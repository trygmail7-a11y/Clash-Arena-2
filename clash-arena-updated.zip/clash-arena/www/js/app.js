/**
 * CLASH ARENA — APP CONTROLLER
 * --------------------------------------------------
 * Plain JS SPA. Handles screen navigation, rendering mock data into the DOM,
 * and simple interactions (join tournament, add coins, withdraw, etc).
 *
 * NOTE: This is the TESTING/UI phase. All actions here simulate what will
 * later call Supabase / ZapUPI / Firebase. Search for "TODO(backend)"
 * to find every point where a real API call will replace mock logic.
 */

/**
 * SVG ICON SET
 * --------------------------------------------------
 * Clean, consistent line icons (stroke="currentColor") used in place of
 * emoji for core navigation chrome — bottom nav, back arrows, chevrons,
 * bell, edit — so sizing and weight stay identical across every screen
 * and every device, instead of relying on the OS's emoji font.
 */
const ICONS = {
  home: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5"/></svg>`,
  trophy: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 4h8v5a4 4 0 0 1-8 0V4Z"/><path d="M8 5H5a2 2 0 0 0 0 4h1.5M16 5h3a2 2 0 0 1 0 4h-1.5"/><path d="M9.5 13.5 9 20M14.5 13.5 15 20M7 20h10"/></svg>`,
  controller: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="8" width="19" height="10" rx="4"/><path d="M7 11v4M5 13h4M16 12h.01M18.5 14.5h.01"/></svg>`,
  wallet: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18"/><circle cx="16.5" cy="14.5" r="1"/></svg>`,
  profile: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="3.3"/><path d="M5 20c1-3.8 4-5.8 7-5.8s6 2 7 5.8"/></svg>`,
  chevronLeft: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5 8 12l7 7"/></svg>`,
  chevronRight: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>`,
  bell: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9a6 6 0 0 1 12 0c0 4 1.5 5.5 2 6.5H4c.5-1 2-2.5 2-6.5Z"/><path d="M10 19a2 2 0 0 0 4 0"/></svg>`,
  edit: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z"/></svg>`,
  people: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3"/><path d="M2.5 20c.7-3.2 3.3-5 6.5-5s5.8 1.8 6.5 5"/><circle cx="17" cy="8" r="2.5"/><path d="M16 11.2c2.3.4 4 1.9 4.5 4.3"/></svg>`,
  gift: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="8" width="18" height="4"/><path d="M12 8v13M5 8v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8"/><path d="M12 8c-1.5-4-6-4-6-1.5S9 8 12 8Zm0 0c1.5-4 6-4 6-1.5S15 8 12 8Z"/></svg>`,
  headset: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13v-1a8 8 0 0 1 16 0v1"/><rect x="2.5" y="13" width="4" height="6" rx="1.5"/><rect x="17.5" y="13" width="4" height="6" rx="1.5"/><path d="M20 19v1a3 3 0 0 1-3 3h-3"/></svg>`,
  coinsStack: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="9" cy="6" rx="6" ry="3"/><path d="M3 6v5c0 1.7 2.7 3 6 3s6-1.3 6-3V6"/><path d="M3 11v5c0 1.7 2.7 3 6 3s6-1.3 6-3v-5"/><path d="M15 9.5c2.9.3 6 1.4 6 3v5c0 1.7-3.1 3-6 3-1.3 0-2.5-.2-3.5-.7"/></svg>`,
  coinQuestion: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.8.4-1 1-1 1.7"/><circle cx="12" cy="16.3" r=".3" fill="currentColor"/></svg>`,
  personBan: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="10" cy="8" r="3.3"/><path d="M3.5 20c.9-3.6 3.7-5.5 6.5-5.5.9 0 1.8.2 2.6.6"/><circle cx="18" cy="17" r="3.3"/><path d="m16 15 4 4"/></svg>`,
  lock: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4.5" y="10.5" width="15" height="10" rx="2"/><path d="M8 10.5V7a4 4 0 0 1 8 0v3.5"/></svg>`,
  bug: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="8" width="10" height="10" rx="5"/><path d="M12 8V5.5M9 5.5 7.5 4M15 5.5 16.5 4M4.5 12H7M17 12h2.5M5 17l2.3-1.3M19 17l-2.3-1.3M9 21l1-2.5M15 21l-1-2.5"/></svg>`,
  robot: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="8" width="16" height="11" rx="3"/><circle cx="9" cy="13.5" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="13.5" r="1.2" fill="currentColor" stroke="none"/><path d="M9 17h6M12 8V5M9.5 5h5"/></svg>`,
  checkCircle: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.3 2.3 2.3 4.7-5.2"/></svg>`,
  cardAdd: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="6" width="19" height="13" rx="2.5"/><path d="M2.5 10.5h19"/><path d="M6 15h4"/><path d="M17 13.5v4M15 15.5h4"/></svg>`,
  ticket: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v1.5a1.7 1.7 0 0 0 0 3V15a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1.5a1.7 1.7 0 0 0 0-3V9Z"/><path d="M10 7.5v9" stroke-dasharray="1.8 1.8"/></svg>`,
  fileDoc: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3.5h8l4 4V19a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4.5 19V5A1.5 1.5 0 0 1 6 3.5Z"/><path d="M14 3.5V8h4"/><path d="M8 12.5h8M8 15.5h8M8 9.5h3"/></svg>`,
  bookOpen: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 6.5c-1.6-1.3-4-2-6.5-2A2 2 0 0 0 3.5 6.5v11c2.7 0 5.2.7 6.9 2 .3.3.9.3 1.2 0 1.7-1.3 4.2-2 6.9-2v-11a2 2 0 0 0-2-2c-2.5 0-4.9.7-6.5 2Z"/><path d="M12 6.5V19"/></svg>`,
  paperclip: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11.5 12.5 19a4.5 4.5 0 0 1-6.4-6.4L14 4.7a3 3 0 0 1 4.2 4.2l-7.6 7.6a1.5 1.5 0 0 1-2.1-2.1l6.7-6.7"/></svg>`,
  sendArrow: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 15-7-6.5 15-2.5-6.5L5 12Z"/></svg>`,
  envelope: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5.5" width="18" height="13" rx="2"/><path d="m4 6.5 8 6.5 8-6.5"/></svg>`,
  chatBubble: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12a8 8 0 1 1 3.5 6.6L4 20l1.2-3.6A7.96 7.96 0 0 1 4 12Z"/></svg>`,
  clock: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></svg>`,
  calendar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3.5v4M16 3.5v4"/></svg>`,
  share: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5.5" r="2.3"/><circle cx="6" cy="12" r="2.3"/><circle cx="18" cy="18.5" r="2.3"/><path d="m8.1 10.8 7.8-4.2M8.1 13.2l7.8 4.2"/></svg>`,
  search: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.3-4.3"/></svg>`,
  bank: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10 12 4l9 6"/><path d="M4.5 10v8.5M8.5 10v8.5M15.5 10v8.5M19.5 10v8.5"/><path d="M3 19h18"/></svg>`,
  chevronDown: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>`,
  shield: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.5 5 6v6c0 4.5 3 7.5 7 8.5 4-1 7-4 7-8.5V6l-7-2.5Z"/></svg>`,
  camera: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8.5a1.5 1.5 0 0 1 1.5-1.5h1.8l1-1.6h7.4l1 1.6h1.8A1.5 1.5 0 0 1 20 8.5v9A1.5 1.5 0 0 1 18.5 19h-13A1.5 1.5 0 0 1 4 17.5v-9Z"/><circle cx="12" cy="13" r="3.3"/></svg>`,
  save: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4.5h11L19.5 8v11a.5.5 0 0 1-.5.5H5a.5.5 0 0 1-.5-.5V5a.5.5 0 0 1 .5-.5Z"/><path d="M8 4.5V9h6V4.5M8 14h8v5.5H8Z"/></svg>`,
  pin: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-6.5-5.7-6.5-11A6.5 6.5 0 0 1 18.5 10c0 5.3-6.5 11-6.5 11Z"/><circle cx="12" cy="10" r="2.3"/></svg>`,
  copy: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="8.5" y="8.5" width="11" height="11" rx="2"/><path d="M5.5 15.5h-1a2 2 0 0 1-2-2v-9a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`,
  moneyBag: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 4.5h5L16 7"/><path d="M8 4.5 6 8c-1.3 2-2 3.6-2 6a8 8 0 0 0 16 0c0-2.4-.7-4-2-6l-2-3.5"/><path d="M12 11v4M10 12.5h4"/></svg>`,
  alertCircle: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v5"/><circle cx="12" cy="16.3" r=".3" fill="currentColor"/></svg>`,
  helpCircle: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.8.4-1 1-1 1.7"/><circle cx="12" cy="16.3" r=".3" fill="currentColor"/></svg>`,
  crown: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 8 3 3 6-6 6 6 3-3-2 10H5L3 8Z"/></svg>`,
  refund: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 8v4l2.5 2.5"/></svg>`,
  target: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/></svg>`,
  eye: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>`,
  diamond: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9 8 4h8l5 5-9 11L3 9Z"/><path d="M3 9h18M9 4l3 5 3-5M8 9l4 11 4-11"/></svg>`,
  barChart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20V10M12 20V4M20 20v-7"/></svg>`,
  smartphone: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6.5" y="2.5" width="11" height="19" rx="2"/><path d="M11 18.5h2"/></svg>`,
  document: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3.5h8l4 4V19a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4.5 19V5A1.5 1.5 0 0 1 6 3.5Z"/><path d="M14 3.5V8h4"/></svg>`,
  facebook: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.5 21v-7.5h2.5l.4-3h-2.9V8.5c0-.9.2-1.5 1.6-1.5h1.4V4.3C16.2 4.2 15.3 4 14.3 4c-2.3 0-3.8 1.4-3.8 3.9v2.6H8v3h2.5V21h3Z"/></svg>`,
  instagram: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="17" height="17" rx="4.5"/><circle cx="12" cy="12" r="3.8"/><circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none"/></svg>`,
  youtube: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="6" width="19" height="12" rx="3.5"/><path d="M10.5 9.5v5l4.5-2.5-4.5-2.5Z" fill="currentColor" stroke="none"/></svg>`,
  telegram: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 11 17-7-6 16-4.5-5.5L3 11Z"/><path d="m9.5 14.5 8.5-9.5"/></svg>`,
  shieldCheck: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5 4.5 5.5V11c0 5.2 3.2 9 7.5 10.5 4.3-1.5 7.5-5.3 7.5-10.5V5.5L12 2.5Z"/></svg>`,
  smsBubble: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 4.5h16A1.5 1.5 0 0 1 21.5 6v10a1.5 1.5 0 0 1-1.5 1.5H9l-4.5 4v-4H4A1.5 1.5 0 0 1 2.5 16V6A1.5 1.5 0 0 1 4 4.5Z"/></svg>`,
  upiIdLogo: `<svg viewBox="0 0 24 24"><rect x="6.5" y="2" width="11" height="20" rx="2" fill="none" stroke="#2d1f6b" stroke-width="1.3"/><text x="12" y="10.3" font-size="4.6" font-weight="800" font-style="italic" fill="#2d1f6b" text-anchor="middle">UPI</text><text x="12" y="15.8" font-size="4" font-weight="700" fill="#2d1f6b" text-anchor="middle">@upi</text></svg>`,
  checkmark: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 13 5 5L19 7"/></svg>`,
  wifiOff: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 1l22 22"/><path d="M16.72 11.06A10.94 10.94 0 0 1 19 12.55"/><path d="M5 12.55a10.94 10.94 0 0 1 5.17-2.39"/><path d="M10.71 5.05A16 16 0 0 1 22.58 9"/><path d="M1.42 9a15.91 15.91 0 0 1 4.7-2.88"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><path d="M12 20h.01"/></svg>`,
  googleLogo: `<svg viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.1H42V20H24v8h11.3C33.7 32.4 29.3 35 24 35c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 5 29.5 3 24 3 12.4 3 3 12.4 3 24s9.4 21 21 21 21-9.4 21-21c0-1.3-.1-2.6-.4-3.9Z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.6 15.9 18.9 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 7 29.5 5 24 5c-7.7 0-14.4 4.4-17.7 10.7Z"/><path fill="#4CAF50" d="M24 45c5.4 0 10.3-1.8 14-5l-6.6-5.4C29.3 36.4 26.8 37 24 37c-5.3 0-9.7-2.6-11.3-6.9L6.2 34c3.3 6.3 9.9 11 17.8 11Z"/><path fill="#1976D2" d="M43.6 20.1H42V20H24v8h11.3c-.8 2.2-2.2 4.1-4 5.5l6.6 5.4C41.3 36 45 30.5 45 24c0-1.3-.1-2.6-.4-3.9Z"/></svg>`,
  facebookLogo: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#1877F2"/><path fill="#fff" d="M13.5 21v-7.5h2.5l.4-3h-2.9V8.5c0-.9.2-1.5 1.6-1.5h1.4V4.3C16.2 4.2 15.3 4 14.3 4c-2.3 0-3.8 1.4-3.8 3.9v2.6H8v3h2.5V21h3Z"/></svg>`,
  appleLogo: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.05 12.5c0-2.6 2.1-3.8 2.2-3.9-1.2-1.7-3-1.9-3.7-2-1.6-.2-3 .9-3.8.9-.8 0-2-.9-3.3-.9-1.7 0-3.3 1-4.1 2.5-1.8 3.1-.5 7.6 1.3 10.1.9 1.2 1.9 2.6 3.2 2.6 1.3 0 1.8-.8 3.3-.8s2 .8 3.3.8c1.4 0 2.3-1.3 3.1-2.5.7-1 1.1-2 1.4-2.9-3.3-1.2-3.7-4.2-3.7-3.9ZM14.6 4.7c.7-.9 1.2-2.1 1-3.3-1.1.1-2.4.7-3.1 1.6-.7.8-1.3 2-1.1 3.2 1.2.1 2.4-.6 3.2-1.5Z"/></svg>`,
  whatsapp: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#25D366"/><path fill="#fff" d="M12 5.5a6.5 6.5 0 0 0-5.6 9.8L5.5 18.5l3.3-.9A6.5 6.5 0 1 0 12 5.5Zm0 1.3a5.2 5.2 0 0 1 4.4 8 5.2 5.2 0 0 1-7.6 1.9l-.3-.2-1.9.5.5-1.8-.2-.3a5.2 5.2 0 0 1 5.1-7.1Zm-2.4 2.6c-.1 0-.3 0-.4.2-.2.2-.6.6-.6 1.4s.6 1.6.7 1.7c.1.1 1.2 1.9 3 2.6.4.2.8.3 1 .4.4.1.8.1 1.1.1.3-.1.9-.4 1.1-.7.1-.3.1-.6.1-.7 0-.1-.1-.1-.3-.2l-1.3-.6c-.2-.1-.3-.1-.4.1l-.5.7c-.1.1-.2.1-.3.1-.2-.1-.7-.3-1.3-.8-.5-.4-.8-1-.9-1.1-.1-.1 0-.2.1-.3l.3-.4c.1-.1.1-.2.2-.3 0-.1 0-.2 0-.3l-.6-1.4c-.1-.4-.3-.3-.4-.3h-.4Z"/></svg>`,
  phonepeLogo: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#5F259F"/><text x="12" y="17.5" font-family="sans-serif" font-size="14" font-weight="700" fill="#fff" text-anchor="middle" font-style="italic">पे</text></svg>`,
  instagramLogo: `<svg viewBox="0 0 24 24"><defs><linearGradient id="igGrad" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#FEE411"/><stop offset=".3" stop-color="#FD5949"/><stop offset=".6" stop-color="#D6249F"/><stop offset="1" stop-color="#285AEB"/></linearGradient></defs><circle cx="12" cy="12" r="12" fill="url(#igGrad)"/><rect x="6.5" y="6.5" width="11" height="11" rx="3" fill="none" stroke="#fff" stroke-width="1.4"/><circle cx="12" cy="12" r="2.6" fill="none" stroke="#fff" stroke-width="1.4"/><circle cx="15.3" cy="8.7" r=".7" fill="#fff"/></svg>`,
  youtubeLogo: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#FF0000"/><path fill="#fff" d="M10 8.5v7l6-3.5-6-3.5Z"/></svg>`,
  telegramLogo: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#26A5E4"/><path fill="#fff" d="m5.5 12.2 12.3-4.7c.6-.2 1.1.1.9.9l-2.1 9.9c-.2.7-.6.9-1.2.5l-3.3-2.4-1.6 1.5c-.2.2-.3.3-.6.3l.2-3.1 5.7-5.1c.2-.2 0-.3-.3-.1l-7 4.4-3-1c-.7-.2-.7-.7.1-1.1Z"/></svg>`,
  coin: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#F5C242"/><circle cx="12" cy="12" r="10" fill="none" stroke="#B8860B" stroke-width="1"/><circle cx="12" cy="12" r="7.3" fill="none" stroke="#B8860B" stroke-width="0.8" opacity="0.65"/><path d="M12 8v8M9.6 10c0-1 1-1.7 2.4-1.7s2.4.6 2.4 1.5c0 2.1-4.8 1-4.8 3.1 0 .9 1.1 1.6 2.4 1.6s2.4-.6 2.4-1.6" stroke="#B8860B" stroke-width="1" fill="none" stroke-linecap="round"/></svg>`
};

const NAV_ITEMS = [
  { screen: "screen-tournaments", icon: "trophy", label: "Tournaments" },
  { screen: "screen-matches", icon: "controller", label: "My Matches" },
  { screen: "screen-home", icon: "home", label: "Home" },
  { screen: "screen-wallet", icon: "wallet", label: "Wallet" },
  { screen: "screen-profile", icon: "profile", label: "Profile" }
];

let state = {
  currentScreen: "screen-login",
  history: [],
  tournamentFilter: "ALL",
  matchFilter: "Ongoing",
  addAmount: 100,
  withdrawAmount: 300,
  activeTournamentId: null,
  selectedAvatarId: null,      // working selection on the avatar-select screen (only committed on Confirm)
  avatarOrigin: "screen-home", // where to return to after confirming an avatar
  pendingChatTopic: null,      // topic to jump straight into when the bot chat screen opens
  chat: null,                   // { topicKey, awaiting: 'buttons'|'select'|'input'|null, inputNext }
  activeMatch: null,           // { id, tab } for the Match Details screen
  activeWithdrawMethod: null,  // which payment method's detail screen is showing
  bankDetailsMode: "view"      // "view" (saved account + Change) or "edit" (entry form)
};

/* ---------------- NAVIGATION ---------------- */

function navigate(screenId, pushHistory = true) {
  if (!document.getElementById(screenId)) return;
  // Stop any running room-countdown timer when leaving Match Details, so it
  // doesn't keep ticking (and updating a DOM node that's no longer visible)
  // in the background.
  if (state.currentScreen === "screen-match-details" && screenId !== "screen-match-details" && activeCountdownInterval) {
    clearInterval(activeCountdownInterval);
    activeCountdownInterval = null;
  }
  if (pushHistory && state.currentScreen && state.currentScreen !== screenId) {
    state.history.push(state.currentScreen);
  }
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById(screenId).classList.add("active");
  state.currentScreen = screenId;
  refreshAvatarDisplays();
  refreshUserDisplays();
  refreshBalanceDisplays();
  renderScreen(screenId);
  polishIcons();
  window.scrollTo(0, 0);
}

function goBack() {
  const prev = state.history.pop();
  if (prev) navigate(prev, false);
}

/* ---------------- BOTTOM NAV ---------------- */

function buildBottomNav() {
  const navs = document.querySelectorAll(".bottom-nav");
  navs.forEach(nav => {
    nav.innerHTML = NAV_ITEMS.map(item => `
      <div class="nav-item" data-nav="${item.screen}">
        <span class="nav-icon ${item.screen === 'screen-home' ? 'nav-icon-home' : ''}">${ICONS[item.icon]}</span>
        <span>${item.label}</span>
      </div>
    `).join("");
  });
}

function polishIcons() {
  // Any element marked data-icon="key" gets its SVG injected — covers every
  // icon placeholder across the app from a single source of truth (ICONS).
  document.querySelectorAll("[data-icon]").forEach(el => {
    const key = el.dataset.icon;
    if (ICONS[key] && el.innerHTML.trim() === "") el.innerHTML = ICONS[key];
  });
  // Back arrows and stray chevrons in static markup that aren't tagged.
  document.querySelectorAll(".back-btn").forEach(el => {
    if (el.textContent.trim() === "←") el.innerHTML = ICONS.chevronLeft;
  });
  document.querySelectorAll("span, div.help-chevron").forEach(el => {
    if (el.children.length !== 0) return;
    const t = el.textContent.trim();
    if (t === "›") el.innerHTML = ICONS.chevronRight;
  });
}

function updateBottomNavActive() {
  document.querySelectorAll(".nav-item").forEach(el => {
    el.classList.toggle("active", el.dataset.nav === state.currentScreen);
  });
}

/* ---------------- RENDER FUNCTIONS ---------------- */

function tournamentCard(t, opts = {}) {
  const [c1, c2] = t.banner_color.split(",");
  return `
    <div class="t-card" data-open-tournament="${t.id}">
      <div class="t-thumb" style="background:linear-gradient(135deg,${c1},${c2})">${t.type.toUpperCase()}</div>
      <div class="t-info">
        <div class="t-title-row">
          <span class="t-title">${t.name}</span>
          <span class="t-timer">⏱ ${t.countdown}</span>
        </div>
        <div class="t-meta">
          <span>Entry: <b><span class="coin-icon-inline">${ICONS.coin}</span>${t.entry_fee}</b></span>
          <span>Prize: <b>₹${t.prize_pool}</b></span>
        </div>
        <div class="t-bottom-row">
          <span class="t-players">${t.joined}/${t.slots} joined</span>
          <button class="t-join-btn" data-open-tournament="${t.id}">JOIN</button>
        </div>
      </div>
    </div>`;
}

function renderHomeTournaments() {
  const list = MOCK.tournaments.slice(0, 4);
  document.getElementById("home-tournament-list").innerHTML = list.map(t => tournamentCard(t)).join("");
}

function renderTournamentsFull() {
  let list = MOCK.tournaments;
  if (state.tournamentFilter !== "ALL") {
    list = list.filter(t => t.category === state.tournamentFilter || t.type === state.tournamentFilter);
  }
  const el = document.getElementById("tournament-list-full");
  el.innerHTML = list.length
    ? list.map(t => tournamentCard(t)).join("")
    : `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">No tournaments in this category yet.</p>`;
}

function openTournamentDetails(id) {
  const t = MOCK.tournaments.find(x => x.id === id);
  if (!t) return;
  state.activeTournamentId = id;
  const [c1, c2] = t.banner_color.split(",");
  const banner = document.getElementById("details-banner");
  banner.style.background = `linear-gradient(135deg,${c1},${c2})`;
  banner.innerHTML = `<h2 style="margin:0;font-size:20px;">${t.name}</h2>`;
  document.getElementById("d-entry").innerHTML = `<span class="coin-icon-inline">${ICONS.coin}</span>${t.entry_fee}`;
  document.getElementById("d-prize").textContent = `₹${t.prize_pool}`;
  document.getElementById("d-mode").textContent = t.mode;
  document.getElementById("d-team").textContent = t.team_type;
  document.getElementById("d-perkill").textContent = t.per_kill;
  document.getElementById("d-map").textContent = t.map;
  document.getElementById("d-version").textContent = t.version;
  document.getElementById("d-room").textContent = t.room_type;
  document.getElementById("d-teams").textContent = t.total_teams;
  document.getElementById("d-ends").textContent = t.reg_ends;
  document.getElementById("d-join-cost").innerHTML = `${t.entry_fee} <span class="coin-icon-inline">${ICONS.coin}</span>`;
  navigate("screen-tournament-details");
}

function matchCard(m, tab) {
  if (tab === "Ongoing") {
    return `
      <div class="t-card">
        <div class="t-thumb" style="background:linear-gradient(135deg,#232526,#414345)">${m.name.slice(0,2).toUpperCase()}</div>
        <div class="t-info">
          <div class="t-title-row">
            <span class="t-title">${m.name}</span>
            <span class="status-tag status-ongoing">LIVE</span>
          </div>
          <div class="t-meta"><span>Entry: <b><span class="coin-icon-inline">${ICONS.coin}</span>${m.entry}</b></span><span>⏱ ${m.countdown}</span></div>
          <div class="t-bottom-row">
            <span class="t-players">Rank ${m.rank} · ${m.kills} Kills</span>
            <button class="t-rank-btn" data-open-match="${m.id}" data-match-tab="${tab}">VIEW</button>
          </div>
        </div>
      </div>`;
  }
  const statusClass = tab === "Completed" ? "status-completed" : "status-cancelled";
  return `
    <div class="t-card">
      <div class="t-thumb" style="background:linear-gradient(135deg,#232526,#414345)">${m.name.slice(0,2).toUpperCase()}</div>
      <div class="t-info">
        <div class="t-title-row">
          <span class="t-title">${m.name}</span>
          <span class="status-tag ${statusClass}">${tab.toUpperCase()}</span>
        </div>
        <div class="t-meta"><span>Entry: <b><span class="coin-icon-inline">${ICONS.coin}</span>${m.entry}</b></span><span>Prize: <b>₹${m.prize || 0}</b></span></div>
        <div class="t-bottom-row">
          <span class="t-players">Rank ${m.rank} · ${m.kills} Kills</span>
          <button class="t-rank-btn" data-open-match="${m.id}" data-match-tab="${tab}">DETAILS</button>
        </div>
      </div>
    </div>`;
}

function renderMatches() {
  const list = MOCK.matches[state.matchFilter] || [];
  const el = document.getElementById("match-list");
  el.innerHTML = list.length
    ? list.map(m => matchCard(m, state.matchFilter)).join("")
    : `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">No ${state.matchFilter.toLowerCase()} matches.</p>`;
}

/* ---------------- REAL DATA FETCHERS (replace MOCK arrays in place) ---------------- */
// A small rotating palette since tournament banner colors aren't stored in
// the DB — keeps cards visually distinct without needing a schema change.
const BANNER_PALETTE = ["#7b2ff7,#f107a3", "#0f2027,#2c5364", "#1f1c2c,#928dab", "#232526,#414345", "#3a1c71,#d76d77"];

function formatCountdown(targetIso) {
  const diffMs = new Date(targetIso).getTime() - Date.now();
  if (diffMs <= 0) return "00:00:00";
  const totalSec = Math.floor(diffMs / 1000);
  const hh = String(Math.floor(totalSec / 3600)).padStart(2, "0");
  const mm = String(Math.floor((totalSec % 3600) / 60)).padStart(2, "0");
  const ss = String(totalSec % 60).padStart(2, "0");
  return `${hh}:${mm}:${ss}`;
}

async function fetchTournaments() {
  const { data, error } = await window.supabaseClient
    .from("tournaments")
    .select("*, participant_count:participants(count)")
    .in("status", ["upcoming", "live"])
    .order("created_at", { ascending: false });
  if (error) { console.error("fetchTournaments failed:", error); return; }

  MOCK.tournaments = (data || []).map((t, i) => ({
    id: t.id,
    name: t.name,
    category: t.category,
    type: t.category,
    banner_color: BANNER_PALETTE[i % BANNER_PALETTE.length],
    entry_fee: t.entry_fee,
    prize_pool: t.prize_pool,
    joined: t.participant_count?.[0]?.count || 0,
    slots: t.max_slots,
    countdown: formatCountdown(t.registration_ends_at),
    reg_ends: formatCountdown(t.registration_ends_at),
    map: t.map || "—",
    mode: t.mode || t.category,
    team_type: t.team_type || "—",
    per_kill: t.per_kill_reward || 0,
    version: t.version || "—",
    room_type: t.room_type || "Custom",
    total_teams: `${t.participant_count?.[0]?.count || 0}/${t.max_slots}`,
  }));
}

async function fetchMatches() {
  const userId = localStorage.getItem("ca_user_id");
  if (!userId) return;

  const { data, error } = await window.supabaseClient
    .from("participants")
    .select("*, tournaments(*), match_results(*)")
    .eq("user_id", userId)
    .order("joined_at", { ascending: false });
  if (error) { console.error("fetchMatches failed:", error); return; }

  const buckets = { Ongoing: [], Completed: [], Cancelled: [] };
  const defaultRules = ["No Hacks or Third Party Apps.", "No Abusive Language.", "Respect All Players.", "Decision of Admin will be Final."];

  (data || []).forEach(p => {
    const t = p.tournaments;
    if (!t) return;
    const result = Array.isArray(p.match_results) ? p.match_results.find(r => r.user_id === userId) : null;
    const base = {
      id: p.id, name: t.name, entry: t.entry_fee,
      tournament_id: t.tournament_number, room_id: "", room_password: "",
      team_type: t.team_type || "—", starts_in: formatCountdown(t.match_starts_at || t.registration_ends_at),
      date: new Date(t.match_starts_at || t.created_at).toLocaleDateString(),
      time: new Date(t.match_starts_at || t.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      map: t.map || "—", players: `${t.max_slots}`, prize_pool: t.prize_pool,
      team: [{ name: p.game_name, uid: p.game_uid, role: "Leader" }],
      match_type: t.room_type || "Custom", gameplay: t.mode || t.category, perspective: "—", environment: "—",
      booyah_reward: t.prize_pool, per_kill_reward: t.per_kill_reward || 0, rules: defaultRules,
    };

    if (t.status === "cancelled") {
      buckets.Cancelled.push({ ...base, rank: "-", kills: 0, prize: 0, cancel_reason: "Cancelled by admin", refund_status: "REFUND INITIATED" });
    } else if (t.status === "completed" || result) {
      buckets.Completed.push({
        ...base, rank: result ? `#${result.rank}` : "—", kills: result?.kills || 0, prize: result?.prize_won || 0,
        results: { rank: result ? `#${result.rank}` : "—", of: t.max_slots, eliminations: result?.kills || 0, earned: result?.prize_won || 0 },
        summary: { total_time: "—", distance: "—", damage: 0, headshots: 0, revives: 0 },
        your_share: result?.prize_won || 0,
      });
    } else {
      buckets.Ongoing.push({ ...base, countdown: base.starts_in, rank: "—", kills: 0 });
    }
  });

  MOCK.matches = buckets;
}

async function fetchTransactions() {
  const userId = localStorage.getItem("ca_user_id");
  if (!userId) return;
  const { data, error } = await window.supabaseClient
    .from("coin_transactions").select("*").eq("user_id", userId)
    .order("created_at", { ascending: false }).limit(50);
  if (error) { console.error("fetchTransactions failed:", error); return; }
  MOCK.transactions = (data || []).map(tx => ({
    id: tx.id,
    label: ({ join: "Tournament Join", winning: "Tournament Winning", add_money: "Add Money", referral: "Referral Bonus", withdraw: "Withdrawal", admin_adjust: "Admin Adjustment" })[tx.type] || tx.type,
    date: new Date(tx.created_at).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }),
    amount: tx.amount,
  }));
}

async function fetchWithdrawals() {
  const userId = localStorage.getItem("ca_user_id");
  if (!userId) return;
  const { data, error } = await window.supabaseClient
    .from("withdrawals").select("*").eq("user_id", userId)
    .order("created_at", { ascending: false });
  if (error) { console.error("fetchWithdrawals failed:", error); return; }
  MOCK.withdrawals = (data || []).map(w => ({
    id: w.id,
    label: `Withdraw to ${w.destination_type.toUpperCase()}`,
    date: new Date(w.created_at).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }),
    amount: -w.amount,
    status: w.status.charAt(0).toUpperCase() + w.status.slice(1),
  }));
}

async function fetchGiveaways() {
  const { data, error } = await window.supabaseClient
    .from("giveaways").select("*").eq("status", "active")
    .order("ends_at", { ascending: true });
  if (error) { console.error("fetchGiveaways failed:", error); return; }
  MOCK.giveaways = (data || []).map(g => ({ id: g.id, name: g.title, ends: `Ends ${new Date(g.ends_at).toLocaleDateString()}` }));
}

async function fetchReferrals() {
  const userId = localStorage.getItem("ca_user_id");
  if (!userId) return;
  const { data, error } = await window.supabaseClient
    .from("referrals").select("*, users!referrals_referred_id_fkey(username)").eq("referrer_id", userId)
    .order("created_at", { ascending: false });
  if (error) { console.error("fetchReferrals failed:", error); return; }
  MOCK.referrals = (data || []).map(r => ({
    id: r.id,
    label: `${r.users?.username || "A player"} joined using your code`,
    date: new Date(r.created_at).toLocaleDateString(),
    amount: r.reward_coins,
  }));
}

async function fetchNotifications() {
  const userId = localStorage.getItem("ca_user_id");
  if (!userId) return;
  const { data, error } = await window.supabaseClient
    .from("notifications").select("*").or(`user_id.eq.${userId},user_id.is.null`)
    .order("created_at", { ascending: false }).limit(50);
  if (error) { console.error("fetchNotifications failed:", error); return; }
  MOCK.notifications = (data || []).map(n => ({
    id: n.id, label: n.title, body: n.body,
    date: new Date(n.created_at).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }),
  }));
}

function txRow(tx) {
  const positive = tx.amount > 0;
  return `
    <div class="tx-row">
      <div>
        <div class="tx-name">${tx.label}</div>
        <div class="tx-date">${tx.date}</div>
      </div>
      <div class="tx-amt ${positive ? 'pos' : 'neg'}">${positive ? '+' : ''}${tx.amount} <span class="coin-icon-inline">${ICONS.coin}</span></div>
    </div>`;
}

function renderWallet() {
  document.getElementById("wallet-balance").textContent = MOCK.user.coin_balance.toLocaleString();
  document.getElementById("home-balance").textContent = MOCK.user.coin_balance.toLocaleString();
  document.getElementById("wallet-tx-list").innerHTML = MOCK.transactions.slice(0, 4).map(txRow).join("");
}

function renderHistory() {
  document.getElementById("history-tx-list").innerHTML = MOCK.transactions.map(txRow).join("");
}

function renderWithdrawHistory() {
  document.getElementById("withdraw-history-list").innerHTML = MOCK.withdrawals.map(w => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${w.label}</div>
        <div class="tx-date">${w.date} · ${w.status}</div>
      </div>
      <div class="tx-amt neg">${w.amount} <span class="coin-icon-inline">${ICONS.coin}</span></div>
    </div>`).join("");
}

function renderGiveaways() {
  document.getElementById("giveaway-list").innerHTML = MOCK.giveaways.map(g => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${g.name}</div>
        <div class="tx-date">${g.ends}</div>
      </div>
      <button class="t-join-btn" data-action="participate">Participate</button>
    </div>`).join("");
}

function renderReferrals() {
  const codeInput = document.getElementById("referral-code-input");
  if (codeInput) codeInput.value = MOCK.user.referral_code || "";
  const total = MOCK.referrals.reduce((sum, r) => sum + (r.amount || 0), 0);
  const totalEl = document.getElementById("referral-earnings-total");
  if (totalEl) totalEl.textContent = total;
  document.getElementById("referral-list").innerHTML = MOCK.referrals.length
    ? MOCK.referrals.map(r => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${r.label}</div>
        <div class="tx-date">${r.date}</div>
      </div>
      <div class="tx-amt pos">+${r.amount} <span class="coin-icon-inline">${ICONS.coin}</span></div>
    </div>`).join("")
    : `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">No referrals yet. Share your code to start earning!</p>`;
}

function renderNotifications() {
  document.getElementById("notification-list").innerHTML = MOCK.notifications.map(n => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${n.label}</div>
        <div class="tx-date">${n.body}</div>
      </div>
      <div class="tx-date">${n.date}</div>
    </div>`).join("");
}

/* ---------------- AVATAR SYSTEM ---------------- */
// Avatars are 10 fixed local images. Only the `avatar_id` string is ever
// stored/read from "the database" (MOCK.user.avatar_id here, a real
// `users.avatar_id` column in Phase 2) — never the image itself.

function getAvatarFile(avatarId) {
  const found = MOCK.avatars.find(a => a.id === avatarId);
  return found ? found.file : MOCK.avatars[0].file;
}

function refreshAvatarDisplays() {
  const file = getAvatarFile(MOCK.user.avatar_id);
  const home = document.getElementById("home-avatar-img");
  const profile = document.getElementById("profile-avatar-img");
  const editProfile = document.getElementById("edit-profile-avatar-img");
  if (home) home.src = file;
  if (profile) profile.src = file;
  if (editProfile) editProfile.src = file;
}

function refreshUserDisplays() {
  const homeName = document.getElementById("home-username");
  const profileName = document.getElementById("profile-name-h2");
  const uidTag = document.getElementById("profile-uid-tag");
  const statTournaments = document.getElementById("profile-stat-tournaments");
  const statWins = document.getElementById("profile-stat-wins");
  const statWinrate = document.getElementById("profile-stat-winrate");
  if (homeName) homeName.textContent = MOCK.user.username || "Player";
  if (profileName) profileName.textContent = MOCK.user.username || "Player";
  if (uidTag) uidTag.textContent = "UID: " + (MOCK.user.uid || "—");
  if (statTournaments) statTournaments.textContent = MOCK.user.tournaments_played || 0;
  if (statWins) statWins.textContent = MOCK.user.wins || 0;
  if (statWinrate) statWinrate.textContent = (MOCK.user.win_rate || 0) + "%";
}

function refreshBalanceDisplays() {
  const u = MOCK.user;
  const total = u.coin_balance.toLocaleString();
  const totalFmt = "₹" + u.coin_balance.toLocaleString() + ".00";

  const homeBalance = document.getElementById("home-balance");
  const walletBalance = document.getElementById("wallet-balance");
  const winningAmt = document.getElementById("winning-balance-amt");
  const bonusAmt = document.getElementById("bonus-balance-amt");
  const cashAmt = document.getElementById("cash-balance-amt");
  const whAmount = document.getElementById("wh-amount");
  const wmAmount = document.getElementById("wm-amount");
  const wmAmountSm = document.getElementById("wm-amount-sm");

  // Every "balance" shown anywhere in the app (Home, Wallet, Withdraw, and
  // every withdrawal method screen) always reflects the SAME single number —
  // MOCK.user.coin_balance — so nothing ever looks out of sync.
  if (homeBalance) homeBalance.textContent = total;
  if (walletBalance) walletBalance.textContent = total;
  if (winningAmt) winningAmt.textContent = u.winning_balance.toLocaleString();
  if (bonusAmt) bonusAmt.textContent = u.bonus_balance.toLocaleString();
  if (cashAmt) cashAmt.textContent = u.cash_balance.toLocaleString();
  if (whAmount) whAmount.textContent = totalFmt;
  if (wmAmount) wmAmount.textContent = totalFmt;
  if (wmAmountSm) wmAmountSm.textContent = totalFmt;
}

function renderAvatarGrid() {
  if (state.selectedAvatarId === null) state.selectedAvatarId = MOCK.user.avatar_id;
  const grid = document.getElementById("avatar-grid");
  grid.innerHTML = MOCK.avatars.filter(a => a.enabled).map(a => `
    <div class="avatar-item ${a.id === state.selectedAvatarId ? 'selected' : ''}" data-avatar-id="${a.id}">
      <img src="${a.file}" alt="${a.id}" />
    </div>`).join("");

  // back / cancel should return wherever the user came from
  state.avatarOrigin = state.history[state.history.length - 1] || "screen-home";
  const backBtn = document.getElementById("avatar-back-btn");
  if (backBtn) backBtn.dataset.nav = state.avatarOrigin;
}

function renderSignupAvatarRow() {
  if (state.selectedAvatarId === null) state.selectedAvatarId = MOCK.user.avatar_id;
  const row = document.getElementById("signup-avatar-row");
  if (!row) return;
  row.innerHTML = MOCK.avatars.filter(a => a.enabled).map(a => `
    <div class="signup-avatar-item ${a.id === state.selectedAvatarId ? 'selected' : ''}" data-signup-avatar-id="${a.id}">
      <img src="${a.file}" alt="${a.id}" />
    </div>`).join("");
}

/* ---------------- SUPPORT: QUICK HELP ---------------- */

function renderQuickHelp() {
  const grid = document.getElementById("quick-help-grid");
  if (!grid) return;
  grid.innerHTML = MOCK.quickHelp.map(q => `
    <div class="qh-card" data-open-chat="${q.topic}">
      <span class="qh-icon ${q.accent === 'gold' ? 'accent-gold-icon' : ''}">${ICONS[q.icon]}</span>
      <span class="qh-title">${q.title}</span>
      <span class="qh-sub">${q.sub}</span>
    </div>`).join("");
}

/* ---------------- SUPPORT BOT (CHAT ENGINE) ---------------- */

function chatTimestamp() {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function scrollChatToBottom() {
  const body = document.getElementById("chat-body");
  if (body) body.scrollTop = body.scrollHeight;
}

function appendBotBubble(text) {
  const body = document.getElementById("chat-body");
  body.insertAdjacentHTML("beforeend", `
    <div class="bubble-row bot">
      <span class="bubble-avatar">${ICONS.robot}</span>
      <div>
        <div class="bubble">${text}</div>
        <span class="bubble-time">${chatTimestamp()}</span>
      </div>
    </div>`);
  scrollChatToBottom();
}

function appendUserBubble(text) {
  const body = document.getElementById("chat-body");
  body.insertAdjacentHTML("beforeend", `
    <div class="bubble-row user">
      <div>
        <div class="bubble">${text}</div>
        <span class="bubble-time">${chatTimestamp()} ✓✓</span>
      </div>
    </div>`);
  scrollChatToBottom();
}

function clearChatControls() {
  const old = document.getElementById("chat-controls");
  if (old) old.remove();
}

function appendChatControls(html) {
  clearChatControls();
  const body = document.getElementById("chat-body");
  body.insertAdjacentHTML("beforeend", `<div id="chat-controls">${html}</div>`);
  scrollChatToBottom();
}

function startChatScreen() {
  const body = document.getElementById("chat-body");
  body.innerHTML = "";
  state.chat = { topicKey: null, awaiting: null, inputNext: null };
  appendBotBubble("👋 Hi! Welcome to Clash Arena Support. How can I help you today?");

  if (state.pendingChatTopic && MOCK.botFlows[state.pendingChatTopic]) {
    const topic = MOCK.chatTopics.find(t => t.topic === state.pendingChatTopic)
      || MOCK.quickHelp.find(t => t.topic === state.pendingChatTopic);
    if (topic) appendUserBubble(topic.label || topic.title);
    runBotFlow(state.pendingChatTopic, MOCK.botFlows[state.pendingChatTopic].start);
  } else {
    showChatTopicMenu();
  }
  state.pendingChatTopic = null;
}

function showChatTopicMenu() {
  appendBotBubble("Please choose a topic");
  const html = `<div class="chat-topic-grid">${MOCK.chatTopics.map(t => `
    <button class="chat-topic-btn" data-chat-topic-btn="${t.topic}" data-chat-topic-label="${t.label}">
      <span class="ct-icon ${t.accent === 'gold' ? 'accent-gold-icon' : ''}">${ICONS[t.icon]}</span>${t.label}<span class="ct-arrow">${ICONS.chevronRight}</span>
    </button>`).join("")}</div>`;
  appendChatControls(html);
}

function runBotFlow(topicKey, stepKey) {
  const flow = MOCK.botFlows[topicKey];
  if (!flow) return;
  const step = flow.steps[stepKey];
  if (!step) return;

  state.chat.topicKey = topicKey;
  clearChatControls();
  appendBotBubble(step.text);

  if (step.buttons) {
    state.chat.awaiting = "buttons";
    appendChatControls(`<div class="chat-quick-replies">${step.buttons.map((b, i) => `
      <button class="${i === 0 ? 'qr-primary' : 'qr-secondary'}" data-chat-btn-next="${b.next}" data-chat-btn-label="${b.label}" ${b.nav ? `data-chat-btn-nav="${b.nav}"` : ""}>${b.label}</button>`).join("")}</div>`);
  } else if (step.select) {
    state.chat.awaiting = "select";
    appendChatControls(`<div class="chat-topic-grid" style="grid-template-columns:1fr;">${step.select.options.map(opt => `
      <button class="chat-topic-btn" data-chat-select-next="${step.select.next}" data-chat-select-label="${opt}">${opt}<span class="ct-arrow">›</span></button>`).join("")}</div>`);
  } else {
    state.chat.awaiting = null;
    if (step.next) {
      // auto-advance steps with no interaction required (e.g. info-only messages)
      setTimeout(() => runBotFlow(topicKey, step.next), 500);
    }
  }
}

function handleChatButtonClick(next, label, nav) {
  appendUserBubble(label);
  clearChatControls();
  state.chat.awaiting = null;
  if (nav) {
    setTimeout(() => navigate(nav), 400);
    return;
  }
  runBotFlow(state.chat.topicKey, next);
}

function handleChatTopicSelect(topicKey, label) {
  appendUserBubble(label);
  clearChatControls();
  runBotFlow(topicKey, MOCK.botFlows[topicKey].start);
}

/* ---------------- SUPPORT TICKETS ---------------- */

function generateTicketId() {
  return "CA-" + Math.floor(10000 + Math.random() * 89999);
}

function createTicket({ category, reason, mobile }) {
  const t = {
    id: generateTicketId(),
    category: category || "Other",
    reason: reason || "No details provided",
    mobile: mobile || "N/A",
    status: "open",
    admin_reply: "",
    created: "Just now",
    updated: "Just now"
  };
  MOCK.tickets.unshift(t); // TODO(backend): insert into `support_tickets`
  return t;
}

async function fetchTickets() {
  const userId = localStorage.getItem("ca_user_id");
  if (!userId) return;
  const { data, error } = await window.supabaseClient
    .from("support_tickets").select("*, support_categories(label)").eq("user_id", userId)
    .order("created_at", { ascending: false });
  if (error) { console.error("fetchTickets failed:", error); return; }
  MOCK.tickets = (data || []).map(t => ({
    id: t.ticket_number,
    category: t.support_categories?.label || "Other",
    reason: t.reason,
    mobile: t.mobile_number,
    status: t.status,
    admin_reply: "",
    created: new Date(t.created_at).toLocaleDateString(),
    updated: new Date(t.updated_at).toLocaleDateString(),
  }));
}

function statusLabel(status) {
  return status.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
}

function ticketCard(t) {
  return `
    <div class="ticket-card">
      <div class="ticket-top-row">
        <div>
          <div class="ticket-id">${t.id}</div>
          <div class="ticket-cat">${t.category}</div>
        </div>
        <span class="ticket-status status-${t.status.replace(/_/g, '-')}">${statusLabel(t.status)}</span>
      </div>
      <p class="ticket-reason">${t.reason}</p>
      <div class="ticket-dates"><span>Created: ${t.created}</span><span>Updated: ${t.updated}</span></div>
      ${t.admin_reply ? `<div class="ticket-admin-reply"><strong>Admin Reply</strong>${t.admin_reply}</div>` : ""}
    </div>`;
}

function renderTickets() {
  const list = document.getElementById("tickets-list");
  if (!list) return;
  list.innerHTML = MOCK.tickets.length
    ? MOCK.tickets.map(ticketCard).join("")
    : `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">No tickets yet. Create one from the Support Center.</p>`;
}

/* ---------------- HELP CENTER ---------------- */

function renderHelpCenter() {
  const wrap = document.getElementById("help-center-list");
  if (!wrap) return;
  wrap.innerHTML = MOCK.faq.map((cat, ci) => `
    <div class="help-category">
      <div class="help-category-title">${cat.category}</div>
      ${cat.items.map((item, ii) => `
        <div class="help-item" data-help-id="${ci}-${ii}">
          <div class="help-q" data-help-toggle="${ci}-${ii}">${item.q}<span class="help-chevron">›</span></div>
          <div class="help-a"><div class="help-a-inner">${item.a}</div></div>
        </div>`).join("")}
    </div>`).join("");
}

function renderMatchDetails() {
  const wrap = document.getElementById("match-details-content");
  if (!wrap || !state.activeMatch) return;
  const { id, tab } = state.activeMatch;
  const m = (MOCK.matches[tab] || []).find(x => x.id === id);
  if (!m) { wrap.innerHTML = ""; return; }

  const teamIcon = tab === "Cancelled" ? "personBan" : "crown";
  let html = `
    <span class="md-status-badge md-status-${tab.toLowerCase()}">${tab.toUpperCase()}</span>
    <div class="md-id-row">
      <div>Tournament ID<strong>${m.tournament_id}<span class="md-copy" data-icon="copy"></span></strong></div>
    </div>
    <div class="md-team-header">
      <span class="md-team-icon" data-icon="${teamIcon}"></span>
      <div><strong>${m.name}</strong><span>${m.team_type}</span></div>
    </div>`;

  if (tab === "Ongoing") {
    html += `
    <button class="md-room-pw-btn" data-open-room-password="${m.id}" data-match-tab="${tab}">
      <span data-icon="lock"></span>View Your Room Password<span class="ct-arrow" data-icon="chevronRight"></span>
    </button>
    <div class="md-countdown-box">
      <span class="md-countdown-label" id="md-countdown-label">STARTS IN</span>
      <div class="md-countdown-time" id="md-countdown-time"></div>
    </div>
    <div class="md-row-2col">
      <div class="md-mini-card"><span data-icon="calendar"></span><div><span>Date</span><strong>${m.date}</strong></div></div>
      <div class="md-mini-card"><span data-icon="clock"></span><div><span>Time</span><strong>${m.time}</strong></div></div>
    </div>
    <div class="md-row-2col">
      <div class="md-mini-card"><span data-icon="pin"></span><div><span>Map</span><strong>${m.map}</strong></div></div>
      <div class="md-mini-card"><span data-icon="people"></span><div><span>Players</span><strong>${m.players}</strong></div></div>
    </div>
    <div class="md-section-card">
      <div class="md-section-title">ENTRY &amp; PRIZE</div>
      <div class="md-fee-prize-row">
        <div class="md-fee-box"><span>Entry Fee</span><strong><span data-icon="coinsStack"></span>${m.entry}</strong></div>
        <div class="md-fee-box"><span>Prize Pool</span><strong><span data-icon="trophy"></span>${m.prize_pool}</strong></div>
      </div>
    </div>
    <div class="md-section-card">
      <div class="md-section-title">YOUR TEAM<span class="md-leader-badge"><span data-icon="crown"></span>Leader</span></div>
      ${m.team.map(p => `
        <div class="md-team-member">
          <span class="md-member-avatar" data-icon="profile"></span>
          <span class="md-member-name">${p.name}${p.uid ? `<span class="md-member-uid">UID: ${p.uid}</span>` : ""}</span>
          <span class="md-member-role">${p.role}</span>
        </div>`).join("")}
    </div>
    <div class="md-section-card">
      <div class="md-section-title">MATCH INFO</div>
      <div class="md-info-row"><span>Match Type</span><span>${m.match_type}</span></div>
      <div class="md-info-row"><span>Gameplay</span><span>${m.gameplay}</span></div>
      <div class="md-info-row"><span>Perspective</span><span>${m.perspective}</span></div>
      <div class="md-info-row"><span>Environment</span><span>${m.environment}</span></div>
      <div class="md-info-row"><span>Booyah Reward</span><span>${m.booyah_reward}</span></div>
      <div class="md-info-row"><span>Per Kill Reward</span><span>${m.per_kill_reward}</span></div>
    </div>
    <div class="md-section-card">
      <div class="md-section-title">RULES</div>
      <ul class="md-rules-list">${m.rules.map(r => `<li>${r}</li>`).join("")}</ul>
    </div>
    <button class="md-action-btn" data-nav="screen-matches" data-action="join-room"><span data-icon="sendArrow"></span>JOIN ROOM</button>`;
  } else if (tab === "Completed") {
    html += `
    <div class="md-won-banner"><span data-icon="trophy"></span><strong>YOU WON</strong></div>
    <div class="md-row-2col">
      <div class="md-mini-card"><span data-icon="calendar"></span><div><span>Date</span><strong>${m.date}</strong></div></div>
      <div class="md-mini-card"><span data-icon="clock"></span><div><span>Time</span><strong>${m.time}</strong></div></div>
    </div>
    <div class="md-row-2col">
      <div class="md-mini-card"><span data-icon="pin"></span><div><span>Map</span><strong>${m.map}</strong></div></div>
      <div class="md-mini-card"><span data-icon="people"></span><div><span>Players</span><strong>${m.players}</strong></div></div>
    </div>
    <div class="md-section-card">
      <div class="md-section-title">RESULTS</div>
      <div class="md-fee-prize-row">
        <div class="md-fee-box"><span>Rank</span><strong>${m.results.rank} / ${m.results.of}</strong></div>
        <div class="md-fee-box"><span>Eliminations</span><strong>${m.results.eliminations}</strong></div>
      </div>
      <div class="md-info-row" style="margin-top:10px;"><span>You Earned</span><span><span data-icon="coinsStack" style="display:inline-flex;width:14px;height:14px;vertical-align:-2px;margin-right:4px;"></span>${m.results.earned}</span></div>
    </div>
    <div class="md-section-card">
      <div class="md-section-title">YOUR TEAM<span class="md-leader-badge"><span data-icon="crown"></span>Leader</span></div>
      ${m.team.map(p => `
        <div class="md-team-member">
          <span class="md-member-avatar" data-icon="profile"></span>
          <span class="md-member-name">${p.name}${p.uid ? `<span class="md-member-uid">UID: ${p.uid}</span>` : ""}</span>
          <span class="md-member-kills">${p.kills} Kills</span>
        </div>`).join("")}
    </div>
    <div class="md-section-card">
      <div class="md-section-title">MATCH SUMMARY</div>
      <div class="md-info-row"><span>Total Time</span><span>${m.summary.total_time}</span></div>
      <div class="md-info-row"><span>Distance Traveled</span><span>${m.summary.distance}</span></div>
      <div class="md-info-row"><span>Damage Dealt</span><span>${m.summary.damage}</span></div>
      <div class="md-info-row"><span>Headshots</span><span>${m.summary.headshots}</span></div>
      <div class="md-info-row"><span>Revives</span><span>${m.summary.revives}</span></div>
      <div class="md-fee-prize-row" style="margin-top:12px;">
        <div class="md-fee-box"><span>Prize Pool</span><strong><span data-icon="trophy"></span>${m.prize_pool}</strong></div>
        <div class="md-fee-box"><span>Your Share</span><strong><span data-icon="coinsStack"></span>${m.your_share}</strong></div>
      </div>
    </div>
    <button class="md-action-btn" data-action="claim-reward"><span data-icon="gift"></span>CLAIM REWARD</button>`;
  } else {
    html += `
    <div class="md-cancel-banner"><strong>MATCH CANCELLED</strong><span>Reason: ${m.cancel_reason}</span></div>
    <div class="md-row-2col">
      <div class="md-mini-card"><span data-icon="calendar"></span><div><span>Date</span><strong>${m.date}</strong></div></div>
      <div class="md-mini-card"><span data-icon="clock"></span><div><span>Time</span><strong>${m.time}</strong></div></div>
    </div>
    <div class="md-row-2col">
      <div class="md-mini-card"><span data-icon="pin"></span><div><span>Map</span><strong>${m.map}</strong></div></div>
      <div class="md-mini-card"><span data-icon="people"></span><div><span>Players</span><strong>${m.players}</strong></div></div>
    </div>
    <div class="md-section-card">
      <div class="md-section-title">DETAILS</div>
      <div class="md-fee-prize-row">
        <div class="md-fee-box"><span>Entry Fee</span><strong><span data-icon="coinsStack"></span>${m.entry}</strong></div>
        <div class="md-fee-box"><span>Prize Pool</span><strong><span data-icon="trophy"></span>${m.prize_pool}</strong></div>
      </div>
    </div>
    <div class="md-section-card">
      <div class="md-section-title">REFUND STATUS</div>
      <div class="md-refund-box">
        <span data-icon="refund"></span>
        <div>
          <p>Your entry fee will be refunded to your wallet within 24 hours.</p>
          <span class="md-refund-tag">${m.refund_status}</span>
        </div>
      </div>
    </div>
    <div class="md-section-card">
      <div class="md-section-title">MATCH INFO</div>
      <div class="md-info-row"><span>Match Type</span><span>${m.match_type}</span></div>
      <div class="md-info-row"><span>Gameplay</span><span>${m.gameplay}</span></div>
      <div class="md-info-row"><span>Perspective</span><span>${m.perspective}</span></div>
      <div class="md-info-row"><span>Environment</span><span>${m.environment}</span></div>
    </div>
    <div class="md-section-card">
      <div class="md-section-title">RULES</div>
      <ul class="md-rules-list">${m.rules.map(r => `<li>${r}</li>`).join("")}</ul>
    </div>
    <button class="md-action-btn" data-nav="screen-matches"><span data-icon="controller"></span>BACK TO MY MATCHES</button>`;
  }

  wrap.innerHTML = html;
  if (tab === "Ongoing") startRoomCountdown(m);
}

// Tracks the currently-running countdown so we can stop it when leaving
// the screen or re-rendering, instead of piling up duplicate timers.
let activeCountdownInterval = null;

function startRoomCountdown(m) {
  if (activeCountdownInterval) clearInterval(activeCountdownInterval);

  // Fix the actual target moment ONCE per match (cached on the mock object
  // itself) by parsing the "HH:MM:SS" duration relative to right now. Every
  // future render/tick reuses this same fixed target, so the timer counts
  // down for real instead of resetting back to the original value.
  if (!m._startsAtMs) {
    const [h, min, s] = m.starts_in.split(":").map(Number);
    m._startsAtMs = Date.now() + ((h * 3600 + min * 60 + s) * 1000);
  }

  const labelEl = document.getElementById("md-countdown-label");
  const timeEl = document.getElementById("md-countdown-time");
  if (!timeEl) return;

  const tick = () => {
    const remainingMs = m._startsAtMs - Date.now();
    if (remainingMs <= 0) {
      clearInterval(activeCountdownInterval);
      if (labelEl) labelEl.textContent = "ROOM STARTED";
      timeEl.innerHTML = `<span class="md-countdown-live">Room is now live — join now!</span>`;
      return;
    }
    const totalSec = Math.floor(remainingMs / 1000);
    const hh = String(Math.floor(totalSec / 3600)).padStart(2, "0");
    const mm = String(Math.floor((totalSec % 3600) / 60)).padStart(2, "0");
    const ss = String(totalSec % 60).padStart(2, "0");
    timeEl.innerHTML = `<span>${hh}<small>HRS</small></span>:<span>${mm}<small>MIN</small></span>:<span>${ss}<small>SEC</small></span>`;
  };

  tick(); // paint immediately, don't wait a full second for the first frame
  activeCountdownInterval = setInterval(tick, 1000);
}

/* ---------------- WITHDRAWAL METHOD DETAIL (data-driven) ---------------- */

const WM_LOGO_HTML = {
  upi: `<span class="upi-text-lg">UPI</span><span class="upi-arrow-lg"></span><span class="upi-subtitle">UNIFIED PAYMENTS INTERFACE</span>`,
  upiid: `<span class="upi-text-lg">UPI ID</span><span class="upi-arrow-lg"></span>`,
  phonepe: `<span class="wm-phonepe-mark">${ICONS.phonepeLogo}</span>`,
  paytm: `<span class="paytm-text-lg">Paytm</span>`,
  gpay: `<div class="gpay-lockup">${ICONS.googleLogo}<span>Pay</span></div>`,
  bank: `<span class="wm-bank-mark">${ICONS.bank}</span>`
};

function renderWithdrawMethodScreen() {
  const key = state.activeWithdrawMethod;
  const m = MOCK.withdrawMethods[key];
  if (!m) return;

  document.getElementById("wm-title").textContent = m.title;
  document.getElementById("wm-hero").className = "wm-hero wm-theme-" + m.theme;
  document.getElementById("wm-logo-circle").className = "wm-logo-circle wm-logo-" + m.theme;
  document.getElementById("wm-logo-circle").innerHTML = WM_LOGO_HTML[key] || "";
  document.getElementById("wm-processing-time").textContent = m.processingTime || "24 - 48 Hours";
  document.getElementById("wm-processing-note").textContent = m.processingNote;
  document.getElementById("wm-submit-btn").className = "md-action-btn wm-submit-" + m.theme;
  document.getElementById("wm-important-box").className = "wm-important-box wm-important-" + m.theme;
  document.getElementById("wm-important-list").innerHTML = m.important.map(i => `<li>${i}</li>`).join("");

  const fieldsWrap = document.getElementById("wm-fields");
  const detailsTitle = document.getElementById("wm-details-title");

  if (m.isBank) {
    detailsTitle.textContent = "Bank Details";
    const hasSavedBank = MOCK.user.savedBank && state.bankDetailsMode !== "edit";
    if (hasSavedBank) {
      const b = MOCK.user.savedBank;
      fieldsWrap.innerHTML = `
        <div class="wm-bank-card">
          <span class="wm-bank-icon" data-icon="bank"></span>
          <div class="wm-bank-info">
            <strong>${b.bankName}</strong>
            <span>A/C No. ${b.accountNo}</span>
            <span>IFSC ${b.ifsc}</span>
          </div>
          <a href="#" class="wm-change-link" data-action="change-bank">Change</a>
        </div>`;
    } else {
      fieldsWrap.innerHTML = `
        <p class="field-label">Bank Name <span class="field-hint">(Required)</span></p>
        <div class="input-icon-wrap"><span class="input-icon" data-icon="bank"></span><input type="text" data-bank-field="bankName" placeholder="e.g., HDFC Bank" /></div>
        <p class="field-label">Account Number <span class="field-hint">(Required)</span></p>
        <div class="input-icon-wrap"><span class="input-icon" data-icon="coinsStack"></span><input type="text" inputmode="numeric" data-bank-field="accountNo" placeholder="Enter account number" /></div>
        <p class="field-label">IFSC Code <span class="field-hint">(Required)</span></p>
        <div class="input-icon-wrap"><span class="input-icon" data-icon="document"></span><input type="text" data-bank-field="ifsc" placeholder="e.g., HDFC0001234" style="text-transform:uppercase;" /></div>
        <button class="wallet-action-btn full" data-action="save-bank-details">Save Bank Details</button>`;
    }
  } else {
    detailsTitle.textContent = m.title.replace(" Withdrawal", "") + " Details";
    fieldsWrap.innerHTML = m.fields.map(f => `
      <p class="field-label">${f.label} <span class="field-hint">(${f.required ? "Required" : "Optional"})</span></p>
      <div class="input-icon-wrap">
        ${f.icon ? `<span class="input-icon" data-icon="${f.icon}"></span>` : ""}
        <input type="text" data-wm-field="${f.key}" placeholder="${f.placeholder}" />
      </div>
      ${f.hint ? `<p class="field-hint" style="margin:-8px 0 12px;">${f.hint}</p>` : ""}
    `).join("");
  }

  if (m.extraNote) {
    fieldsWrap.innerHTML += `<div class="info-note-box" style="max-width:none;margin-top:4px;"><span data-icon="alertCircle"></span><div><span>${m.extraNote}</span></div></div>`;
  }

  polishIcons();
}

function renderRoomPassword() {
  if (!state.activeMatch) return;
  const { id, tab } = state.activeMatch;
  const m = (MOCK.matches[tab] || []).find(x => x.id === id);
  if (!m) return;
  document.getElementById("rp-tournament-name").textContent = m.name;
  document.getElementById("rp-room-id").textContent = m.room_id || "—";
  document.getElementById("rp-room-password").textContent = m.room_password || "—";
}

function renderScreen(id) {
  updateBottomNavActive();
  switch (id) {
    case "screen-home":
      renderHomeTournaments();
      fetchTournaments().then(renderHomeTournaments);
      break;
    case "screen-tournaments":
      renderTournamentsFull();
      fetchTournaments().then(renderTournamentsFull);
      break;
    case "screen-matches":
      renderMatches();
      fetchMatches().then(renderMatches);
      break;
    case "screen-wallet":
      renderWallet();
      fetchTransactions().then(renderWallet);
      break;
    case "screen-history":
      renderHistory();
      fetchTransactions().then(renderHistory);
      break;
    case "screen-withdraw":
      renderWithdrawHistory();
      fetchWithdrawals().then(renderWithdrawHistory);
      break;
    case "screen-withdraw-method": renderWithdrawMethodScreen(); break;
    case "screen-giveaway":
      renderGiveaways();
      fetchGiveaways().then(renderGiveaways);
      break;
    case "screen-refer":
      renderReferrals();
      fetchReferrals().then(renderReferrals);
      break;
    case "screen-notifications":
      renderNotifications();
      fetchNotifications().then(renderNotifications);
      break;
    case "screen-addmoney": {
      state.addAmount = 100;
      document.getElementById("addmoney-amt").textContent = "100";
      document.querySelectorAll("#amount-grid [data-amt]").forEach(x => x.classList.toggle("active", x.dataset.amt === "100"));
      const customInput = document.getElementById("custom-amount-input");
      if (customInput) customInput.value = "";
      break;
    }
    case "screen-avatar-select": renderAvatarGrid(); break;
    case "screen-edit-profile": {
      const parts = (MOCK.user.full_name || MOCK.user.username || "").split(" ");
      document.getElementById("edit-first-name").value = parts[0] || "";
      document.getElementById("edit-last-name").value = parts.slice(1).join(" ") || "";
      document.getElementById("edit-username").value = MOCK.user.username || "";
      document.getElementById("edit-email-display").value = MOCK.user.email || "";
      document.getElementById("edit-mobile").value = MOCK.user.mobile || "";
      document.getElementById("edit-gender").value = MOCK.user.gender || "";
      document.getElementById("edit-dob").value = MOCK.user.date_of_birth || "";
      document.getElementById("edit-dob-display").value = MOCK.user.date_of_birth
        ? new Date(MOCK.user.date_of_birth).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })
        : "";
      break;
    }
    case "screen-privacy": {
      const cameFromLogin = state.history[state.history.length - 1] === "screen-login";
      const backBtn = document.getElementById("privacy-back-btn");
      const bottomNav = document.getElementById("privacy-bottom-nav");
      if (backBtn) backBtn.dataset.nav = cameFromLogin ? "screen-login" : "screen-profile";
      if (bottomNav) bottomNav.style.display = cameFromLogin ? "none" : "";
      break;
    }
    case "screen-signup": renderSignupAvatarRow(); break;
    case "screen-support": renderQuickHelp(); break;
    case "screen-support-bot": startChatScreen(); break;
    case "screen-my-tickets":
      renderTickets();
      fetchTickets().then(renderTickets);
      break;
    case "screen-help-center": renderHelpCenter(); break;
    case "screen-match-details": renderMatchDetails(); break;
    case "screen-room-password": renderRoomPassword(); break;
    case "screen-verify": {
      const targetEl = document.getElementById("verify-target-email");
      if (targetEl) targetEl.textContent = state.pendingSignupEmail || "your email";
      document.querySelectorAll("#screen-verify .otp-box").forEach(box => box.value = "");
      break;
    }
    case "screen-create-ticket":
      document.getElementById("ticket-reason").value = "";
      document.getElementById("ticket-mobile").value = "";
      document.getElementById("reason-word-count").textContent = "(max 50 characters)";
      break;
  }
}

/* ---------------- TOAST ---------------- */

let toastTimer = null;
function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
}

/* ---------------- ACTIONS ---------------- */

function handleAction(action, el) {
  switch (action) {
    case "login": {
      const email = document.getElementById("login-email").value.trim();
      const password = document.getElementById("login-password").value;
      if (!email || !password) { toast("Enter your email and password."); return; }
      toast("Logging in...");
      window.supabaseClient.auth.signInWithPassword({ email, password }).then(async ({ data, error }) => {
        if (error) { toast(error.message); return; }
        await afterAuthSuccess(data.user.id);
        toast("Welcome back!");
        navigate("screen-home");
      });
      break;
    }
    case "signup": {
      const fullname = document.getElementById("signup-fullname").value.trim();
      const email = document.getElementById("signup-email").value.trim();
      const mobile = document.getElementById("signup-mobile").value.trim();
      const password = document.getElementById("signup-password").value;
      const confirmPassword = document.getElementById("signup-confirm-password").value;
      const termsChecked = document.getElementById("signup-terms").checked;
      if (!fullname || !email || !mobile || !password) { toast("Please fill in all fields."); return; }
      if (password !== confirmPassword) { toast("Passwords do not match."); return; }
      if (password.length < 6) { toast("Password must be at least 6 characters."); return; }
      if (!termsChecked) { toast("Please accept the Terms & Conditions."); return; }

      toast("Creating your account...");
      window.supabaseClient.auth.signUp({
        email, password,
        options: { data: { full_name: fullname, mobile, avatar_id: state.selectedAvatarId || "avatar_01" } },
      }).then(({ data, error }) => {
        if (error) { toast(error.message); return; }
        const profile = { fullname, mobile };
        const referralCode = document.getElementById("signup-referral").value.trim().toUpperCase();

        // If Supabase already returned an active session, "Confirm email"
        // is OFF in the project's Auth settings — the account is ready
        // immediately, no OTP needed at all. This is the normal path.
        if (data.session) {
          finishAccountSetup(data.user.id, profile, referralCode);
        } else {
          // Fallback: "Confirm email" is still ON in Supabase settings, so
          // an OTP is required before the account can be used.
          state.pendingSignupEmail = email;
          state.pendingSignupProfile = profile;
          state.pendingReferralCode = referralCode;
          toast("Verification code sent to your email!");
          navigate("screen-verify");
        }
      });
      break;
    }
    case "resend-code":
      if (!state.pendingSignupEmail) { toast("Please sign up again."); return; }
      window.supabaseClient.auth.resend({ type: "signup", email: state.pendingSignupEmail }).then(({ error }) => {
        toast(error ? error.message : "Verification code resent!");
      });
      break;
    case "verify": {
      const digits = Array.from(document.querySelectorAll("#screen-verify .otp-box")).map(x => x.value.trim());
      const code = digits.join("");
      if (!state.pendingSignupEmail) { toast("Please sign up again."); return; }
      if (code.length !== 6) { toast("Enter the full 6-digit code."); return; }

      window.supabaseClient.auth.verifyOtp({
        email: state.pendingSignupEmail, token: code, type: "signup",
      }).then(async ({ data, error }) => {
        if (error) { toast(error.message); return; }
        await finishAccountSetup(data.user.id, state.pendingSignupProfile || {}, state.pendingReferralCode);
        toast("Email verified!");
      });
      break;
    }
    case "logout":
      window.supabaseClient.auth.signOut();
      setLoggedIn(false);
      localStorage.removeItem("ca_user_id");
      state.history = [];
      toast("Logged out.");
      break;
    case "open-join-modal": {
      const t = MOCK.tournaments.find(x => x.id === state.activeTournamentId);
      if (t && MOCK.user.coin_balance < t.entry_fee) {
        toast("Insufficient coin balance.");
        return;
      }
      // Prefill from last time so returning players don't retype every match
      const savedUid = localStorage.getItem("ca_game_uid");
      const savedName = localStorage.getItem("ca_game_name");
      if (savedUid) document.getElementById("join-game-uid").value = savedUid;
      if (savedName) document.getElementById("join-game-name").value = savedName;
      document.getElementById("join-tournament-modal").classList.add("active");
      break;
    }
    case "close-join-modal":
      document.getElementById("join-tournament-modal").classList.remove("active");
      break;
    case "join": {
      const t = MOCK.tournaments.find(x => x.id === state.activeTournamentId);
      if (t) {
        const gameUid = document.getElementById("join-game-uid").value.trim();
        const gameName = document.getElementById("join-game-name").value.trim();
        if (!gameUid) { toast("Enter your Game UID."); return; }
        if (!gameName) { toast("Enter your Game Name."); return; }
        if (!isLoggedIn()) { toast("Please log in first."); return; }

        toast("Joining tournament...");
        window.supabaseClient.rpc("join_tournament", {
          p_tournament_id: t.id, p_game_uid: gameUid, p_game_name: gameName,
        }).then(async ({ data, error }) => {
          if (error || (data && data.error)) {
            toast((data && data.error) || error.message);
            return;
          }
          // Remembered for next time so returning players don't retype every match
          localStorage.setItem("ca_game_uid", gameUid);
          localStorage.setItem("ca_game_name", gameName);

          const userId = localStorage.getItem("ca_user_id");
          const { data: wallet } = await window.supabaseClient.from("wallets").select("*").eq("user_id", userId).single();
          if (wallet) MOCK.user.coin_balance = (wallet.winning_balance || 0) + (wallet.bonus_balance || 0) + (wallet.cash_balance || 0);
          refreshBalanceDisplays();

          document.getElementById("join-tournament-modal").classList.remove("active");
          toast(`Joined ${t.name}!`);
          navigate("screen-matches");
        });
      }
      break;
    }
    case "addmoney": {
      if (!isLoggedIn()) { toast("Please log in first."); return; }
      const userId = localStorage.getItem("ca_user_id");
      toast("Starting payment...");
      window.supabaseClient.functions.invoke("create-payment", {
        body: { amount: state.addAmount, mobile: MOCK.user.mobile || "9999999999" },
      }).then(async ({ data, error }) => {
        if (error) {
          // When an Edge Function returns a non-2xx status, supabase-js
          // puts the failure in `error` and leaves `data` null — it does
          // NOT auto-parse the JSON body our function actually returned.
          // Read the real reason from error.context (the raw Response)
          // instead of showing a generic, unhelpful message.
          let reason = error.message;
          try {
            const body = await error.context.json();
            if (body && body.error) reason = body.error;
          } catch (e) { /* body wasn't JSON — fall back to error.message */ }
          console.error("create-payment failed:", reason);
          toast(reason || "Could not start payment. Please try again.");
          return;
        }
        if (!data || data.error) {
          toast((data && data.error) || "Could not start payment. Please try again.");
          return;
        }
        // Hands off to ZapUPI's checkout page. Uses Capacitor's in-app
        // browser overlay when running as the native app (so it never
        // fully exits to the phone's separate Chrome app); falls back to a
        // normal browser tab only when running in a plain web browser.
        // isPluginAvailable() is the correct check here — a plain truthy
        // check on window.Capacitor.Plugins.Browser can pass even when the
        // native side isn't actually wired up, silently no-op-ing instead
        // of opening anything.
        try {
          if (window.Capacitor && window.Capacitor.isNativePlatform() && window.Capacitor.isPluginAvailable("Browser")) {
            await window.Capacitor.Plugins.Browser.open({ url: data.payment_url });
          } else {
            window.open(data.payment_url, "_blank");
          }
        } catch (e) {
          console.error("In-app browser failed, falling back:", e);
          window.open(data.payment_url, "_blank");
        }
        navigate("screen-wallet");
      });
      break;
    }
    case "copy-room-id":
      toast("Room ID copied!");
      break;
    case "copy-room-password":
      toast("Room password copied!");
      break;
    case "how-it-works":
      navigate("screen-how-it-works");
      break;
    case "change-bank":
      state.bankDetailsMode = "edit";
      renderWithdrawMethodScreen();
      break;
    case "save-bank-details": {
      const bankName = document.querySelector('[data-bank-field="bankName"]').value.trim();
      const accountNo = document.querySelector('[data-bank-field="accountNo"]').value.trim();
      const ifsc = document.querySelector('[data-bank-field="ifsc"]').value.trim();
      if (!bankName || !accountNo || !ifsc) { toast("Please fill in all bank details."); return; }
      MOCK.user.savedBank = { bankName, accountNo, ifsc }; // TODO(backend): save to `users` bank_details — cleared automatically once admin marks a bank withdrawal as paid
      state.bankDetailsMode = "view";
      toast("Bank details saved!");
      renderWithdrawMethodScreen();
      break;
    }
    case "submit-method-withdraw": {
      const m = MOCK.withdrawMethods[state.activeWithdrawMethod];
      const amt = Number(document.getElementById("wm-amount-input").value);
      if (!amt || amt < 300) { toast("Minimum withdrawal amount is ₹300."); return; }
      if (amt > MOCK.user.coin_balance) { toast("Amount exceeds available balance."); return; }
      if (!m.isBank) {
        for (const f of m.fields) {
          if (f.required) {
            const el = document.querySelector(`[data-wm-field="${f.key}"]`);
            if (!el || !el.value.trim()) { toast(`Please enter your ${f.label}.`); return; }
          }
        }
      } else if (!MOCK.user.savedBank) {
        toast("Please add your bank details first.");
        return;
      }
      MOCK.user.coin_balance -= amt; // TODO(backend): insert into `withdrawals` with method + field data
      MOCK.user.winning_balance = Math.max(0, MOCK.user.winning_balance - amt);
      MOCK.withdrawals.unshift({ id: "w" + Date.now(), label: `Withdraw to ${m.title.replace(" Withdrawal", "")}`, date: "Just now", amount: -amt, status: "Processing" });
      toast("Withdrawal request submitted.");
      navigate("screen-wallet");
      break;
    }
    case "redeem":
      toast("Redeem code applied!"); // TODO(backend): validate against `redeem_codes` table
      break;
    case "copy-code":
      toast(`Referral code copied: ${MOCK.user.referral_code}`);
      break;
    case "share": {
      const inviteUrl = `https://clasharena.app/invite/${MOCK.user.referral_code}`;
      shareContent({
        title: "Join me on Clash Arena!",
        text: `Use my code ${MOCK.user.referral_code} and let's play Free Fire tournaments together on Clash Arena!`,
        url: inviteUrl,
      });
      break;
    }
    case "share-tournament": {
      const t = MOCK.tournaments.find(x => x.id === state.activeTournamentId);
      if (!t) return;
      shareContent({
        title: t.name,
        text: `Join "${t.name}" on Clash Arena — Entry ₹${t.entry_fee}, Prize Pool ₹${t.prize_pool}!`,
        url: `https://clasharena.app/tournament/${t.id}`,
      });
      break;
    }
    case "resend-code":
      toast("Verification code resent!"); // TODO(backend): resend OTP via supabase/SMS provider
      break;
    case "verify-mobile":
      setLoggedIn(true); // TODO(backend): confirm OTP
      toast("Mobile number verified!");
      break;
    case "open-terms-url":
      window.open("https://ClashArenaterm.blogspot.com", "_blank");
      break;
    case "open-privacy-url":
      window.open("https://clasharenaprivacy.blogspot.com", "_blank");
      break;
    case "reset-via-email": {
      const emailInput = document.getElementById("forgot-email");
      const emailVal = emailInput ? emailInput.value.trim() : "";
      if (!emailVal || !emailVal.includes("@")) {
        toast("Enter a valid email address");
        break;
      }
      toast("Sending reset link...");
      window.supabaseClient.auth.resetPasswordForEmail(emailVal, {
        redirectTo: "https://clasharena.app/reset-password",
      }).then(({ error }) => {
        if (error) { toast(error.message); return; }
        toast("Password reset link sent to your email!");
        navigate("screen-login");
      });
      break;
    }
    case "toggle-password": {
      const pw = document.getElementById("login-password");
      if (pw) pw.type = pw.type === "password" ? "text" : "password";
      break;
    }
    case "toggle-signup-password": {
      const pw = document.getElementById("signup-password");
      if (pw) pw.type = pw.type === "password" ? "text" : "password";
      break;
    }
    case "toggle-confirm-password": {
      const pw = document.getElementById("signup-confirm-password");
      if (pw) pw.type = pw.type === "password" ? "text" : "password";
      break;
    }
    case "save-avatar":
      MOCK.user.avatar_id = state.selectedAvatarId; // TODO(backend): update users.avatar_id
      refreshAvatarDisplays();
      toast("Avatar updated!");
      navigate(state.avatarOrigin || "screen-home");
      break;
    case "join-room":
      toast("Opening Free Fire..."); // TODO(backend): fetch live room_id/password from tournament_rooms, then relay into game
      openFreeFire();
      break;
    case "claim-reward":
      toast("Reward claimed! Coins added to your wallet."); // TODO(backend): mark match_results reward as claimed
      break;
    case "open-dob-picker": {
      const dobInput = document.getElementById("edit-dob");
      try { dobInput.showPicker(); } catch (e) { dobInput.click(); }
      break;
    }
    case "save-profile": {
      const first = document.getElementById("edit-first-name").value.trim();
      const last = document.getElementById("edit-last-name").value.trim();
      const uname = document.getElementById("edit-username").value.trim();
      const mobile = document.getElementById("edit-mobile").value.trim();
      const gender = document.getElementById("edit-gender").value;
      const dob = document.getElementById("edit-dob").value;
      const fullName = [first, last].filter(Boolean).join(" ");

      const userId = localStorage.getItem("ca_user_id");
      if (!userId) { toast("Please log in first."); return; }

      toast("Saving...");
      window.supabaseClient.from("users").update({
        full_name: fullName || null,
        username: uname || undefined,
        mobile: mobile || null,
        gender: gender || null,
        date_of_birth: dob || null,
      }).eq("id", userId).then(({ error }) => {
        if (error) { toast("Could not save: " + error.message); return; }
        MOCK.user.full_name = fullName;
        MOCK.user.username = uname || MOCK.user.username;
        MOCK.user.mobile = mobile;
        MOCK.user.gender = gender;
        MOCK.user.date_of_birth = dob;
        refreshUserDisplays();
        toast("Profile updated successfully!");
        navigate("screen-profile");
      });
      break;
    }
    case "submit-ticket": {
      const isTicketForm = document.getElementById("ticket-category");
      if (isTicketForm) {
        // Only one ticket per calendar day — checked against the last
        // submission date saved on this device.
        const today = new Date().toDateString();
        const lastTicketDate = localStorage.getItem("ca_last_ticket_date");
        if (lastTicketDate === today) {
          toast("You can only raise 1 ticket per day. Please try again tomorrow.");
          return;
        }

        const categoryKey = document.getElementById("ticket-category").value;
        const reason = document.getElementById("ticket-reason").value.trim();
        const mobile = document.getElementById("ticket-mobile").value.trim();
        if (!reason) { toast("Please enter a reason."); return; }
        if (reason.length > 50) { toast("Reason must be 50 characters or fewer."); return; }
        if (!mobile || mobile.length < 10) { toast("Please enter a valid mobile number."); return; }

        const userId = localStorage.getItem("ca_user_id");
        if (!userId) { toast("Please log in first."); return; }

        toast("Submitting ticket...");
        (async () => {
          const { data: cat } = await window.supabaseClient.from("support_categories").select("id").eq("key", categoryKey).single();
          const ticketNumber = "CA-" + Math.floor(10000 + Math.random() * 89999);
          const { error } = await window.supabaseClient.from("support_tickets").insert({
            ticket_number: ticketNumber, user_id: userId, category_id: cat?.id, reason, mobile_number: mobile,
          });
          if (error) { toast("Could not submit ticket: " + error.message); return; }
          localStorage.setItem("ca_last_ticket_date", today);
          toast(`Ticket Created Successfully — ${ticketNumber}`);
          navigate("screen-my-tickets");
        })();
      } else {
        toast("Message sent to our support team."); // TODO(backend): insert into `support_tickets` (category: Other)
        navigate("screen-support");
      }
      break;
    }
    case "copy-email":
      toast("Email copied: aplexstudio.in@gmail.com");
      break;
    case "open-whatsapp":
      window.open("https://wa.me/919876543210", "_blank");
      break;
    case "social-link": {
      const links = {
        facebook: "https://facebook.com/ClashArenaOfficial",
        instagram: "https://instagram.com/ClashArenaOfficial",
        youtube: "https://youtube.com/@ClashArenaOfficial",
        telegram: "https://t.me/ClashArenaOfficial",
      };
      const url = links[e.target.closest("[data-platform]")?.dataset.platform];
      if (url) window.open(url, "_blank");
      break;
    }
    case "participate":
      toast("You're in! Good luck 🎉"); // TODO(backend): insert into `giveaway_entries`
      break;
  }
}

/* ---------------- EVENT DELEGATION ---------------- */

document.addEventListener("click", (e) => {
  const navEl = e.target.closest("[data-nav]");
  const openT = e.target.closest("[data-open-tournament]");
  const openM = e.target.closest("[data-open-match]");
  const openWM = e.target.closest("[data-open-withdraw-method]");
  const openRP = e.target.closest("[data-open-room-password]");
  const actionEl = e.target.closest("[data-action]");
  const filterEl = e.target.closest("[data-filter]");
  const amtEl = e.target.closest("[data-amt]");
  const avatarEl = e.target.closest("[data-avatar-id]");
  const signupAvatarEl = e.target.closest("[data-signup-avatar-id]");
  const openChatEl = e.target.closest("[data-open-chat]");
  const helpToggleEl = e.target.closest("[data-help-toggle]");
  const chatTopicBtn = e.target.closest("[data-chat-topic-btn]");
  const chatSelectBtn = e.target.closest("[data-chat-select-next]");
  const chatBtnNext = e.target.closest("[data-chat-btn-next]");

  if (openT) {
    openTournamentDetails(openT.dataset.openTournament);
    return;
  }

  if (openM) {
    state.activeMatch = { id: openM.dataset.openMatch, tab: openM.dataset.matchTab };
    navigate("screen-match-details");
    return;
  }

  if (openWM) {
    state.activeWithdrawMethod = openWM.dataset.openWithdrawMethod;
    state.bankDetailsMode = "view";
    navigate("screen-withdraw-method");
    return;
  }

  if (openRP) {
    state.activeMatch = { id: openRP.dataset.openRoomPassword, tab: openRP.dataset.matchTab };
    navigate("screen-room-password");
    return;
  }

  if (avatarEl) {
    state.selectedAvatarId = avatarEl.dataset.avatarId;
    renderAvatarGrid();
    return;
  }

  if (signupAvatarEl) {
    state.selectedAvatarId = signupAvatarEl.dataset.signupAvatarId;
    renderSignupAvatarRow();
    return;
  }

  if (openChatEl) {
    state.pendingChatTopic = openChatEl.dataset.openChat;
    navigate("screen-support-bot");
    return;
  }

  if (helpToggleEl) {
    const item = document.querySelector(`.help-item[data-help-id="${helpToggleEl.dataset.helpToggle}"]`);
    if (item) item.classList.toggle("open");
    return;
  }

  if (chatTopicBtn) {
    handleChatTopicSelect(chatTopicBtn.dataset.chatTopicBtn, chatTopicBtn.dataset.chatTopicLabel);
    return;
  }

  if (chatSelectBtn) {
    handleChatButtonClick(chatSelectBtn.dataset.chatSelectNext, chatSelectBtn.dataset.chatSelectLabel);
    return;
  }

  if (chatBtnNext) {
    handleChatButtonClick(chatBtnNext.dataset.chatBtnNext, chatBtnNext.dataset.chatBtnLabel, chatBtnNext.dataset.chatBtnNav);
    return;
  }

  if (navEl) {
    navigate(navEl.dataset.nav);
  }

  if (filterEl) {
    const parent = filterEl.closest("#tournament-tabs, #match-tabs, .categories");
    if (parent) {
      parent.querySelectorAll("[data-filter]").forEach(x => x.classList.remove("active"));
      filterEl.classList.add("active");
    }
    if (filterEl.closest("#tournament-tabs") || filterEl.closest(".categories")) {
      state.tournamentFilter = filterEl.dataset.filter;
      if (state.currentScreen !== "screen-tournaments") navigate("screen-tournaments");
      else renderTournamentsFull();
    } else if (filterEl.closest("#match-tabs")) {
      state.matchFilter = filterEl.dataset.filter;
      renderMatches();
    }
  }

  if (amtEl) {
    const grid = amtEl.closest("#amount-grid, #wm-amount-grid");
    grid.querySelectorAll("[data-amt]").forEach(x => x.classList.remove("active"));
    amtEl.classList.add("active");
    const val = Number(amtEl.dataset.amt);
    if (grid.id === "amount-grid") {
      state.addAmount = val;
      document.getElementById("addmoney-amt").textContent = val;
      // Selecting a preset chip clears any custom amount that was typed,
      // so only one amount is ever "active" at a time.
      const customInput = document.getElementById("custom-amount-input");
      if (customInput) customInput.value = "";
    } else if (grid.id === "wm-amount-grid") {
      document.getElementById("wm-amount-input").value = val;
    }
  }

  if (actionEl && !navEl) {
    handleAction(actionEl.dataset.action, actionEl);
  } else if (actionEl && navEl) {
    // element has both nav + action (e.g. login button)
    handleAction(actionEl.dataset.action, actionEl);
  }
});

/* ---------------- OPEN FREE FIRE ---------------- */
// Free Fire's Android package is com.dts.freefireth. On a real Android device
// (inside the Capacitor app) this intent opens Free Fire directly if it's
// installed, or falls back to its Play Store listing if it isn't. In a plain
// desktop browser (local testing) neither will do anything visible — that's
// expected, this only works on Android.
function openFreeFire() {
  const intentUrl = "intent://#Intent;package=com.dts.freefireth;scheme=android-app;S.browser_fallback_url=https://play.google.com/store/apps/details?id=com.dts.freefireth;end";
  try {
    window.location.href = intentUrl;
  } catch (e) { /* not on Android, ignore */ }
}

// Uses the phone's native share sheet (WhatsApp, Instagram, SMS, etc. — all
// installed apps) when available, since that's what real Share buttons do
// on mobile. Falls back to copying the text to the clipboard on platforms
// where navigator.share isn't supported (e.g. desktop browser testing).
async function shareContent({ title, text, url }) {
  const fullText = url ? `${text}\n${url}` : text;
  if (navigator.share) {
    try {
      await navigator.share({ title, text, url });
    } catch (e) {
      // User cancelled the share sheet — not an error, do nothing.
    }
  } else if (navigator.clipboard) {
    try {
      await navigator.clipboard.writeText(fullText);
      toast("Link copied to clipboard!");
    } catch (e) {
      toast("Could not copy link.");
    }
  } else {
    toast("Sharing isn't supported on this device.");
  }
}

/* ---------------- SESSION PERSISTENCE ---------------- */
// Simple client-side "remember me" for this testing build — a real backend
// (Supabase auth session) will replace this in Phase 2, but for now it keeps
// the person logged in across app restarts instead of showing Login every time.
// Runs right after a successful login OR a successful signup+verify:
// remembers who's logged in, registers this device for push notifications
// against the right user, and loads their real wallet/profile data so the
// rest of the app isn't showing stale mock numbers.
// Creates the profile row + starting wallet for a brand-new account, applies
// a referral code if one was entered, then logs them in. Called right after
// signup (instant, no OTP — the normal path) or after OTP verification (only
// if "Confirm email" is still ON in Supabase Auth settings).
async function finishAccountSetup(userId, profile, referralCode) {
  // Username is silently derived from their name (lowercase, no spaces) —
  // never shown to the user as a separate "pick a username" step, since
  // the UID already guarantees a unique identity. If it collides with an
  // existing username, a random 4-digit suffix is added automatically,
  // with no availability check UI needed.
  let username = (profile.fullname || "player").replace(/\s+/g, "").toLowerCase();
  let { error: insertErr } = await window.supabaseClient.from("users").insert({
    id: userId, username, full_name: profile.fullname, mobile: profile.mobile,
    avatar_id: state.selectedAvatarId || "avatar_01",
  });
  if (insertErr && insertErr.message.includes("duplicate")) {
    username = username + Math.floor(1000 + Math.random() * 9000);
    insertErr = (await window.supabaseClient.from("users").insert({
      id: userId, username, full_name: profile.fullname, mobile: profile.mobile,
      avatar_id: state.selectedAvatarId || "avatar_01",
    })).error;
  }
  if (insertErr) {
    console.error("Profile creation failed:", insertErr);
    toast("Account created, but profile setup failed: " + insertErr.message);
    return;
  }
  await window.supabaseClient.from("wallets").insert({ user_id: userId });

  // Apply the referral code they typed at signup, if any — silently
  // skipped (no error shown) if it was left blank or was invalid, since
  // it's optional and shouldn't block account creation.
  if (referralCode) {
    await window.supabaseClient.rpc("apply_referral_code", { p_referral_code: referralCode });
  }

  await afterAuthSuccess(userId);
  navigate("screen-avatar-select");
}

async function afterAuthSuccess(userId) {
  setLoggedIn(true);
  localStorage.setItem("ca_user_id", userId);
  if (window.registerDeviceToken) window.registerDeviceToken(userId);

  try {
    const { data: { user: authUser } } = await window.supabaseClient.auth.getUser();
    const { data: profile } = await window.supabaseClient.from("users").select("*").eq("id", userId).single();
    const { data: wallet } = await window.supabaseClient.from("wallets").select("*").eq("user_id", userId).single();
    if (authUser) MOCK.user.email = authUser.email;
    if (profile) {
      MOCK.user.username = profile.username;
      MOCK.user.full_name = profile.full_name;
      MOCK.user.mobile = profile.mobile;
      MOCK.user.gender = profile.gender;
      MOCK.user.date_of_birth = profile.date_of_birth;
      MOCK.user.uid = profile.uid;
      MOCK.user.avatar_id = profile.avatar_id;
      MOCK.user.referral_code = profile.referral_code;
    }
    if (wallet) {
      MOCK.user.coin_balance = (wallet.winning_balance || 0) + (wallet.bonus_balance || 0) + (wallet.cash_balance || 0);
      MOCK.user.winning_balance = wallet.winning_balance || 0;
      MOCK.user.bonus_balance = wallet.bonus_balance || 0;
      MOCK.user.cash_balance = wallet.cash_balance || 0;
    }

    // Real profile stats — counted live from actual joins/wins, not stored/faked.
    const { count: played } = await window.supabaseClient.from("participants").select("id", { count: "exact", head: true }).eq("user_id", userId);
    const { data: results } = await window.supabaseClient.from("match_results").select("rank").eq("user_id", userId);
    const wins = (results || []).filter(r => r.rank === 1).length;
    MOCK.user.tournaments_played = played || 0;
    MOCK.user.wins = wins;
    MOCK.user.win_rate = played ? Math.round((wins / played) * 100) : 0;

    refreshUserDisplays();
    refreshAvatarDisplays();
    refreshBalanceDisplays();
  } catch (e) {
    console.error("Failed to load profile/wallet:", e);
    toast("Could not load your profile. Pull to refresh or re-login.");
  }
}

function setLoggedIn(isLoggedIn) {
  try {
    if (isLoggedIn) localStorage.setItem("ca_logged_in", "true");
    else localStorage.removeItem("ca_logged_in");
  } catch (e) { /* storage unavailable, ignore */ }
}
function isLoggedIn() {
  try { return localStorage.getItem("ca_logged_in") === "true"; }
  catch (e) { return false; }
}

/* ---------------- INIT ---------------- */

// Native date picker (Date of Birth) — updates the readable display field
// the moment a date is chosen.
document.addEventListener("change", (e) => {
  if (e.target.id === "edit-dob") {
    const displayEl = document.getElementById("edit-dob-display");
    displayEl.value = e.target.value
      ? new Date(e.target.value).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })
      : "";
  }
});

document.addEventListener("input", (e) => {
  if (e.target.classList.contains("otp-box")) {
    if (e.target.value.length >= 1) {
      const next = e.target.nextElementSibling;
      if (next && next.classList.contains("otp-box")) next.focus();
    }
  }
  if (e.target.id === "ticket-reason") {
    // maxlength="50" on the input already stops typing past 50 characters;
    // this just keeps the counter in sync.
    document.getElementById("reason-word-count").textContent = `(${e.target.value.length}/50 characters)`;
  }
  if (e.target.id === "ticket-mobile" || e.target.id === "chat-mobile") {
    e.target.value = e.target.value.replace(/\D/g, "").slice(0, 10);
  }
  if (e.target.id === "custom-amount-input") {
    const val = Number(e.target.value);
    if (val > 0) {
      state.addAmount = val;
      document.getElementById("addmoney-amt").textContent = val;
      // Typing a custom amount deselects any preset chip, so it's clear
      // which amount is actually about to be charged.
      document.querySelectorAll("#amount-grid [data-amt]").forEach(x => x.classList.remove("active"));
    }
  }
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Backspace" && e.target.classList.contains("otp-box") && e.target.value === "") {
    const prev = e.target.previousElementSibling;
    if (prev && prev.classList.contains("otp-box")) prev.focus();
  }
});

document.addEventListener("DOMContentLoaded", () => {
  buildBottomNav();
  document.querySelectorAll("#amount-grid [data-amt='100']").forEach(x => x.classList.add("active"));
  boot();
});

// Splash screen is already the active screen in the HTML (so there's never a
// flash of Login/Home before this runs). It stays up until we've confirmed a
// real, working connection to Supabase — not just that a network exists, but
// that a request actually completed — then routes to Home (if already
// logged in) or Login. If there's no connection, a blocking "No Internet"
// screen takes over instead of leaving the app in a broken half-loaded state.
async function boot() {
  const fill = document.getElementById("splash-progress-fill");
  const loadingText = document.getElementById("splash-loading-text");
  if (fill) fill.style.width = "35%";

  if (!navigator.onLine) {
    showNoInternet();
    return;
  }

  try {
    if (loadingText) loadingText.textContent = "CONNECTING...";
    // A real round-trip to Supabase — confirms the connection actually
    // works, not just that the device thinks it has a network.
    await window.supabaseClient.from("avatars").select("id").limit(1);

    // Check for an existing logged-in session (returning user) and load
    // their real data, instead of relying only on the local "remember me" flag.
    const { data: { session } } = await window.supabaseClient.auth.getSession();
    if (session) {
      await afterAuthSuccess(session.user.id);
    } else {
      setLoggedIn(false);
    }

    if (fill) fill.style.width = "100%";
    hideNoInternet();
    setTimeout(() => {
      navigate(isLoggedIn() ? "screen-home" : "screen-login", false);
    }, 300);
  } catch (err) {
    showNoInternet();
  }
}

function showNoInternet() {
  const overlay = document.getElementById("no-internet-overlay");
  if (overlay) overlay.classList.add("active");
}

function hideNoInternet() {
  const overlay = document.getElementById("no-internet-overlay");
  if (overlay) overlay.classList.remove("active");
}

document.addEventListener("DOMContentLoaded", () => {
  const retryBtn = document.getElementById("retry-connection-btn");
  if (retryBtn) retryBtn.addEventListener("click", () => {
    const loadingText = document.getElementById("splash-loading-text");
    if (loadingText) loadingText.textContent = "LOADING...";
    navigate("screen-splash", false);
    boot();
  });
});

// If the device comes back online while the "No Internet" screen is showing
// (e.g. mid-tournament, wifi drops then returns), retry automatically.
window.addEventListener("online", () => {
  const overlay = document.getElementById("no-internet-overlay");
  if (overlay && overlay.classList.contains("active")) boot();
});

// If connection is lost anywhere else in the app (not just at startup),
// block interaction immediately rather than letting taps silently fail.
window.addEventListener("offline", () => {
  showNoInternet();
});
