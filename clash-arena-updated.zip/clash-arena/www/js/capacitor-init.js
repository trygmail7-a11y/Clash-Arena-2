/**
 * CAPACITOR NATIVE BOOTSTRAP
 * --------------------------------------------------
 * Runs only when the app is actually running inside the native Capacitor
 * shell (Android APK) — completely inert in a plain browser tab, so it's
 * safe to leave in place for local testing too.
 *
 * What it does:
 *  1. Forces the Android status bar (where the clock/battery show) to a
 *     white background with dark icons, matching the app's white theme.
 *  2. Registers this device for push notifications (Firebase Cloud
 *     Messaging) and saves its token to Supabase once a user is logged in,
 *     so the send-notification Edge Function can reach this phone.
 *
 * The native splash screen itself (logo + white background, built from
 * resources/splash.png) is now shown and hidden entirely by Capacitor's
 * own launchAutoHide/launchShowDuration config in capacitor.config.json —
 * deliberately NOT depending on this JS file running successfully to hide
 * it, so a slow-loading WebView can never leave the splash stuck on screen.
 */
(function () {
  function isNative() {
    return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  }

  // Holds the FCM token once the device registers, in case it arrives
  // before we know which user is logged in (e.g. on a fresh install, before
  // Login/Signup completes).
  window.pendingFcmToken = null;

  // Call this once you know the logged-in user's id (right after a
  // successful login/signup). Saves whatever token we currently have —
  // if push registration hasn't finished yet, it saves nothing and that's
  // fine, since registerPush() below will also try to save once it arrives.
  window.registerDeviceToken = async function (userId) {
    if (!userId || !window.pendingFcmToken || !window.supabaseClient) return;
    try {
      await window.supabaseClient.from("device_tokens").upsert(
        { user_id: userId, fcm_token: window.pendingFcmToken, platform: "android" },
        { onConflict: "fcm_token" },
      );
    } catch (e) { /* offline or not logged in yet — safe to ignore */ }
  };

  function registerPush() {
    var PushNotifications = window.Capacitor.Plugins.PushNotifications;
    if (!PushNotifications) return;

    PushNotifications.requestPermissions().then(function (result) {
      if (result.receive !== "granted") return;
      PushNotifications.register();
    });

    PushNotifications.addListener("registration", function (token) {
      window.pendingFcmToken = token.value;
      // If a user is already logged in (app re-opened, not first install),
      // save immediately instead of waiting for the next login.
      var storedUserId = localStorage.getItem("ca_user_id");
      if (storedUserId) window.registerDeviceToken(storedUserId);
    });

    PushNotifications.addListener("registrationError", function () {
      // No token this session — send-notification simply won't reach this
      // device until the next successful registration; nothing else to do.
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (!isNative() || !window.Capacitor.Plugins) return;

    var StatusBar = window.Capacitor.Plugins.StatusBar;
    if (StatusBar) {
      // "Light" style = dark icons/text, correct for our white status bar
      StatusBar.setStyle({ style: "LIGHT" }).catch(function () {});
      StatusBar.setBackgroundColor({ color: "#FFFFFF" }).catch(function () {});
      StatusBar.setOverlaysWebView({ overlay: false }).catch(function () {});
    }

    registerPush();
  });
})();
