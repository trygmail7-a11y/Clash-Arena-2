-- ==========================================================
-- CLASH ARENA — SUPABASE SCHEMA (Phase 2 reference)
-- ==========================================================
-- NOT executed against a live project yet. This file documents the
-- table structure the frontend mock data (js/data.js) is modeled on,
-- so Phase 2 can wire up real Supabase calls without changing the UI.
-- Every table includes fields an Admin Panel will need to manage it.
-- ==========================================================

create extension if not exists "uuid-ossp";

-- ==========================================================
-- AUTO-ID SEQUENCES
-- ==========================================================
-- Public-facing player UID: starts at 100001, then 100002, 100003, ...
-- Assigned automatically the moment a user row is created (i.e. right after
-- signup/login creates their profile) — no app code needs to generate this.
create sequence if not exists public.user_uid_seq start with 100001 increment by 1;

-- Tournament number: starts at 10001, rendered as 'TM10001', 'TM10002', ...
-- Assigned automatically the moment an admin creates a tournament/room.
create sequence if not exists public.tournament_number_seq start with 10001 increment by 1;

-- ---------- AVATARS (built-in only — no uploads) ----------
-- Images live in the app bundle (assets/avatars/avatar01.png ... avatar10.png).
-- Only the avatar_id (e.g. 'avatar_01') is ever stored in the database.
-- Admin Panel can later enable/disable or add rows here without any app code changes.
create table public.avatars (
  id text primary key,                    -- 'avatar_01', 'avatar_02', ...
  file_name text not null,                -- 'avatar01.png' — resolved against local assets/avatars/
  is_active boolean default true,         -- admin can disable an avatar from selection
  sort_order int default 0,
  created_at timestamptz default now()
);

-- Seeded immediately — users.avatar_id below is a foreign key into this
-- table, so signup would fail for everyone until these rows exist.
insert into public.avatars (id, file_name, sort_order) values
  ('avatar_01', 'avatar01.png', 1),
  ('avatar_02', 'avatar02.png', 2),
  ('avatar_03', 'avatar03.png', 3),
  ('avatar_04', 'avatar04.png', 4),
  ('avatar_05', 'avatar05.png', 5),
  ('avatar_06', 'avatar06.png', 6),
  ('avatar_07', 'avatar07.png', 7),
  ('avatar_08', 'avatar08.png', 8),
  ('avatar_09', 'avatar09.png', 9),
  ('avatar_10', 'avatar10.png', 10)
on conflict (id) do nothing;

-- ---------- USERS ----------
create table public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,          -- auto-derived from full_name at signup (lowercase, no spaces) — never shown as a separate "choose a username" step
  full_name text,                         -- the name they typed at signup, shown in Profile
  mobile text,                            -- the mobile number they typed at signup, shown in Profile
  gender text,                            -- null until the person sets it in Edit Profile ('Not Set' shown in the app)
  date_of_birth date,                     -- null until the person sets it in Edit Profile ('Not Set' shown in the app)
  uid text unique,                        -- public-facing player ID, auto-filled by trigger below (100001, 100002, ...)
  avatar_id text references public.avatars(id) default 'avatar_01',
  is_banned boolean default false,        -- admin control
  is_verified boolean default false,
  referral_code text unique,
  referred_by uuid references public.users(id),
  created_at timestamptz default now()
);

-- Auto-assign the next UID (100001, 100002, ...) the moment a user profile
-- row is inserted — i.e. right when someone signs up / logs in for the first
-- time and their `public.users` row gets created. The app never has to send
-- a uid; this fills it in automatically and it never repeats.
create or replace function public.assign_user_uid()
returns trigger as $$
begin
  if new.uid is null then
    new.uid := nextval('public.user_uid_seq')::text;
  end if;
  -- Auto-generate a referral code from the UID + 2 random uppercase letters
  -- (e.g. '100001XQ'), so users never have to invent or type one themselves.
  if new.referral_code is null then
    new.referral_code := new.uid ||
      chr(65 + floor(random() * 26)::int) ||
      chr(65 + floor(random() * 26)::int);
  end if;
  return new;
end;
$$ language plpgsql;

create trigger trg_assign_user_uid
before insert on public.users
for each row execute function public.assign_user_uid();

-- ---------- WALLET ----------
create table public.wallets (
  user_id uuid primary key references public.users(id) on delete cascade,
  winning_balance numeric default 0,
  bonus_balance numeric default 0,
  cash_balance numeric default 0,
  updated_at timestamptz default now()
);

-- ---------- SAVED BANK ACCOUNT (for Bank Transfer withdrawals) ----------
-- One saved account per user, entered once via the app's "Add Bank Details"
-- form and reused for future bank withdrawals until the user changes it.
create table public.saved_bank_accounts (
  user_id uuid primary key references public.users(id) on delete cascade,
  bank_name text not null,
  account_no text not null,
  ifsc text not null,
  updated_at timestamptz default now()
);

-- ---------- COIN TRANSACTIONS ----------
create table public.coin_transactions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade,
  type text not null,                     -- 'join','winning','add_money','referral','withdraw','admin_adjust'
  amount numeric not null,                -- negative for debits
  balance_type text default 'winning',    -- which balance it affects
  reference_id uuid,                      -- links to tournament/payment/withdrawal
  note text,
  created_at timestamptz default now()
);

-- ---------- PAYMENTS (Zap UPI) ----------
-- Renamed from a Cashfree-only shape to a generic one since the app now uses
-- Zap for UPI collect payments. `gateway_order_id` stores the order/txn ID
-- Zap gives you when the payment is created; `utr_number` stores the bank's
-- UPI reference number once it's paid — this is what support looks up first
-- when a user says "I paid but coins didn't come" (UTR is on their bank/UPI
-- app's payment screen, so it's easy for them to share).
create table public.payments (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade,
  gateway text default 'zap_upi',          -- which payment gateway handled this ('zap_upi', future ones if added)
  gateway_order_id text unique,            -- order/txn ID returned by Zap when the payment session is created
  utr_number text,                         -- UPI bank reference number (UTR), captured from Zap's webhook/status response once paid
  amount numeric not null,
  status text default 'pending',          -- 'pending','success','failed'
  method text default 'upi',              -- upi/card/netbanking/wallet (mostly 'upi' with Zap)
  created_at timestamptz default now(),
  verified_at timestamptz
);

create index if not exists idx_payments_utr on public.payments (utr_number);

-- ---------- WITHDRAWALS ----------
-- Reporting window (enforced in the support flow, not the DB itself):
--   UPI / PhonePe / Paytm / Google Pay: raise a ticket if unpaid after 48 hours.
--   Bank transfer: raise a ticket if unpaid after 4 working days.
-- bank_details_snapshot captures the account used for THIS withdrawal so it's
-- never lost even if the user later changes/clears their saved bank details;
-- the Admin Panel should null this out once a bank payout is marked completed,
-- so sensitive account numbers aren't retained longer than necessary.
create table public.withdrawals (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade,
  amount numeric not null,
  destination_type text not null,         -- 'upi','bank','paytm','phonepe','gpay'
  destination_value text not null,
  bank_details_snapshot jsonb,            -- {bank_name, account_no, ifsc} for bank transfers only; cleared after payout
  status text default 'pending',          -- 'pending','processing','completed','rejected' (admin sets this)
  admin_note text,
  created_at timestamptz default now(),
  processed_at timestamptz
);

-- ---------- TOURNAMENTS ----------
-- tournament_number is an auto-generated human-readable ID (e.g. 'TM10045') the
-- Admin Panel can look up to instantly pull a tournament's full details. Match
-- records are expected to stay queryable for at least 3 days after the match
-- ends (support/dispute window) even after the tournament itself is archived.
create table public.tournaments (
  id uuid primary key default uuid_generate_v4(),
  tournament_number text unique,          -- auto-generated on insert, e.g. 'TM10045' (see trigger below)
  name text not null,
  category text not null,                 -- 'Classic Squad','Clash Squad','Battle Royale','Lone Wolf','Solo','Duo'
  banner_url text,
  entry_fee numeric not null,
  prize_pool numeric not null,
  per_kill_reward numeric default 0,
  map text,
  mode text,
  team_type text,
  version text,
  room_type text default 'Custom',
  max_slots int not null,
  registration_ends_at timestamptz not null,
  match_starts_at timestamptz,
  rules text,
  status text default 'upcoming',         -- 'upcoming','live','completed','cancelled' (admin controlled)
  is_full boolean default false,          -- auto-flips to true the moment joined players hit max_slots (see trigger below)
  created_by uuid references public.users(id),
  created_at timestamptz default now()
);

-- Auto-generate tournament_number ('TM10001', 'TM10002', ...) the moment the
-- admin creates a tournament/room in the app — the app never has to send one,
-- and this is the ID support can look up in Supabase to find full details
-- when a user reports a problem.
create or replace function public.assign_tournament_number()
returns trigger as $$
begin
  if new.tournament_number is null then
    new.tournament_number := 'TM' || nextval('public.tournament_number_seq')::text;
  end if;
  return new;
end;
$$ language plpgsql;

create trigger trg_assign_tournament_number
before insert on public.tournaments
for each row execute function public.assign_tournament_number();

-- ---------- TOURNAMENT ROOMS ----------
-- room_id/room_password are only released 2-5 minutes before match start (set
-- by the admin). The app reveals a "View Room Password" button in Match
-- Details once released_at has passed, instead of showing them up front.
create table public.tournament_rooms (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  room_id text,                           -- in-game room ID (admin sets before match)
  room_password text,
  released_at timestamptz
);

-- ---------- PARTICIPANTS ----------
create table public.participants (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  team_name text,
  game_uid text not null,                 -- player's in-game Free Fire UID, so admin can match them inside the room
  game_name text not null,                -- player's in-game name (IGN), shown alongside UID for matching
  joined_at timestamptz default now(),
  unique(tournament_id, user_id)
);

-- Auto-flip tournaments.is_full to true the moment joined-player count hits
-- max_slots (room shows "Full" in the app), and back to false if a slot opens
-- up again (someone leaves / a join is cancelled). Fires on join and on leave.
create or replace function public.refresh_tournament_full_status()
returns trigger as $$
declare
  target_tournament uuid := coalesce(new.tournament_id, old.tournament_id);
  joined_count int;
  slot_limit int;
begin
  select count(*) into joined_count from public.participants where tournament_id = target_tournament;
  select max_slots into slot_limit from public.tournaments where id = target_tournament;

  update public.tournaments
  set is_full = (joined_count >= slot_limit)
  where id = target_tournament;

  return null;
end;
$$ language plpgsql;

create trigger trg_participants_full_after_join
after insert on public.participants
for each row execute function public.refresh_tournament_full_status();

create trigger trg_participants_full_after_leave
after delete on public.participants
for each row execute function public.refresh_tournament_full_status();

-- ---------- MATCH RESULTS ----------
create table public.match_results (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  rank int,
  kills int default 0,
  prize_won numeric default 0,
  status text default 'ongoing',          -- 'ongoing','completed','cancelled'
  updated_by uuid references public.users(id), -- admin who entered result
  created_at timestamptz default now()
);

-- ---------- NOTIFICATIONS ----------
create table public.notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade, -- null = broadcast to all
  title text not null,
  body text not null,
  type text default 'announcement',       -- 'tournament_reminder','match_started','match_result','coin_added','withdrawal_update','announcement'
  is_read boolean default false,
  created_at timestamptz default now()
);

-- ---------- REDEEM CODES ----------
create table public.redeem_codes (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  reward_coins numeric default 0,
  max_uses int default 1,
  used_count int default 0,
  expires_at timestamptz,
  created_by uuid references public.users(id),
  created_at timestamptz default now()
);

create table public.redeem_code_uses (
  id uuid primary key default uuid_generate_v4(),
  code_id uuid references public.redeem_codes(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  used_at timestamptz default now(),
  unique(code_id, user_id)
);

-- ---------- GIVEAWAYS ----------
create table public.giveaways (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  banner_url text,
  reward_description text,
  ends_at timestamptz not null,
  status text default 'active',           -- 'active','ended' (admin controlled)
  created_at timestamptz default now()
);

create table public.giveaway_entries (
  id uuid primary key default uuid_generate_v4(),
  giveaway_id uuid references public.giveaways(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  entered_at timestamptz default now(),
  is_winner boolean default false,
  unique(giveaway_id, user_id)
);

-- ---------- REFERRALS ----------
create table public.referrals (
  id uuid primary key default uuid_generate_v4(),
  referrer_id uuid references public.users(id) on delete cascade,
  referred_id uuid references public.users(id) on delete cascade,
  reward_coins numeric default 50,        -- admin-configurable
  created_at timestamptz default now(),
  unique(referred_id)
);

-- ---------- SUPPORT CATEGORIES ----------
-- Backs both the ticket "Category" dropdown and the Quick Help cards.
-- Admin Panel can add/rename/hide categories without touching the schema.
create table public.support_categories (
  id uuid primary key default uuid_generate_v4(),
  key text unique not null,               -- 'payment','coins','tournament','withdrawal','login','redeem_code','account','bug','other'
  label text not null,                    -- 'Payment','Coins',...
  icon text,                              -- emoji or icon key shown on Quick Help card
  is_active boolean default true,
  sort_order int default 0,
  created_at timestamptz default now()
);

-- Seeded immediately — the ticket form's category dropdown looks these up
-- by key, so ticket submission would fail with no categories to match.
insert into public.support_categories (key, label, sort_order) values
  ('payment', 'Payment', 1),
  ('coins', 'Coins', 2),
  ('tournament', 'Tournament', 3),
  ('withdrawal', 'Withdrawal', 4),
  ('login', 'Login', 5),
  ('redeem_code', 'Redeem Code', 6),
  ('account', 'Account', 7),
  ('bug', 'Bug', 8),
  ('other', 'Other', 9)
on conflict (key) do nothing;

-- ---------- SUPPORT TICKETS ----------
create table public.support_tickets (
  id uuid primary key default uuid_generate_v4(),
  ticket_number text unique not null,     -- human-readable ID shown to users, e.g. 'CA-10231'
  user_id uuid references public.users(id) on delete cascade,
  category_id uuid references public.support_categories(id),
  reason text not null,                   -- capped at 10 words client-side
  mobile_number text not null,
  status text default 'open',             -- 'open','in_review','waiting_for_user','resolved','closed' (admin controlled)
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  resolved_at timestamptz
);

-- ---------- SUPPORT REPLIES ----------
-- Thread of replies on a ticket. Currently only admin replies are shown to
-- the user (read-only), but the structure supports multi-message threads later.
create table public.support_replies (
  id uuid primary key default uuid_generate_v4(),
  ticket_id uuid references public.support_tickets(id) on delete cascade,
  sender_type text not null,              -- 'admin' or 'user'
  sender_id uuid,                         -- references users(id) or an admin id
  message text not null,
  created_at timestamptz default now()
);

-- ---------- APP SETTINGS (admin-controlled) ----------
-- Simple key-value config table for Admin Panel toggles. First use: how many
-- days a support ticket is kept before auto-deleting. Admin can change this
-- anytime from the Admin Panel (e.g. '7' for 1 week, '14' for 2 weeks) —
-- no schema change or redeploy needed.
create table public.app_settings (
  key text primary key,
  value text not null,
  updated_at timestamptz default now()
);

insert into public.app_settings (key, value) values ('ticket_retention_days', '7')
on conflict (key) do nothing;

-- Deletes tickets whose status is 'resolved' or 'closed' and which have sat
-- past the admin-configured retention window (counted from resolved_at, or
-- from created_at if resolved_at was never set). support_replies for those
-- tickets are removed automatically via the existing on delete cascade.
create or replace function public.cleanup_old_support_tickets()
returns void as $$
declare
  retention_days int;
begin
  select coalesce(value::int, 7) into retention_days
  from public.app_settings where key = 'ticket_retention_days';

  delete from public.support_tickets
  where status in ('resolved', 'closed')
    and coalesce(resolved_at, updated_at, created_at) < now() - (retention_days || ' days')::interval;
end;
$$ language plpgsql security definer;

-- Runs the cleanup once a day at 3 AM (server time). Requires the `pg_cron`
-- extension, which on Supabase you enable from Dashboard → Database →
-- Extensions → search "pg_cron" → Enable (do this once; the schedule call
-- below only needs to run once too, not on every deploy).
-- create extension if not exists pg_cron;
-- select cron.schedule('cleanup-old-support-tickets', '0 3 * * *', 'select public.cleanup_old_support_tickets();');

-- ---------- FAQ ----------
create table public.faq (
  id uuid primary key default uuid_generate_v4(),
  category_id uuid references public.support_categories(id),
  question text not null,
  answer text not null,
  is_active boolean default true,
  sort_order int default 0,
  created_at timestamptz default now()
);

-- ---------- ANNOUNCEMENTS ----------
create table public.announcements (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  body text not null,
  is_active boolean default true,         -- admin controlled
  created_at timestamptz default now()
);

-- ==========================================================
-- ROW LEVEL SECURITY (enable + baseline policies)
-- Every table: users can only read/write their own rows.
-- Admin role (added in Phase 2) will bypass via service_role or a
-- `is_admin` claim checked in policies.
-- ==========================================================
alter table public.users enable row level security;
alter table public.wallets enable row level security;
alter table public.coin_transactions enable row level security;
alter table public.payments enable row level security;
alter table public.withdrawals enable row level security;
alter table public.participants enable row level security;
alter table public.match_results enable row level security;
alter table public.notifications enable row level security;
alter table public.support_tickets enable row level security;
alter table public.giveaway_entries enable row level security;
alter table public.referrals enable row level security;

create policy "Users read own profile" on public.users for select using (auth.uid() = id);
create policy "Users update own profile" on public.users for update using (auth.uid() = id);

create policy "Users read own wallet" on public.wallets for select using (auth.uid() = user_id);

alter table public.saved_bank_accounts enable row level security;
create policy "Users manage own bank account" on public.saved_bank_accounts for all using (auth.uid() = user_id);
create policy "Users read own transactions" on public.coin_transactions for select using (auth.uid() = user_id);
create policy "Users read own payments" on public.payments for select using (auth.uid() = user_id);
create policy "Users read own withdrawals" on public.withdrawals for select using (auth.uid() = user_id);
create policy "Users insert own withdrawals" on public.withdrawals for insert with check (auth.uid() = user_id);

create policy "Users read own participation" on public.participants for select using (auth.uid() = user_id);
create policy "Users join tournaments" on public.participants for insert with check (auth.uid() = user_id);

create policy "Users read own results" on public.match_results for select using (auth.uid() = user_id);

create policy "Users read own notifications" on public.notifications for select using (auth.uid() = user_id or user_id is null);

create policy "Users manage own tickets" on public.support_tickets for all using (auth.uid() = user_id);

alter table public.support_replies enable row level security;
create policy "Users read replies on own tickets" on public.support_replies
  for select using (
    exists (select 1 from public.support_tickets t where t.id = ticket_id and t.user_id = auth.uid())
  );

alter table public.faq enable row level security;
create policy "Anyone can view active FAQ" on public.faq for select using (is_active = true);

alter table public.support_categories enable row level security;
create policy "Anyone can view active categories" on public.support_categories for select using (is_active = true);

create policy "Users read own giveaway entries" on public.giveaway_entries for select using (auth.uid() = user_id);
create policy "Users enter giveaways" on public.giveaway_entries for insert with check (auth.uid() = user_id);

create policy "Users read own referrals" on public.referrals for select using (auth.uid() = referrer_id);

-- Public read tables (tournaments, giveaways, announcements, redeem_codes list)
-- are intentionally left without RLS restriction on SELECT so all users can browse them.
alter table public.avatars enable row level security;
create policy "Anyone can view active avatars" on public.avatars for select using (is_active = true);

alter table public.tournaments enable row level security;
create policy "Anyone can view tournaments" on public.tournaments for select using (true);

alter table public.giveaways enable row level security;
create policy "Anyone can view giveaways" on public.giveaways for select using (true);

alter table public.announcements enable row level security;
create policy "Anyone can view active announcements" on public.announcements for select using (is_active = true);

-- app_settings is admin-only config (ticket retention days, etc.) — RLS is
-- enabled with NO policies, so regular users get zero access to it; only
-- the service_role (used by the Admin Panel / backend) can read or change it,
-- since service_role always bypasses RLS.
alter table public.app_settings enable row level security;

-- ---------- DEVICE TOKENS (push notifications) ----------
-- Stores each user's FCM device token (their phone's unique push-notification
-- address). A user can have multiple tokens if they use the app on more than
-- one device — each row is one device.
create table public.device_tokens (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade,
  fcm_token text unique not null,
  platform text default 'android',
  updated_at timestamptz default now()
);

alter table public.device_tokens enable row level security;
create policy "Users manage own device token" on public.device_tokens for all using (auth.uid() = user_id);

-- ---------- WALLET CREDIT HELPER (used by the zapupi-webhook Edge Function) ----------
-- Atomically credits a user's cash_balance and logs the coin_transaction in
-- one step, so a payment is never partially applied. Called only after the
-- webhook independently re-confirms the payment succeeded with ZapUPI —
-- never trust a webhook body blindly.
create or replace function public.credit_wallet_from_payment(
  p_user_id uuid,
  p_amount numeric,
  p_order_id text
)
returns void as $$
begin
  update public.wallets
  set cash_balance = cash_balance + p_amount,
      updated_at = now()
  where user_id = p_user_id;

  insert into public.coin_transactions (user_id, type, amount, balance_type, note)
  values (p_user_id, 'add_money', p_amount, 'cash', 'ZapUPI order ' || p_order_id);
end;
$$ language plpgsql security definer;

-- ---------- JOIN TOURNAMENT (atomic, callable via supabase.rpc) ----------
-- Does everything a join needs in one all-or-nothing step: checks the room
-- isn't full, checks the player hasn't already joined, checks they can
-- afford it, deducts the entry fee, and records the participant — all
-- inside one transaction so two rapid taps (or a slow connection) can never
-- double-charge someone or overfill a room. Uses auth.uid() internally
-- instead of trusting a user_id passed from the client, so a player can only
-- ever join as themselves.
create or replace function public.join_tournament(
  p_tournament_id uuid,
  p_game_uid text,
  p_game_name text
)
returns json as $$
declare
  v_user_id uuid := auth.uid();
  v_entry_fee numeric;
  v_max_slots int;
  v_joined_count int;
  v_wallet public.wallets;
begin
  if v_user_id is null then
    return json_build_object('error', 'Not logged in');
  end if;

  select entry_fee, max_slots into v_entry_fee, v_max_slots
  from public.tournaments where id = p_tournament_id;
  if v_entry_fee is null then
    return json_build_object('error', 'Tournament not found');
  end if;

  if exists (select 1 from public.participants where tournament_id = p_tournament_id and user_id = v_user_id) then
    return json_build_object('error', 'You have already joined this tournament');
  end if;

  select count(*) into v_joined_count from public.participants where tournament_id = p_tournament_id;
  if v_joined_count >= v_max_slots then
    return json_build_object('error', 'This room is full');
  end if;

  select * into v_wallet from public.wallets where user_id = v_user_id for update;
  if v_wallet.winning_balance + v_wallet.bonus_balance + v_wallet.cash_balance < v_entry_fee then
    return json_build_object('error', 'Insufficient coin balance');
  end if;

  -- Spend from winning_balance first, then bonus, then cash — most
  -- restricted balance type first.
  declare
    v_remaining numeric := v_entry_fee;
    v_from_winning numeric := least(v_wallet.winning_balance, v_remaining);
  begin
    v_remaining := v_remaining - v_from_winning;
    declare v_from_bonus numeric := least(v_wallet.bonus_balance, v_remaining);
    begin
      v_remaining := v_remaining - v_from_bonus;
      update public.wallets set
        winning_balance = winning_balance - v_from_winning,
        bonus_balance = bonus_balance - v_from_bonus,
        cash_balance = cash_balance - v_remaining,
        updated_at = now()
      where user_id = v_user_id;
    end;
  end;

  insert into public.participants (tournament_id, user_id, game_uid, game_name)
  values (p_tournament_id, v_user_id, p_game_uid, p_game_name);

  insert into public.coin_transactions (user_id, type, amount, balance_type, reference_id, note)
  values (v_user_id, 'join', -v_entry_fee, 'winning', p_tournament_id, 'Joined tournament');

  return json_build_object('success', true);
end;
$$ language plpgsql security definer;

-- ---------- REFERRAL SYSTEM (admin-configurable reward) ----------
insert into public.app_settings (key, value) values ('referral_reward_coins', '50')
on conflict (key) do nothing;

-- Called once, right after a new user finishes email verification, if they
-- entered someone else's referral code at signup. Credits BOTH the referrer
-- and the new player with the current admin-configured reward (read live
-- from app_settings, so changing it in the Admin Panel applies immediately
-- to all future signups — no app update needed).
create or replace function public.apply_referral_code(p_referral_code text)
returns json as $$
declare
  v_new_user_id uuid := auth.uid();
  v_referrer_id uuid;
  v_reward numeric;
begin
  if v_new_user_id is null then
    return json_build_object('error', 'Not logged in');
  end if;

  select id into v_referrer_id from public.users where referral_code = p_referral_code;
  if v_referrer_id is null then
    return json_build_object('error', 'Invalid referral code');
  end if;
  if v_referrer_id = v_new_user_id then
    return json_build_object('error', 'You cannot use your own referral code');
  end if;
  if exists (select 1 from public.referrals where referred_id = v_new_user_id) then
    return json_build_object('error', 'Referral already applied');
  end if;

  select coalesce(value::numeric, 50) into v_reward
  from public.app_settings where key = 'referral_reward_coins';

  update public.users set referred_by = v_referrer_id where id = v_new_user_id;

  insert into public.referrals (referrer_id, referred_id, reward_coins)
  values (v_referrer_id, v_new_user_id, v_reward);

  update public.wallets set bonus_balance = bonus_balance + v_reward, updated_at = now() where user_id = v_referrer_id;
  update public.wallets set bonus_balance = bonus_balance + v_reward, updated_at = now() where user_id = v_new_user_id;

  insert into public.coin_transactions (user_id, type, amount, balance_type, note)
  values (v_referrer_id, 'referral', v_reward, 'bonus', 'Referral bonus — invited a new player'),
         (v_new_user_id, 'referral', v_reward, 'bonus', 'Referral bonus — signed up with a referral code');

  return json_build_object('success', true, 'reward', v_reward);
end;
$$ language plpgsql security definer;
