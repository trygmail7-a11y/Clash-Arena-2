// supabase/functions/send-notification/index.ts
//
// Sends a real push notification to a user's phone (or everyone, if user_id
// is left out) using Firebase Cloud Messaging. Call this after inserting a
// row into public.notifications — e.g. when admin sends an announcement, or
// a match result is declared.
//
// Required secret (Supabase Dashboard -> Edge Functions -> Secrets):
//   FIREBASE_SERVICE_ACCOUNT = the ENTIRE content of the service account
//   JSON file you downloaded from Google Cloud, pasted as-is (it's valid
//   JSON, so paste the whole { ... } as the secret value).

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { SignJWT, importPKCS8 } from "npm:jose@5";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const FIREBASE_SERVICE_ACCOUNT = Deno.env.get("FIREBASE_SERVICE_ACCOUNT")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    // Only a logged-in admin may trigger a push notification. Without this
    // check, anyone who has the public anon key (which is meant to be
    // public) could call this function directly and spam any user — or
    // every user at once — with fake push notifications.
    const jwt = req.headers.get("Authorization")?.replace("Bearer ", "");
    if (!jwt) {
      return new Response(JSON.stringify({ error: "Missing Authorization header" }), { status: 401, headers: corsHeaders });
    }
    const { data: { user: caller }, error: authErr } = await supabase.auth.getUser(jwt);
    if (authErr || !caller) {
      return new Response(JSON.stringify({ error: "Invalid or expired session" }), { status: 401, headers: corsHeaders });
    }
    const { data: callerProfile } = await supabase.from("users").select("is_admin").eq("id", caller.id).single();
    if (!callerProfile || !callerProfile.is_admin) {
      return new Response(JSON.stringify({ error: "Admin access required" }), { status: 403, headers: corsHeaders });
    }

    const { user_id, title, body, data, image_url } = await req.json();
    // user_id omitted/null = send to every registered device (broadcast)

    if (!title || !body) {
      return new Response(JSON.stringify({ error: "title and body are required" }), { status: 400, headers: corsHeaders });
    }

    const sa = JSON.parse(FIREBASE_SERVICE_ACCOUNT);

    // Step 1: build a short-lived signed JWT proving we own this service account
    const privateKey = await importPKCS8(sa.private_key, "RS256");
    const now = Math.floor(Date.now() / 1000);
    const assertion = await new SignJWT({ scope: "https://www.googleapis.com/auth/firebase.messaging" })
      .setProtectedHeader({ alg: "RS256", typ: "JWT" })
      .setIssuedAt(now)
      .setExpirationTime(now + 3600)
      .setIssuer(sa.client_email)
      .setSubject(sa.client_email)
      .setAudience("https://oauth2.googleapis.com/token")
      .sign(privateKey);

    // Step 2: exchange that JWT for a real Google OAuth access token
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion,
      }),
    });
    const { access_token } = await tokenRes.json();
    if (!access_token) {
      return new Response(JSON.stringify({ error: "Could not authenticate with Firebase" }), { status: 500, headers: corsHeaders });
    }

    // Step 3: find which device(s) to notify
    let query = supabase.from("device_tokens").select("fcm_token");
    if (user_id) query = query.eq("user_id", user_id);
    const { data: tokens } = await query;

    // Step 4: send one FCM message per device token
    const results = [];
    for (const row of tokens ?? []) {
      const fcmRes = await fetch(
        `https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`,
        {
          method: "POST",
          headers: { Authorization: `Bearer ${access_token}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            message: {
              token: row.fcm_token,
              // `image` here is the field FCM actually reads to auto-render
              // a picture in the notification (previously `image_url` was
              // accepted from the admin panel but never placed anywhere in
              // this payload, so it was silently dropped).
              notification: { title, body, ...(image_url ? { image: image_url } : {}) },
              data: data || {},
            },
          }),
        },
      );
      results.push(await fcmRes.json());
    }

    return new Response(JSON.stringify({ sent: results.length, results }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500, headers: corsHeaders });
  }
});
