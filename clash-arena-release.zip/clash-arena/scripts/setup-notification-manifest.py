#!/usr/bin/env python3
"""
Adds the AndroidManifest.xml <meta-data> entries Firebase Cloud Messaging
needs to safely build and display a notification.

Without these, the very first push notification that arrives (including an
automatic one Firebase sometimes sends right after a device registers) can
crash the app — Android tries to build the notification with no default
channel/icon to fall back on and throws a Resources$NotFoundException.

Also copies a proper white-silhouette notification icon into the Android
project. Android notification icons MUST be a plain white shape on a
transparent background — pointing this at the regular full-color launcher
icon (@mipmap/ic_launcher) is a common mistake that makes the notification
icon show up blank/invisible in the status bar and notification shade,
even though everything else about the notification works fine.

Must run AFTER `npx cap sync android` (so AndroidManifest.xml exists with
its final merged content) and BEFORE the Gradle build step.
"""
import re
import shutil
import os

manifest_path = "android/app/src/main/AndroidManifest.xml"
with open(manifest_path, "r") as f:
    content = f.read()

# Android 13+ requires this permission to be explicitly declared before the
# app can even ask the user for notification permission at runtime.
permission_line = '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n'
if "POST_NOTIFICATIONS" not in content:
    match = re.search(r"<manifest[^>]*>", content)
    if match:
        insert_pos = match.end()
        content = content[:insert_pos] + "\n" + permission_line + content[insert_pos:]
        print(f"Added POST_NOTIFICATIONS permission to {manifest_path}")
    else:
        print(f"WARNING: could not find <manifest> tag in {manifest_path}")
else:
    print(f"POST_NOTIFICATIONS permission already present in {manifest_path}")

meta_data_block = """        <meta-data
            android:name="com.google.firebase.messaging.default_notification_channel_id"
            android:value="default_channel" />
        <meta-data
            android:name="com.google.firebase.messaging.default_notification_icon"
            android:resource="@drawable/ic_stat_notify" />
"""

if "default_notification_channel_id" not in content:
    # Insert right after the opening <application ...> tag (before its first child).
    match = re.search(r"<application[^>]*>", content)
    if match:
        insert_pos = match.end()
        content = content[:insert_pos] + "\n" + meta_data_block + content[insert_pos:]
        print(f"Added FCM notification meta-data to {manifest_path}")
    else:
        print(f"WARNING: could not find <application> tag in {manifest_path}")
else:
    print(f"FCM notification meta-data already present in {manifest_path}")

# Single write at the end covers both changes above, regardless of which
# ones actually applied.
with open(manifest_path, "w") as f:
    f.write(content)

# Copy the pre-generated white silhouette icon into each density folder.
source_root = "resources/notification-icons"
dest_root = "android/app/src/main/res"
if os.path.isdir(source_root):
    for density_folder in os.listdir(source_root):
        src_file = os.path.join(source_root, density_folder, "ic_stat_notify.png")
        if os.path.isfile(src_file):
            dest_dir = os.path.join(dest_root, density_folder)
            os.makedirs(dest_dir, exist_ok=True)
            shutil.copy(src_file, os.path.join(dest_dir, "ic_stat_notify.png"))
    print("Copied notification icon into all density folders")
else:
    print(f"WARNING: {source_root} not found — notification icon not copied")

