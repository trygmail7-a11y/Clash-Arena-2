#!/usr/bin/env python3
"""
Forces Firebase to actually initialize by explicitly calling
FirebaseApp.initializeApp() in MainActivity.java's onCreate().

Root cause found from a real device crash log:
  "java.lang.IllegalStateException: Default FirebaseApp is not initialized
   in this process com.clasharena.app."
This happened the moment push notification registration ran, right after
the user granted the permission. Normally, placing google-services.json +
applying the google-services Gradle plugin is enough — Firebase auto-
initializes itself via a ContentProvider before anything else runs. Since
that clearly isn't happening reliably here, this script stops relying on
that automatic mechanism and forces it explicitly instead, which always
works regardless of why the automatic path was failing.

Must run AFTER `npx cap add android` (so MainActivity.java exists) and
AFTER google-services.json has been placed, but BEFORE the Gradle build step.
"""
import re
import glob

# MainActivity.java's path depends on the app's package name
# (com.clasharena.app -> .../java/com/clasharena/app/MainActivity.java) —
# find it rather than hardcoding the path, so this survives a package
# name change too.
matches = glob.glob("android/app/src/main/java/**/MainActivity.java", recursive=True)
if not matches:
    print("WARNING: MainActivity.java not found — skipping Firebase init patch")
else:
    path = matches[0]
    with open(path, "r") as f:
        content = f.read()

    if "FirebaseApp.initializeApp" in content:
        print(f"Firebase init already present in {path}")
    else:
        # 1. Add the import, right after the package declaration.
        content = re.sub(
            r"(package [\w.]+;\n)",
            r"\1\nimport com.google.firebase.FirebaseApp;\n",
            content,
            count=1,
        )

        if "onCreate" in content:
            # 2a. An onCreate() already exists — call FirebaseApp.initializeApp()
            # as the very first line inside it.
            content = re.sub(
                r"(protected void onCreate\(Bundle savedInstanceState\)\s*\{)",
                r"\1\n        FirebaseApp.initializeApp(this);",
                content,
                count=1,
            )
            # Make sure Bundle is imported (onCreate's signature needs it).
            if "import android.os.Bundle;" not in content:
                content = content.replace(
                    "import com.google.firebase.FirebaseApp;",
                    "import android.os.Bundle;\nimport com.google.firebase.FirebaseApp;",
                    1,
                )
        else:
            # 2b. No onCreate() override in the default template — add one.
            content = content.replace(
                "import com.google.firebase.FirebaseApp;",
                "import android.os.Bundle;\nimport com.google.firebase.FirebaseApp;",
                1,
            )
            content = re.sub(
                r"(public class MainActivity extends BridgeActivity\s*\{)",
                r"""\1
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FirebaseApp.initializeApp(this);
        super.onCreate(savedInstanceState);
    }
""",
                content,
                count=1,
            )

        with open(path, "w") as f:
            f.write(content)
        print(f"Added explicit FirebaseApp.initializeApp() to {path}")

# ---------- Add the compile-time Firebase dependency ----------
# Even with google-services.json in place, our own MainActivity.java
# couldn't find the FirebaseApp class at all when compiling — Capacitor's
# push-notifications plugin depends on Firebase internally, but that
# doesn't automatically make it visible to our own app-level Java code.
# This adds it explicitly so `import com.google.firebase.FirebaseApp;`
# actually resolves.
app_gradle_path = "android/app/build.gradle"
with open(app_gradle_path, "r") as f:
    app_content = f.read()

firebase_dep_marker = "fix-firebase-init.py (dependency)"
if firebase_dep_marker not in app_content:
    app_content += f"""
// --- Firebase compile dependency (added by scripts/{firebase_dep_marker}) ---
dependencies {{
    implementation platform('com.google.firebase:firebase-bom:33.1.2')
    implementation 'com.google.firebase:firebase-messaging'
}}
"""
    with open(app_gradle_path, "w") as f:
        f.write(app_content)
    print(f"Added Firebase BOM + messaging dependency to {app_gradle_path}")
else:
    print(f"Firebase dependency already present in {app_gradle_path}")
