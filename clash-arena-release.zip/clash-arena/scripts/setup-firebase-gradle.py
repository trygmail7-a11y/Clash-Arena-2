#!/usr/bin/env python3
"""
Wires up the Google Services (Firebase) Gradle plugin, which
@capacitor/push-notifications needs to actually read google-services.json.

Without this, having google-services.json present is not enough — Firebase
fails to initialize at runtime and the app crashes immediately on launch
(force-closes right after the splash screen).

Must run AFTER `npx cap add android` (so these gradle files exist) and
AFTER google-services.json has been placed in android/app/, but BEFORE the
Gradle build step.
"""
import re

# ---------- 1. Project-level android/build.gradle ----------
# Add the google-services classpath to the existing buildscript dependencies block.
project_gradle_path = "android/build.gradle"
with open(project_gradle_path, "r") as f:
    content = f.read()

classpath_line = "        classpath 'com.google.gms:google-services:4.4.2'\n"

if "com.google.gms:google-services" not in content:
    # Insert right after the FIRST "dependencies {" that appears after
    # "buildscript {" — using DOTALL + non-greedy so nested braces (like the
    # "repositories { ... }" block that normally comes first) don't break the match.
    match = re.search(r"buildscript\s*\{.*?dependencies\s*\{", content, re.DOTALL)
    if match:
        insert_pos = match.end()
        content = content[:insert_pos] + "\n" + classpath_line + content[insert_pos:]
        with open(project_gradle_path, "w") as f:
            f.write(content)
        print(f"Added google-services classpath to {project_gradle_path}")
    else:
        print(f"WARNING: could not find buildscript dependencies block in {project_gradle_path}")
else:
    print(f"google-services classpath already present in {project_gradle_path}")

# ---------- 2. App-level android/app/build.gradle ----------
# Apply the google-services plugin at the bottom of the file.
app_gradle_path = "android/app/build.gradle"
with open(app_gradle_path, "r") as f:
    app_content = f.read()

apply_line = "\napply plugin: 'com.google.gms.google-services'\n"

if "com.google.gms.google-services" not in app_content:
    app_content += apply_line
    with open(app_gradle_path, "w") as f:
        f.write(app_content)
    print(f"Added apply plugin line to {app_gradle_path}")
else:
    print(f"google-services plugin already applied in {app_gradle_path}")
