// supabase/functions/zapupi-webhook/index.ts
//
// ZapUPI calls this URL automatically the moment a payment succeeds/fails.
// For safety, it does NOT trust the webhook body blindly — it re-checks the
// order status directly with ZapUPI's own API before crediting any coins,
// so a fake/spoofed webhook call can never credit a wallet.
//
// Required secret (same as create-payment): ZAP_KEY

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ZAP_KEY = Deno.env.get("ZAP_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

serve(async (req) => {
  const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

  try {
    const body = await req.json();
    const order_id = body.order_id;
    if (!order_id) return new Response(JSON.stringify({ status: "ignored" }), { status: 200 });

    // Re-verify with ZapUPI directly instead of trusting the webhook payload as-is
    const checkRes = await fetch("https://pay.zapupi.com/api/order-status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ zap_key: ZAP_KEY, order_id }),
    });
    const checkData = await checkRes.json();
    const d = checkData.data;
    if (!d) return new Response(JSON.stringify({ status: "ignored" }), { status: 200 });

    const { data: payment } = await supabase
      .from("payments")
      .select("*")
      .eq("gateway_order_id", order_id)
      .single();

    if (!payment) return new Response(JSON.stringify({ status: "ignored" }), { status: 200 });
    if (payment.status === "success") {
      // Already credited earlier — never credit twice for the same order
      return new Response(JSON.stringify({ status: "ok" }), { status: 200 });
    }

    if (d.status === "Success") {
      await supabase
        .from("payments")
        .update({ status: "success", utr_number: d.utr, verified_at: new Date().toISOString() })
        .eq("gateway_order_id", order_id);

      // Atomically credit the wallet + log the transaction (see SQL function below)
      await supabase.rpc("credit_wallet_from_payment", {
        p_user_id: payment.user_id,
        p_amount: payment.amount,
        p_order_id: order_id,
      });
    } else if (d.status === "Failed") {
      await supabase.from("payments").update({ status: "failed" }).eq("gateway_order_id", order_id);
    }
    // If still "Pending", do nothing — ZapUPI will call again on the next status change

    return new Response(JSON.stringify({ status: "ok" }), { status: 200 });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});
