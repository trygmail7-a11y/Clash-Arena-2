// Initializes the Supabase client used across the whole app.
// SUPABASE_URL / SUPABASE_ANON_KEY are safe to keep in client code —
// they are public identifiers, not secrets (Row Level Security in the
// database is what actually protects the data).

const SUPABASE_URL = "https://byxtpznjawxpiqnvebnm.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_gqpHmF1RoFePOiwEol74kg_KH4k-Pnw";

// `supabase` (the UMD global from the CDN script) creates the client here;
// we store it as `window.supabaseClient` so every other script file can use it.
window.supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
