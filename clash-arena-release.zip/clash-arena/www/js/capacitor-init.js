/**
 * CAPACITOR NATIVE BOOTSTRAP
 * --------------------------------------------------
 * Runs only when the app is actually running inside the native Capacitor
 * shell (Android APK) — completely inert in a plain browser tab, so it's
 * safe to leave in place for local testing too.
 *
 * What it does:
 *  1. Forces the Android status bar (where the clock/battery show) to a
 *     white background with dark icons, matching the app's white theme.
 *  2. Exposes window.registerPushIfNative() to register this device for
 *     push notifications (Firebase Cloud Messaging) and save its token to
 *     Supabase — called from app.js's afterAuthSuccess(), i.e. only AFTER
 *     a real login, not automatically on cold start. Requesting
 *     notification permission before the app/webview has even finished
 *     settling in is a common crash cause on some Android versions, so
 *     this is deliberately deferred until there's an actual logged-in
 *     user who needs a device token.
 *
 * The native splash screen itself (logo + white background, built from
 * resources/splash.png) is now shown and hidden entirely by Capacitor's
 * own launchAutoHide/launchShowDuration config in capacitor.config.json —
 * deliberately NOT depending on this JS file running successfully to hide
 * it, so a slow-loading WebView can never leave the splash stuck on screen.
 */
(function () {
  function isNative() {
    return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  }

  // Holds the FCM token once the device registers, in case it arrives
  // before we know which user is logged in.
  window.pendingFcmToken = null;
  var pushRegistrationStarted = false;

  // Call this once you know the logged-in user's id (right after a
  // successful login/signup). Saves whatever token we currently have —
  // if push registration hasn't finished yet, it saves nothing and that's
  // fine, since the "registration" listener below will also try to save
  // once it arrives.
  window.registerDeviceToken = async function (userId) {
    if (!userId || !window.pendingFcmToken || !window.supabaseClient) return;
    try {
      await window.supabaseClient.from("device_tokens").upsert(
        { user_id: userId, fcm_token: window.pendingFcmToken, platform: "android" },
        { onConflict: "fcm_token" },
      );
    } catch (e) { /* offline or not logged in yet — safe to ignore */ }
  };

  // Deliberately NOT called automatically on app launch — only once a real
  // user is logged in (see afterAuthSuccess() in app.js), and only once
  // per app session (pushRegistrationStarted guards against calling this
  // again every time afterAuthSuccess re-runs, e.g. after Save Profile).
  window.registerPushIfNative = function () {
    if (pushRegistrationStarted || !isNative() || !window.Capacitor.Plugins) return;
    var PushNotifications = window.Capacitor.Plugins.PushNotifications;
    if (!PushNotifications) return;
    pushRegistrationStarted = true;

    PushNotifications.requestPermissions().then(function (result) {
      if (result.receive !== "granted") return;
      PushNotifications.register();
    }).catch(function (e) {
      console.error("Push permission request failed:", e);
    });

    PushNotifications.addListener("registration", function (token) {
      window.pendingFcmToken = token.value;
      var storedUserId = localStorage.getItem("ca_user_id");
      if (storedUserId) window.registerDeviceToken(storedUserId);
    });

    PushNotifications.addListener("registrationError", function () {
      // No token this session — send-notification simply won't reach this
      // device until the next successful registration; nothing else to do.
    });
  };

  document.addEventListener("DOMContentLoaded", function () {
    if (!isNative() || !window.Capacitor.Plugins) return;

    var StatusBar = window.Capacitor.Plugins.StatusBar;
    if (StatusBar) {
      // "Light" style = dark icons/text, correct for our white status bar
      StatusBar.setStyle({ style: "LIGHT" }).catch(function () {});
      StatusBar.setBackgroundColor({ color: "#FFFFFF" }).catch(function () {});
      StatusBar.setOverlaysWebView({ overlay: false }).catch(function () {});
    }

    // Hardware/gesture back button: without this, Android's default
    // behavior is to close the app immediately from any screen. Instead,
    // route it through the app's own screen history (same as the on-screen
    // back arrows) — only actually exit once there's nowhere left to go
    // back to. `state` and `goBack` are declared with `let`/`function` in
    // app.js — accessible here as bare identifiers since both files are
    // plain (non-module) scripts sharing one global scope, but NOT via
    // `window.state`, since `let` never attaches to `window`.
    var CapApp = window.Capacitor.Plugins.App;
    if (CapApp) {
      CapApp.addListener("backButton", function () {
        if (typeof state !== "undefined" && state.history && state.history.length > 0) {
          goBack();
        } else {
          CapApp.exitApp();
        }
      });
    }
  });
})();
