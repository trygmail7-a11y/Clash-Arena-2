/**
 * MOCK DATA LAYER
 * --------------------------------------------------
 * This file simulates data that will eventually come from Supabase tables.
 * Every object shape here mirrors the planned DB schema (see /supabase/schema.sql)
 * so that swapping mock arrays for real `supabase.from('table').select()` calls
 * later requires no changes to the render functions in app.js.
 */

const MOCK = {

  user: {
    id: "usr_001",
    username: "Ayan Gamer",
    uid: "348219",
    coin_balance: 2450,
    winning_balance: 1850,
    bonus_balance: 300,
    cash_balance: 300,
    avatar_id: "avatar_01",           // only the ID is stored in the DB — never the image
    tournaments_played: 125,
    wins: 45,
    win_rate: 28
  },

  // 10 built-in local avatars. Only `id` is ever persisted to the database;
  // `file` is resolved client-side to load the matching local asset.
  avatars: [
    { id: "avatar_01", file: "assets/avatars/avatar01.png", enabled: true },
    { id: "avatar_02", file: "assets/avatars/avatar02.png", enabled: true },
    { id: "avatar_03", file: "assets/avatars/avatar03.png", enabled: true },
    { id: "avatar_04", file: "assets/avatars/avatar04.png", enabled: true },
    { id: "avatar_05", file: "assets/avatars/avatar05.png", enabled: true },
    { id: "avatar_06", file: "assets/avatars/avatar06.png", enabled: true },
    { id: "avatar_07", file: "assets/avatars/avatar07.png", enabled: true },
    { id: "avatar_08", file: "assets/avatars/avatar08.png", enabled: true },
    { id: "avatar_09", file: "assets/avatars/avatar09.png", enabled: true },
    { id: "avatar_10", file: "assets/avatars/avatar10.png", enabled: true }
  ],

  // maps to `tournaments` table
  tournaments: [
    { id: "t1", name: "Solo Battle Royale", category: "Battle Royale", type: "Solo", banner_color: "#7b2ff7,#f107a3", entry_fee: 10, prize_pool: 100, joined: 32, slots: 48, countdown: "10m 30s", map: "Bermuda", mode: "Battle Royale", team_type: "Solo (1 Player)", per_kill: 1, version: "Classic", room_type: "Custom", total_teams: "32/48", reg_ends: "00:10:30" },
    { id: "t2", name: "Duo Warrior", category: "Duo", type: "Duo", banner_color: "#0f2027,#2c5364", entry_fee: 20, prize_pool: 200, joined: 24, slots: 50, countdown: "20m 15s", map: "Kalahari", mode: "Duo Clash", team_type: "Duo (2 Players)", per_kill: 1, version: "Classic", room_type: "Custom", total_teams: "24/50", reg_ends: "00:20:15" },
    { id: "t3", name: "Squad Clash", category: "Squad", type: "Squad", banner_color: "#1f1c2c,#928dab", entry_fee: 40, prize_pool: 500, joined: 12, slots: 20, countdown: "30m 45s", map: "Purgatory", mode: "Squad Clash", team_type: "Squad (4 Players)", per_kill: 2, version: "Classic", room_type: "Custom", total_teams: "12/20", reg_ends: "00:30:45" },
    { id: "t4", name: "Clash Squad", category: "Clash Squad", type: "Clash Squad", banner_color: "#232526,#414345", entry_fee: 30, prize_pool: 300, joined: 18, slots: 40, countdown: "45m 10s", map: "Bermuda", mode: "Clash Squad", team_type: "Squad (4 Players)", per_kill: 2, version: "Classic", room_type: "Custom", total_teams: "18/40", reg_ends: "01:15:20" },
    { id: "t5", name: "Solo Clash", category: "Solo", type: "Solo", banner_color: "#3a1c71,#d76d77", entry_fee: 15, prize_pool: 150, joined: 36, slots: 50, countdown: "50m 20s", map: "Alpine", mode: "Solo Clash", team_type: "Solo (1 Player)", per_kill: 1, version: "Classic", room_type: "Custom", total_teams: "36/50", reg_ends: "00:50:20" }
  ],

  // maps to `match_results` joined with `tournament_rooms`
  matches: {
    Ongoing: [
      { id: "m1", name: "Solo Battle", entry: 10, countdown: "10m 30s", rank: "#12", kills: 3 },
      { id: "m2", name: "Duo Warrior", entry: 20, countdown: "20m 15s", rank: "#8", kills: 4 },
      { id: "m3", name: "Squad Clash", entry: 40, countdown: "30m 45s", rank: "#5", kills: 6 },
      { id: "m4", name: "Clash Squad", entry: 30, countdown: "45m 10s", rank: "#10", kills: 2 }
    ],
    Completed: [
      { id: "m5", name: "Duo Warrior", entry: 20, rank: "#2", kills: 8, prize: 150 },
      { id: "m6", name: "Solo Clash", entry: 15, rank: "#1", kills: 11, prize: 150 }
    ],
    Cancelled: [
      { id: "m7", name: "Squad Clash", entry: 40, rank: "-", kills: 0, prize: 0 }
    ]
  },

  // maps to `coin_transactions`
  transactions: [
    { id: "tx1", label: "Tournament Join", date: "24 May, 10:30 AM", amount: -20 },
    { id: "tx2", label: "Tournament Winning", date: "24 May, 08:45 AM", amount: 150 },
    { id: "tx3", label: "Add Money", date: "23 May, 09:20 PM", amount: 100 },
    { id: "tx4", label: "Referral Bonus", date: "22 May, 06:10 PM", amount: 50 },
    { id: "tx5", label: "Tournament Join", date: "21 May, 07:00 PM", amount: -30 },
    { id: "tx6", label: "Withdrawal", date: "20 May, 11:15 AM", amount: -200 }
  ],

  withdrawals: [
    { id: "w1", label: "Withdraw to UPI", date: "18 May, 04:20 PM", amount: -500, status: "Completed" },
    { id: "w2", label: "Withdraw to Bank", date: "10 May, 01:10 PM", amount: -300, status: "Processing" }
  ],

  // maps to `giveaways`
  giveaways: [
    { id: "g1", name: "1000 Diamonds", ends: "Ends in 02d 10h 30m" },
    { id: "g2", name: "Elite Pass", ends: "Ends in 01d 08h 20m" },
    { id: "g3", name: "500 Diamonds", ends: "Ends in 03d 12h 15m" }
  ],

  // maps to `referrals`
  referrals: [
    { id: "r1", label: "Rohit joined using your code", date: "20 May, 2026", amount: 50 },
    { id: "r2", label: "Priya joined using your code", date: "15 May, 2026", amount: 50 }
  ],

  // maps to `notifications`
  notifications: [
    { id: "n1", label: "Tournament Reminder", body: "Squad Clash starts in 30 minutes.", date: "Just now" },
    { id: "n2", label: "Coin Added", body: "₹100 added to your wallet successfully.", date: "2h ago" },
    { id: "n3", label: "Match Result", body: "You ranked #2 in Duo Warrior. +150 coins!", date: "1d ago" },
    { id: "n4", label: "Withdrawal Update", body: "Your withdrawal of ₹500 has been processed.", date: "2d ago" },
    { id: "n5", label: "Announcement", body: "New Battle Royale mode is now live!", date: "3d ago" }
  ],

  // maps to `SupportCategories` — quick help entry cards on Support Center home
  quickHelp: [
    { topic: "payment_failed", icon: "💰", title: "Payment Failed", sub: "Problem with payment" },
    { topic: "coins_not_received", icon: "🪙", title: "Coin Issue", sub: "Coins not added" },
    { topic: "tournament_join", icon: "🎮", title: "Tournament Issue", sub: "Match or join issue" },
    { topic: "withdrawal_issue", icon: "💳", title: "Withdraw Issue", sub: "Withdrawal problems" },
    { topic: "account_issue", icon: "👤", title: "Account Issue", sub: "Login or account help" },
    { topic: "bug_report", icon: "🐞", title: "Report Bug", sub: "Report an error/bug" }
  ],

  // Topic buttons shown at the start of every fresh bot chat
  chatTopics: [
    { topic: "coins_not_received", icon: "🪙", label: "Add Coin Problem" },
    { topic: "payment_failed", icon: "💳", label: "Payment Failed" },
    { topic: "coins_not_received", icon: "❓", label: "Coins Not Received" },
    { topic: "withdrawal_issue", icon: "👛", label: "Withdrawal Status" },
    { topic: "tournament_join", icon: "🎮", label: "Tournament Join Issue" },
    { topic: "account_banned", icon: "🚫", label: "Account Banned" },
    { topic: "prize_not_received", icon: "🏆", label: "Prize Not Received" },
    { topic: "bug_report", icon: "🐞", label: "App Bug" },
    { topic: "login_issue", icon: "🔒", label: "Login Problem" },
    { topic: "contact_human", icon: "🎧", label: "Contact Human Support" }
  ],

  /**
   * SCRIPTED BOT FLOWS
   * Each flow is a small step machine. A step can be:
   *  - text: bot message to show
   *  - buttons: [{label, next}] shown after the text, tapping advances to `next`
   *  - input: {placeholder, next} shows a text field, submitting advances to `next`
   *  - select: {options:[...], next} shows a list to pick from
   *  - end: true marks a terminal step (chat waits for a new topic)
   */
  botFlows: {
    payment_failed: {
      start: "q1",
      steps: {
        q1: { text: "Did your money get deducted?", buttons: [{ label: "Yes", next: "txid" }, { label: "No", next: "no_deduct" }] },
        no_deduct: { text: "No worries — since no money was deducted, please just try the payment again. If it fails again, come back here.", end: true },
        txid: { text: "Please enter your Transaction ID.", input: { placeholder: "Enter Transaction ID", next: "verifying" } },
        verifying: { text: "Your payment is being verified. This usually takes 1–5 minutes. If the payment is successful, coins will be added automatically.", next: "resolved_check" },
        resolved_check: { text: "Is your issue resolved?", buttons: [{ label: "👍 Yes, Resolved", next: "closed" }, { label: "👎 No, Still Issue", next: "escalate" }] },
        closed: { text: "Great! Glad we could help. 🎉", end: true },
        escalate: { text: "I've created a support ticket for our team to look into this personally. You'll get updates in My Tickets.", end: true, createTicket: { category: "Payment", reason: "Payment failed, not resolved by bot" } }
      }
    },
    coins_not_received: {
      start: "q1",
      steps: {
        q1: { text: "Have you completed the payment successfully?", buttons: [{ label: "Yes", next: "txid" }, { label: "No", next: "no_pay" }] },
        no_pay: { text: "Please complete the payment first. If coins still don't appear after that, come back and let me know.", end: true },
        txid: { text: "Please enter your Transaction ID.", input: { placeholder: "Enter Transaction ID", next: "checking" } },
        checking: { text: "We are checking your payment. If payment is successful, coins will automatically be credited.", next: "resolved_check" },
        resolved_check: { text: "Is your issue resolved?", buttons: [{ label: "👍 Yes, Resolved", next: "closed" }, { label: "👎 No, Still Issue", next: "escalate" }] },
        closed: { text: "Awesome, enjoy your coins! 🪙", end: true },
        escalate: { text: "I've raised a support ticket for this. Our team will verify and update you in My Tickets.", end: true, createTicket: { category: "Coins", reason: "Coins not received after payment" } }
      }
    },
    tournament_join: {
      start: "q1",
      steps: {
        q1: { text: "Which tournament are you trying to join?", select: { options: ["Solo Battle Royale", "Duo Warrior", "Squad Clash", "Clash Squad", "Solo Clash"], next: "describe" } },
        describe: { text: "Got it. Please describe your issue in a few words.", input: { placeholder: "e.g. entry fee deducted but not joined", next: "suggest" } },
        suggest: { text: "Thanks — here are a few quick things to check: make sure your coin balance covers the entry fee, and that registration hasn't closed. If it still doesn't work, I'll raise a ticket for the team.", next: "resolved_check" },
        resolved_check: { text: "Is your issue resolved?", buttons: [{ label: "👍 Yes, Resolved", next: "closed" }, { label: "👎 No, Still Issue", next: "escalate" }] },
        closed: { text: "Perfect, good luck in the tournament! 🎮", end: true },
        escalate: { text: "A support ticket has been created. Our team will check your tournament join issue and update you in My Tickets.", end: true, createTicket: { category: "Tournament", reason: "Tournament join issue" } }
      }
    },
    prize_not_received: {
      start: "q1",
      steps: {
        q1: { text: "Please select the completed tournament.", select: { options: ["Duo Warrior", "Solo Clash", "Squad Clash"], next: "verifying" } },
        verifying: { text: "Your reward verification is in progress. This is usually completed within a few hours after the match ends.", next: "resolved_check" },
        resolved_check: { text: "Is your issue resolved?", buttons: [{ label: "👍 Yes, Resolved", next: "closed" }, { label: "👎 No, Still Issue", next: "escalate" }] },
        closed: { text: "Great, congrats on the win! 🏆", end: true },
        escalate: { text: "A support ticket has been created for your prize issue. You'll see updates in My Tickets.", end: true, createTicket: { category: "Tournament", reason: "Prize not received" } }
      }
    },
    withdrawal_issue: {
      start: "q1",
      steps: {
        q1: { text: "Please select your withdrawal request.", select: { options: ["₹500 · 18 May", "₹300 · 10 May"], next: "info" } },
        info: { text: "Withdrawals are processed after admin verification, usually within 24–48 hours.", next: "resolved_check" },
        resolved_check: { text: "Is your issue resolved?", buttons: [{ label: "👍 Yes, Resolved", next: "closed" }, { label: "👎 No, Still Issue", next: "escalate" }] },
        closed: { text: "Thanks for your patience! 💳", end: true },
        escalate: { text: "A support ticket has been created for your withdrawal issue. You'll see updates in My Tickets.", end: true, createTicket: { category: "Withdrawal", reason: "Withdrawal delayed or failed" } }
      }
    },
    login_issue: {
      start: "q1",
      steps: {
        q1: { text: "What kind of login issue are you facing?", select: { options: ["Forgot Password", "OTP Problem", "Account Locked", "Email Verification"], next: "guide" } },
        guide: { text: "Thanks — try resetting your password from the login screen, or requesting a new OTP. If that still doesn't work, I'll get our team to look into your account directly.", next: "resolved_check" },
        resolved_check: { text: "Is your issue resolved?", buttons: [{ label: "👍 Yes, Resolved", next: "closed" }, { label: "👎 No, Still Issue", next: "escalate" }] },
        closed: { text: "You're all set! 🔓", end: true },
        escalate: { text: "A support ticket has been created for your login issue.", end: true, createTicket: { category: "Login", reason: "Login issue unresolved" } }
      }
    },
    account_banned: {
      start: "q1",
      steps: {
        q1: { text: "What account issue are you facing?", select: { options: ["Change Name", "Change Profile", "Delete Account", "Account Restricted"], next: "guide" } },
        guide: { text: "Got it — this needs a manual review by our team. I'll raise a ticket right away.", next: "escalate" },
        escalate: { text: "A support ticket has been created for your account issue. Our team will review and update you in My Tickets.", end: true, createTicket: { category: "Account", reason: "Account issue needs review" } }
      }
    },
    redeem_code: {
      start: "q1",
      steps: {
        q1: { text: "What's happening with your redeem code?", buttons: [{ label: "Invalid Code", next: "invalid" }, { label: "Already Used", next: "used" }, { label: "Expired Code", next: "expired" }] },
        invalid: { text: "Please double check the code for typos — codes are case-sensitive. If it still doesn't work, it may not be a valid code.", end: true },
        used: { text: "Each redeem code can only be used once per account, so it looks like this one's already been redeemed.", end: true },
        expired: { text: "This code has passed its expiry date and can no longer be redeemed. Keep an eye out for new codes in the Giveaway section!", end: true }
      }
    },
    bug_report: {
      start: "q1",
      steps: {
        q1: { text: "Please describe the bug you're facing.", input: { placeholder: "Describe the bug", next: "logged" } },
        logged: { text: "Thanks for reporting this! A support ticket has been created and our team will investigate.", end: true, createTicket: { category: "Bug", reason: "Bug reported via chat" } }
      }
    },
    contact_human: {
      start: "q1",
      steps: {
        q1: { text: "Sure — I'll connect you with our human support team. You can also reach them anytime from the Support Center.", buttons: [{ label: "Go to Contact Us", next: "done", nav: "screen-contact" }] },
        done: { text: "Redirecting you now...", end: true }
      }
    },
    general: {
      start: "q1",
      steps: {
        q1: { text: "I can help right away — please choose a topic below.", end: true }
      }
    }
  },

  // maps to `SupportTickets`
  tickets: [
    { id: "CA-10231", category: "Withdrawal", reason: "Withdrawal delayed for 2 days", mobile: "9876543210", status: "in_review", admin_reply: "", created: "24 May, 2026", updated: "24 May, 2026" },
    { id: "CA-10198", category: "Payment", reason: "Payment failed but amount deducted", mobile: "9876543210", status: "resolved", admin_reply: "Your payment was verified and coins have been credited. Sorry for the delay!", created: "18 May, 2026", updated: "19 May, 2026" }
  ],

  // maps to `FAQ`, grouped by `SupportCategories`
  faq: [
    { category: "Payments", items: [
      { q: "How do I add coins?", a: "Go to Wallet → Add Coins, pick an amount, and pay via UPI, card, or net banking through Cashfree. Coins are credited automatically after payment succeeds." },
      { q: "Payment failed but money deducted", a: "This usually resolves within 1–5 minutes automatically. If it doesn't, use the Support Bot's Payment Failed flow with your Transaction ID." },
      { q: "Coins not added", a: "Check the Support Bot's Coins Not Received flow and share your Transaction ID so we can verify the payment." },
      { q: "Payment pending", a: "Pending payments are usually confirmed within a few minutes. If it stays pending for over 30 minutes, please raise a ticket." }
    ]},
    { category: "Tournament", items: [
      { q: "How to join a tournament?", a: "Open Tournaments, pick one that matches your budget and mode, then tap Join. The entry fee is deducted from your coin balance instantly." },
      { q: "Entry fee deducted but not joined", a: "This can happen due to a network hiccup. Check My Matches first — if it's not listed, use the Tournament Join Issue flow in the Support Bot." },
      { q: "Room ID not received", a: "Room details are released shortly before the match starts. Check Tournament Details or your notifications a few minutes before start time." },
      { q: "Match cancelled", a: "If a match is cancelled by admins, your entry fee is automatically refunded to your wallet." },
      { q: "Rules", a: "Each tournament has its own rules listed on the Tournament Details page — please review them before joining." }
    ]},
    { category: "Withdraw", items: [
      { q: "How to withdraw?", a: "Go to Wallet → Withdraw, enter the amount, choose UPI/Bank/Paytm/PhonePe, and submit your request." },
      { q: "Minimum withdrawal", a: "The minimum withdrawal amount is ₹100 (this may be adjusted from time to time)." },
      { q: "Processing time", a: "Withdrawals are typically processed within 24–48 hours after admin verification." },
      { q: "Withdrawal rejected", a: "Rejections usually happen due to mismatched account details. Check your withdrawal history or raise a ticket for details." }
    ]},
    { category: "Account", items: [
      { q: "Login problem", a: "Try resetting your password. If you still can't log in, use the Login Problem flow in the Support Bot." },
      { q: "Forgot password", a: "Tap Forgot Password on the login screen and follow the reset link sent to your email." },
      { q: "Change profile", a: "You can update your avatar anytime from Profile → tap the edit icon." },
      { q: "Delete account", a: "Contact human support to request account deletion — this is handled manually to keep your data secure." }
    ]},
    { category: "Redeem Codes", items: [
      { q: "How to use?", a: "Go to Giveaway, enter your code in the Redeem Code field, and tap Redeem." },
      { q: "Invalid code", a: "Double check for typos — codes are case-sensitive." },
      { q: "Expired code", a: "Expired codes can no longer be redeemed. Watch the Giveaway section for new ones." }
    ]},
    { category: "Notifications", items: [
      { q: "Tournament reminder", a: "You'll get a push notification shortly before a tournament you've joined begins." },
      { q: "Winning notification", a: "You're notified as soon as match results are finalized and prizes are credited." },
      { q: "Coin credit notification", a: "You'll be notified every time coins are added to your wallet, whether from a payment, referral, or winnings." }
    ]}
  ]
};

// expose for app.js
window.MOCK = MOCK;
