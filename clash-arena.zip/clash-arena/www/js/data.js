/**
 * MOCK DATA LAYER
 * --------------------------------------------------
 * This file simulates data that will eventually come from Supabase tables.
 * Every object shape here mirrors the planned DB schema (see /supabase/schema.sql)
 * so that swapping mock arrays for real `supabase.from('table').select()` calls
 * later requires no changes to the render functions in app.js.
 */

const MOCK = {

  user: {
    id: "usr_001",
    username: "Ayan Gamer",
    uid: "348219",
    coin_balance: 2450,
    winning_balance: 1850,
    bonus_balance: 300,
    cash_balance: 300,
    avatar_url: "https://api.dicebear.com/7.x/adventurer/svg?seed=Ayan",
    tournaments_played: 125,
    wins: 45,
    win_rate: 28
  },

  // maps to `tournaments` table
  tournaments: [
    { id: "t1", name: "Solo Battle Royale", category: "Battle Royale", type: "Solo", banner_color: "#7b2ff7,#f107a3", entry_fee: 10, prize_pool: 100, joined: 32, slots: 48, countdown: "10m 30s", map: "Bermuda", mode: "Battle Royale", team_type: "Solo (1 Player)", per_kill: 1, version: "Classic", room_type: "Custom", total_teams: "32/48", reg_ends: "00:10:30" },
    { id: "t2", name: "Duo Warrior", category: "Duo", type: "Duo", banner_color: "#0f2027,#2c5364", entry_fee: 20, prize_pool: 200, joined: 24, slots: 50, countdown: "20m 15s", map: "Kalahari", mode: "Duo Clash", team_type: "Duo (2 Players)", per_kill: 1, version: "Classic", room_type: "Custom", total_teams: "24/50", reg_ends: "00:20:15" },
    { id: "t3", name: "Squad Clash", category: "Squad", type: "Squad", banner_color: "#1f1c2c,#928dab", entry_fee: 40, prize_pool: 500, joined: 12, slots: 20, countdown: "30m 45s", map: "Purgatory", mode: "Squad Clash", team_type: "Squad (4 Players)", per_kill: 2, version: "Classic", room_type: "Custom", total_teams: "12/20", reg_ends: "00:30:45" },
    { id: "t4", name: "Clash Squad", category: "Clash Squad", type: "Clash Squad", banner_color: "#232526,#414345", entry_fee: 30, prize_pool: 300, joined: 18, slots: 40, countdown: "45m 10s", map: "Bermuda", mode: "Clash Squad", team_type: "Squad (4 Players)", per_kill: 2, version: "Classic", room_type: "Custom", total_teams: "18/40", reg_ends: "01:15:20" },
    { id: "t5", name: "Solo Clash", category: "Solo", type: "Solo", banner_color: "#3a1c71,#d76d77", entry_fee: 15, prize_pool: 150, joined: 36, slots: 50, countdown: "50m 20s", map: "Alpine", mode: "Solo Clash", team_type: "Solo (1 Player)", per_kill: 1, version: "Classic", room_type: "Custom", total_teams: "36/50", reg_ends: "00:50:20" }
  ],

  // maps to `match_results` joined with `tournament_rooms`
  matches: {
    Ongoing: [
      { id: "m1", name: "Solo Battle", entry: 10, countdown: "10m 30s", rank: "#12", kills: 3 },
      { id: "m2", name: "Duo Warrior", entry: 20, countdown: "20m 15s", rank: "#8", kills: 4 },
      { id: "m3", name: "Squad Clash", entry: 40, countdown: "30m 45s", rank: "#5", kills: 6 },
      { id: "m4", name: "Clash Squad", entry: 30, countdown: "45m 10s", rank: "#10", kills: 2 }
    ],
    Completed: [
      { id: "m5", name: "Duo Warrior", entry: 20, rank: "#2", kills: 8, prize: 150 },
      { id: "m6", name: "Solo Clash", entry: 15, rank: "#1", kills: 11, prize: 150 }
    ],
    Cancelled: [
      { id: "m7", name: "Squad Clash", entry: 40, rank: "-", kills: 0, prize: 0 }
    ]
  },

  // maps to `coin_transactions`
  transactions: [
    { id: "tx1", label: "Tournament Join", date: "24 May, 10:30 AM", amount: -20 },
    { id: "tx2", label: "Tournament Winning", date: "24 May, 08:45 AM", amount: 150 },
    { id: "tx3", label: "Add Money", date: "23 May, 09:20 PM", amount: 100 },
    { id: "tx4", label: "Referral Bonus", date: "22 May, 06:10 PM", amount: 50 },
    { id: "tx5", label: "Tournament Join", date: "21 May, 07:00 PM", amount: -30 },
    { id: "tx6", label: "Withdrawal", date: "20 May, 11:15 AM", amount: -200 }
  ],

  withdrawals: [
    { id: "w1", label: "Withdraw to UPI", date: "18 May, 04:20 PM", amount: -500, status: "Completed" },
    { id: "w2", label: "Withdraw to Bank", date: "10 May, 01:10 PM", amount: -300, status: "Processing" }
  ],

  // maps to `giveaways`
  giveaways: [
    { id: "g1", name: "1000 Diamonds", ends: "Ends in 02d 10h 30m" },
    { id: "g2", name: "Elite Pass", ends: "Ends in 01d 08h 20m" },
    { id: "g3", name: "500 Diamonds", ends: "Ends in 03d 12h 15m" }
  ],

  // maps to `referrals`
  referrals: [
    { id: "r1", label: "Rohit joined using your code", date: "20 May, 2026", amount: 50 },
    { id: "r2", label: "Priya joined using your code", date: "15 May, 2026", amount: 50 }
  ],

  // maps to `notifications`
  notifications: [
    { id: "n1", label: "Tournament Reminder", body: "Squad Clash starts in 30 minutes.", date: "Just now" },
    { id: "n2", label: "Coin Added", body: "₹100 added to your wallet successfully.", date: "2h ago" },
    { id: "n3", label: "Match Result", body: "You ranked #2 in Duo Warrior. +150 coins!", date: "1d ago" },
    { id: "n4", label: "Withdrawal Update", body: "Your withdrawal of ₹500 has been processed.", date: "2d ago" },
    { id: "n5", label: "Announcement", body: "New Battle Royale mode is now live!", date: "3d ago" }
  ]
};

// expose for app.js
window.MOCK = MOCK;
