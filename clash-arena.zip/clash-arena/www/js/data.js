/**
 * MOCK DATA LAYER
 * --------------------------------------------------
 * This file simulates data that will eventually come from Supabase tables.
 * Every object shape here mirrors the planned DB schema (see /supabase/schema.sql)
 * so that swapping mock arrays for real `supabase.from('table').select()` calls
 * later requires no changes to the render functions in app.js.
 */

const MOCK = {

  user: {
    id: "usr_001",
    username: "Ayan Gamer",
    uid: "348219",
    referral_code: "348219XQ",  // 6-digit UID + 2 random uppercase letters
    coin_balance: 2450,
    winning_balance: 1850,
    bonus_balance: 300,
    cash_balance: 300,
    savedBank: null,  // { bankName, accountNo, ifsc } — set once the person adds bank details for withdrawals
    avatar_id: "avatar_01",           // only the ID is stored in the DB — never the image
    tournaments_played: 125,
    wins: 45,
    win_rate: 28
  },

  // 10 built-in local avatars. Only `id` is ever persisted to the database;
  // `file` is resolved client-side to load the matching local asset.
  avatars: [
    { id: "avatar_01", file: "assets/avatars/avatar01.png", enabled: true },
    { id: "avatar_02", file: "assets/avatars/avatar02.png", enabled: true },
    { id: "avatar_03", file: "assets/avatars/avatar03.png", enabled: true },
    { id: "avatar_04", file: "assets/avatars/avatar04.png", enabled: true },
    { id: "avatar_05", file: "assets/avatars/avatar05.png", enabled: true },
    { id: "avatar_06", file: "assets/avatars/avatar06.png", enabled: true },
    { id: "avatar_07", file: "assets/avatars/avatar07.png", enabled: true },
    { id: "avatar_08", file: "assets/avatars/avatar08.png", enabled: true },
    { id: "avatar_09", file: "assets/avatars/avatar09.png", enabled: true },
    { id: "avatar_10", file: "assets/avatars/avatar10.png", enabled: true }
  ],

  // maps to `tournaments` table
  tournaments: [
    { id: "t1", name: "Solo Battle Royale", category: "Battle Royale", type: "Solo", banner_color: "#7b2ff7,#f107a3", entry_fee: 10, prize_pool: 100, joined: 32, slots: 48, countdown: "10m 30s", map: "Bermuda", mode: "Battle Royale", team_type: "Solo (1 Player)", per_kill: 1, version: "Classic", room_type: "Custom", total_teams: "32/48", reg_ends: "00:10:30" },
    { id: "t2", name: "Duo Warrior", category: "Duo", type: "Duo", banner_color: "#0f2027,#2c5364", entry_fee: 20, prize_pool: 200, joined: 24, slots: 50, countdown: "20m 15s", map: "Kalahari", mode: "Duo Clash", team_type: "Duo (2 Players)", per_kill: 1, version: "Classic", room_type: "Custom", total_teams: "24/50", reg_ends: "00:20:15" },
    { id: "t3", name: "Squad Clash", category: "Squad", type: "Squad", banner_color: "#1f1c2c,#928dab", entry_fee: 40, prize_pool: 500, joined: 12, slots: 20, countdown: "30m 45s", map: "Purgatory", mode: "Squad Clash", team_type: "Squad (4 Players)", per_kill: 2, version: "Classic", room_type: "Custom", total_teams: "12/20", reg_ends: "00:30:45" },
    { id: "t4", name: "Clash Squad", category: "Clash Squad", type: "Clash Squad", banner_color: "#232526,#414345", entry_fee: 30, prize_pool: 300, joined: 18, slots: 40, countdown: "45m 10s", map: "Bermuda", mode: "Clash Squad", team_type: "Squad (4 Players)", per_kill: 2, version: "Classic", room_type: "Custom", total_teams: "18/40", reg_ends: "01:15:20" },
    { id: "t5", name: "Solo Clash", category: "Solo", type: "Solo", banner_color: "#3a1c71,#d76d77", entry_fee: 15, prize_pool: 150, joined: 36, slots: 50, countdown: "50m 20s", map: "Alpine", mode: "Solo Clash", team_type: "Solo (1 Player)", per_kill: 1, version: "Classic", room_type: "Custom", total_teams: "36/50", reg_ends: "00:50:20" }
  ],

  // maps to `match_results` joined with `tournament_rooms`
  matches: {
    Ongoing: [
      { id: "m1", name: "Solo Battle", entry: 10, countdown: "10m 30s", rank: "#12", kills: 3,
        tournament_id: "#TM10045", room_id: "457812", room_password: "FF2024", team_type: "Squad - FPP", starts_in: "00:15:30",
        date: "26 May 2024", time: "10:00 AM", map: "Bermuda", players: "48 / 48", prize_pool: 100,
        team: [{ name: "Ayan Gamer", uid: "12345678", role: "Leader" }, { name: "Rohan Playz", role: "Member" }, { name: "Killer XD", role: "Member" }, { name: "Devil God", role: "Member" }],
        match_type: "Room Card", gameplay: "Classic", perspective: "FPP", environment: "Day", booyah_reward: 100, per_kill_reward: 10,
        rules: ["No Hacks or Third Party Apps.", "No Abusive Language.", "Respect All Players.", "Decision of Admin will be Final."] },
      { id: "m2", name: "Duo Warrior", entry: 20, countdown: "20m 15s", rank: "#8", kills: 4,
        tournament_id: "#TM10046", room_id: "457900", room_password: "DUO789", team_type: "Duo - TPP", starts_in: "00:20:15",
        date: "26 May 2024", time: "10:20 AM", map: "Kalahari", players: "50 / 50", prize_pool: 200,
        team: [{ name: "Ayan Gamer", uid: "12345678", role: "Leader" }, { name: "Rohan Playz", role: "Member" }],
        match_type: "Room Card", gameplay: "Classic", perspective: "TPP", environment: "Night", booyah_reward: 150, per_kill_reward: 8,
        rules: ["No Hacks or Third Party Apps.", "No Abusive Language.", "Respect All Players.", "Decision of Admin will be Final."] },
      { id: "m3", name: "Squad Clash", entry: 40, countdown: "30m 45s", rank: "#5", kills: 6,
        tournament_id: "#TM10047", room_id: "457955", room_password: "SQD456", team_type: "Squad - FPP", starts_in: "00:30:45",
        date: "26 May 2024", time: "10:45 AM", map: "Purgatory", players: "20 / 20", prize_pool: 500,
        team: [{ name: "Ayan Gamer", uid: "12345678", role: "Leader" }, { name: "Rohan Playz", role: "Member" }, { name: "Killer XD", role: "Member" }, { name: "Devil God", role: "Member" }],
        match_type: "Custom", gameplay: "Clash Squad", perspective: "FPP", environment: "Day", booyah_reward: 300, per_kill_reward: 15,
        rules: ["No Hacks or Third Party Apps.", "No Abusive Language.", "Respect All Players.", "Decision of Admin will be Final."] },
      { id: "m4", name: "Clash Squad", entry: 30, countdown: "45m 10s", rank: "#10", kills: 2,
        tournament_id: "#TM10048", room_id: "458020", room_password: "CS2024", team_type: "Squad - FPP", starts_in: "00:45:10",
        date: "26 May 2024", time: "11:15 AM", map: "Bermuda", players: "40 / 40", prize_pool: 300,
        team: [{ name: "Ayan Gamer", uid: "12345678", role: "Leader" }, { name: "Rohan Playz", role: "Member" }, { name: "Killer XD", role: "Member" }, { name: "Devil God", role: "Member" }],
        match_type: "Custom", gameplay: "Clash Squad", perspective: "FPP", environment: "Day", booyah_reward: 200, per_kill_reward: 10,
        rules: ["No Hacks or Third Party Apps.", "No Abusive Language.", "Respect All Players.", "Decision of Admin will be Final."] }
    ],
    Completed: [
      { id: "m5", name: "Duo Warrior", entry: 20, rank: "#2", kills: 8, prize: 150,
        tournament_id: "#TM10032", room_id: "451236", team_type: "Squad - FPP",
        date: "25 May 2024", time: "09:30 PM", map: "Purgatory", players: "50 / 50",
        results: { rank: "#2", of: 12, eliminations: 7, earned: 100 },
        team: [{ name: "Ayan Gamer", uid: "12345678", role: "Leader", kills: 7 }, { name: "Rohan Playz", role: "Member", kills: 3 }, { name: "Killer XD", role: "Member", kills: 2 }, { name: "Devil God", role: "Member", kills: 1 }],
        summary: { total_time: "15:42", distance: "3.45 KM", damage: 1523, headshots: 11, revives: 2 },
        prize_pool: 500, your_share: 100 },
      { id: "m6", name: "Solo Clash", entry: 15, rank: "#1", kills: 11, prize: 150,
        tournament_id: "#TM10029", room_id: "450110", team_type: "Solo - FPP",
        date: "24 May 2024", time: "08:45 AM", map: "Alpine", players: "50 / 50",
        results: { rank: "#1", of: 50, eliminations: 11, earned: 150 },
        team: [{ name: "Ayan Gamer", uid: "12345678", role: "Leader", kills: 11 }],
        summary: { total_time: "18:20", distance: "4.10 KM", damage: 2010, headshots: 6, revives: 0 },
        prize_pool: 150, your_share: 150 }
    ],
    Cancelled: [
      { id: "m7", name: "Squad Clash", entry: 40, rank: "-", kills: 0, prize: 0,
        tournament_id: "#TM10028", room_id: "448910", team_type: "1v1 - FPP",
        date: "25 May 2024", time: "08:15 PM", map: "Iron Cage", players: "1 / 2", prize_pool: 200,
        cancel_reason: "Not enough players", refund_status: "REFUND INITIATED",
        match_type: "1v1", gameplay: "Classic", perspective: "FPP", environment: "Day",
        rules: ["No Hacks or Third Party Apps.", "No Abusive Language.", "Respect All Players.", "Decision of Admin will be Final."] }
    ]
  },

  // maps to `coin_transactions`
  transactions: [
    { id: "tx1", label: "Tournament Join", date: "24 May, 10:30 AM", amount: -20 },
    { id: "tx2", label: "Tournament Winning", date: "24 May, 08:45 AM", amount: 150 },
    { id: "tx3", label: "Add Money", date: "23 May, 09:20 PM", amount: 100 },
    { id: "tx4", label: "Referral Bonus", date: "22 May, 06:10 PM", amount: 50 },
    { id: "tx5", label: "Tournament Join", date: "21 May, 07:00 PM", amount: -30 },
    { id: "tx6", label: "Withdrawal", date: "20 May, 11:15 AM", amount: -200 }
  ],

  withdrawals: [
    { id: "w1", label: "Withdraw to UPI", date: "18 May, 04:20 PM", amount: -500, status: "Completed" },
    { id: "w2", label: "Withdraw to Bank", date: "10 May, 01:10 PM", amount: -300, status: "Processing" }
  ],

  // maps to `giveaways`
  giveaways: [
    { id: "g1", name: "1000 Diamonds", ends: "Ends in 02d 10h 30m" },
    { id: "g2", name: "Elite Pass", ends: "Ends in 01d 08h 20m" },
    { id: "g3", name: "500 Diamonds", ends: "Ends in 03d 12h 15m" }
  ],

  // maps to `referrals`
  referrals: [
    { id: "r1", label: "Rohit joined using your code", date: "20 May, 2026", amount: 50 },
    { id: "r2", label: "Priya joined using your code", date: "15 May, 2026", amount: 50 }
  ],

  // maps to `notifications`
  notifications: [
    { id: "n1", label: "Tournament Reminder", body: "Squad Clash starts in 30 minutes.", date: "Just now" },
    { id: "n2", label: "Coin Added", body: "₹100 added to your wallet successfully.", date: "2h ago" },
    { id: "n3", label: "Match Result", body: "You ranked #2 in Duo Warrior. +150 coins!", date: "1d ago" },
    { id: "n4", label: "Withdrawal Update", body: "Your withdrawal of ₹500 has been processed.", date: "2d ago" },
    { id: "n5", label: "Announcement", body: "New Battle Royale mode is now live!", date: "3d ago" }
  ],

  // maps to `SupportCategories` — quick help entry cards on Support Center home
  quickHelp: [
    { topic: "payment_failed", icon: "coinsStack", accent: "gold", title: "Payment Issue", sub: "Problem with payment" },
    { topic: "coins_not_received", icon: "coinQuestion", accent: "gold", title: "Coin Issue", sub: "Coins not added" },
    { topic: "tournament_join", icon: "controller", accent: "", title: "Tournament Issue", sub: "Match or join issue" },
    { topic: "withdrawal_issue", icon: "wallet", accent: "", title: "Withdraw Issue", sub: "Withdrawal problems" },
    { topic: "account_issue", icon: "profile", accent: "", title: "Account Issue", sub: "Login or account help" },
    { topic: "bug_report", icon: "bug", accent: "", title: "Report Bug", sub: "Report an error/bug" }
  ],

  // Topic buttons shown at the start of every fresh bot chat
  chatTopics: [
    { topic: "coins_not_received", icon: "coinsStack", accent: "gold", label: "Add Coin Problem" },
    { topic: "payment_failed", icon: "cardAdd", accent: "", label: "Payment Failed" },
    { topic: "coins_not_received", icon: "coinQuestion", accent: "gold", label: "Coins Not Received" },
    { topic: "withdrawal_issue", icon: "wallet", accent: "", label: "Withdrawal Status" },
    { topic: "tournament_join", icon: "controller", accent: "", label: "Tournament Join Issue" },
    { topic: "account_banned", icon: "personBan", accent: "", label: "Account Banned" },
    { topic: "prize_not_received", icon: "trophy", accent: "gold", label: "Prize Not Received" },
    { topic: "bug_report", icon: "bug", accent: "", label: "App Bug" },
    { topic: "login_issue", icon: "lock", accent: "", label: "Login Problem" },
    { topic: "contact_human", icon: "headset", accent: "", label: "Contact Human Support" }
  ],

  /**
   * SCRIPTED BOT FLOWS
   * Each flow is a small step machine. A step can be:
   *  - text: bot message to show
   *  - buttons: [{label, next}] shown after the text, tapping advances to `next`
   *  - input: {placeholder, next} shows a text field, submitting advances to `next`
   *  - select: {options:[...], next} shows a list to pick from
   *  - end: true marks a terminal step (chat waits for a new topic)
   */
  botFlows: {
    payment_failed: {
      start: "q1",
      steps: {
        q1: { text: "No worries — if your payment was deducted, coins are credited automatically within 24-48 hours once the payment is verified.", next: "policy" },
        policy: { text: "If your coins are still not credited after 24 hours, please raise a support ticket with your payment details and our team will resolve it.", buttons: [{ label: "Raise a Ticket", next: "done", nav: "screen-create-ticket" }, { label: "OK, I'll Wait", next: "closed" }] },
        closed: { text: "Sounds good! We'll notify you as soon as your coins are credited.", end: true },
        done: { text: "Opening the ticket form for you...", end: true }
      }
    },
    coins_not_received: {
      start: "q1",
      steps: {
        q1: { text: "If your payment was successful, coins are credited automatically within 24-48 hours.", next: "policy" },
        policy: { text: "Still not received after 24 hours? Please raise a support ticket and our team will check it manually.", buttons: [{ label: "Raise a Ticket", next: "done", nav: "screen-create-ticket" }, { label: "OK, I'll Wait", next: "closed" }] },
        closed: { text: "Great, thanks for your patience! 🪙", end: true },
        done: { text: "Opening the ticket form for you...", end: true }
      }
    },
    tournament_join: {
      start: "q1",
      steps: {
        q1: { text: "Which tournament are you having trouble with?", select: { options: ["Solo Battle Royale", "Duo Warrior", "Squad Clash", "Clash Squad", "Solo Clash"], next: "guide" } },
        guide: { text: "First, please check: your coin balance covers the entry fee, and registration for that tournament hasn't closed yet. This resolves most join issues.", next: "policy" },
        policy: { text: "Still stuck? Please raise a ticket. Note: issues about a tournament or room must be reported within 48 hours of the match — we're unable to look into reports after that window.", buttons: [{ label: "Raise a Ticket", next: "done", nav: "screen-create-ticket" }, { label: "That Fixed It", next: "closed" }] },
        closed: { text: "Perfect, good luck in the tournament! 🎮", end: true },
        done: { text: "Opening the ticket form for you...", end: true }
      }
    },
    prize_not_received: {
      start: "q1",
      steps: {
        q1: { text: "Please select the completed tournament.", select: { options: ["Duo Warrior", "Solo Clash", "Squad Clash"], next: "info" } },
        info: { text: "Prize verification is usually completed within a few hours after the match ends and credited automatically.", next: "policy" },
        policy: { text: "If your prize still hasn't arrived, please raise a ticket. Reminder: tournament and room issues must be reported within 48 hours of the match ending — reports after that window can't be reviewed.", buttons: [{ label: "Raise a Ticket", next: "done", nav: "screen-create-ticket" }, { label: "Got It, Resolved", next: "closed" }] },
        closed: { text: "Great, congrats on the win! 🏆", end: true },
        done: { text: "Opening the ticket form for you...", end: true }
      }
    },
    withdrawal_issue: {
      start: "q1",
      steps: {
        q1: { text: "Please select your withdrawal request.", select: { options: ["₹500 · 18 May", "₹300 · 10 May"], next: "info" } },
        info: { text: "Instant methods (UPI, PhonePe, Paytm, Google Pay) are usually credited within 24-48 hours. Bank transfers can take up to 4 working days.", next: "policy" },
        policy: { text: "Not received after that window? Please raise a ticket — for instant methods, raise it after 48 hours; for bank transfer, after 4 days. Reports beyond these windows can't be reviewed.", buttons: [{ label: "Raise a Ticket", next: "done", nav: "screen-create-ticket" }, { label: "OK, I'll Wait", next: "closed" }] },
        closed: { text: "Thanks for your patience! 💳", end: true },
        done: { text: "Opening the ticket form for you...", end: true }
      }
    },
    login_issue: {
      start: "q1",
      steps: {
        q1: { text: "What kind of login issue are you facing?", select: { options: ["Forgot Password", "OTP Problem", "Account Locked", "Email Verification"], next: "guide" } },
        guide: { text: "Try resetting your password from the login screen, or requesting a new OTP — this resolves most login issues right away.", next: "policy" },
        policy: { text: "Still can't log in? Raise a ticket and our team will look into your account directly.", buttons: [{ label: "Raise a Ticket", next: "done", nav: "screen-create-ticket" }, { label: "That Worked", next: "closed" }] },
        closed: { text: "You're all set! 🔓", end: true },
        done: { text: "Opening the ticket form for you...", end: true }
      }
    },
    account_banned: {
      start: "q1",
      steps: {
        q1: { text: "What account issue are you facing?", select: { options: ["Change Name", "Change Profile", "Delete Account", "Account Restricted"], next: "guide" } },
        guide: { text: "You can change your name and avatar anytime from Profile → Edit Profile. Deleting an account or a restriction review needs a manual check by our team.", buttons: [{ label: "Raise a Ticket", next: "done", nav: "screen-create-ticket" }, { label: "Thanks, That Helps", next: "closed" }] },
        closed: { text: "Glad that helped! 👍", end: true },
        done: { text: "Opening the ticket form for you...", end: true }
      }
    },
    redeem_code: {
      start: "q1",
      steps: {
        q1: { text: "What's happening with your redeem code?", buttons: [{ label: "Invalid Code", next: "invalid" }, { label: "Already Used", next: "used" }, { label: "Expired Code", next: "expired" }] },
        invalid: { text: "Please double check the code for typos — codes are case-sensitive. If it still doesn't work, it may not be a valid code.", end: true },
        used: { text: "Each redeem code can only be used once per account, so it looks like this one's already been redeemed.", end: true },
        expired: { text: "This code has passed its expiry date and can no longer be redeemed. Keep an eye out for new codes in the Giveaway section!", end: true }
      }
    },
    bug_report: {
      start: "q1",
      steps: {
        q1: { text: "Sorry about that! Please raise a ticket describing the bug — what happened, and what you expected instead. Our team will investigate.", buttons: [{ label: "Raise a Ticket", next: "done", nav: "screen-create-ticket" }] },
        done: { text: "Opening the ticket form for you...", end: true }
      }
    },
    contact_human: {
      start: "q1",
      steps: {
        q1: { text: "Sure — I'll connect you with our human support team. You can also reach them anytime from the Support Center.", buttons: [{ label: "Go to Contact Us", next: "done", nav: "screen-contact" }] },
        done: { text: "Redirecting you now...", end: true }
      }
    },
    general: {
      start: "q1",
      steps: {
        q1: { text: "I can help right away — please choose a topic below.", end: true }
      }
    }
  },

  // maps to `SupportTickets`
  tickets: [
    { id: "CA-10231", category: "Withdrawal", reason: "Withdrawal delayed for 2 days", mobile: "9876543210", status: "in_review", admin_reply: "", created: "24 May, 2026", updated: "24 May, 2026" },
    { id: "CA-10198", category: "Payment", reason: "Payment failed but amount deducted", mobile: "9876543210", status: "resolved", admin_reply: "Your payment was verified and coins have been credited. Sorry for the delay!", created: "18 May, 2026", updated: "19 May, 2026" }
  ],

  // maps to `FAQ`, grouped by `SupportCategories`
  faq: [
    { category: "Payments", items: [
      { q: "How do I add coins?", a: "Go to Wallet → Add Coins, pick an amount, and pay via UPI, card, or net banking through Cashfree. Coins are credited automatically after payment succeeds." },
      { q: "Payment failed but money deducted", a: "This usually resolves automatically within 24-48 hours as coins get credited once the payment is verified. If it's still not resolved after that, please raise a support ticket." },
      { q: "Coins not added", a: "Coins are usually credited automatically within a few minutes of a successful payment. If they're still missing after 24 hours, please raise a support ticket — reports made after 24 hours can't be reviewed." },
      { q: "Payment pending", a: "Pending payments are usually confirmed within a few minutes. If it stays pending for over 30 minutes, please raise a ticket." }
    ]},
    { category: "Tournament", items: [
      { q: "How to join a tournament?", a: "Open Tournaments, pick one that matches your budget and mode, then tap Join. The entry fee is deducted from your coin balance instantly." },
      { q: "Entry fee deducted but not joined", a: "This can happen due to a network hiccup. Check My Matches first — if it's not listed, use the Tournament Join Issue flow in the Support Bot." },
      { q: "Room ID not received", a: "Room details are released shortly before the match starts. Check Tournament Details or your notifications a few minutes before start time." },
      { q: "Match cancelled", a: "If a match is cancelled by admins, your entry fee is automatically refunded to your wallet." },
      { q: "Rules", a: "Each tournament has its own rules listed on the Tournament Details page — please review them before joining." }
    ]},
    { category: "Withdraw", items: [
      { q: "How to withdraw?", a: "Go to Wallet → Withdraw, enter the amount, choose UPI/Bank/Paytm/PhonePe, and submit your request." },
      { q: "Minimum withdrawal", a: "The minimum withdrawal amount is ₹100 (this may be adjusted from time to time)." },
      { q: "Processing time", a: "UPI, PhonePe, Paytm, and Google Pay withdrawals are usually credited within 24-48 hours. Bank transfers can take up to 4 working days. If your withdrawal hasn't arrived after that window, please raise a support ticket — reports made after this window can't be reviewed." },
      { q: "Withdrawal rejected", a: "Rejections usually happen due to mismatched account details. Check your withdrawal history or raise a ticket for details." }
    ]},
    { category: "Account", items: [
      { q: "Login problem", a: "Try resetting your password. If you still can't log in, use the Login Problem flow in the Support Bot." },
      { q: "Forgot password", a: "Tap Forgot Password on the login screen and follow the reset link sent to your email." },
      { q: "Change profile", a: "You can update your avatar anytime from Profile → tap the edit icon." },
      { q: "Delete account", a: "Contact human support to request account deletion — this is handled manually to keep your data secure." }
    ]},
    { category: "Redeem Codes", items: [
      { q: "How to use?", a: "Go to Giveaway, enter your code in the Redeem Code field, and tap Redeem." },
      { q: "Invalid code", a: "Double check for typos — codes are case-sensitive." },
      { q: "Expired code", a: "Expired codes can no longer be redeemed. Watch the Giveaway section for new ones." }
    ]},
    { category: "Notifications", items: [
      { q: "Tournament reminder", a: "You'll get a push notification shortly before a tournament you've joined begins." },
      { q: "Winning notification", a: "You're notified as soon as match results are finalized and prizes are credited." },
      { q: "Coin credit notification", a: "You'll be notified every time coins are added to your wallet, whether from a payment, referral, or winnings." }
    ]}
  ],

  // Drives the single shared "screen-withdraw-method" screen — one entry per
  // payment method card on the main Withdraw screen. `fields` become the
  // input rows rendered into #wm-fields; `bank` is a special case with its
  // own saved-account card instead of free-form fields.
  withdrawMethods: {
    upi: {
      title: "UPI Withdrawal", theme: "upi", logo: "upiWordmarkBig", subtitle: "UNIFIED PAYMENTS INTERFACE",
      fields: [
        { key: "upi_id", icon: "sendArrow", label: "UPI ID", required: true, placeholder: "Enter UPI ID (e.g., name@okicici)", hint: "Enter the UPI ID where you want to receive the amount" },
        { key: "mobile", icon: "profile", label: "Mobile Number", required: true, placeholder: "Enter Mobile Number" }
      ],
      processingNote: "Your withdrawal will be credited to your UPI account",
      important: ["Withdrawals are processed only to your registered UPI ID.", "Do not add any extra amount.", "Your withdrawal will be credited after successful processing.", "Not received after 48 hours? Please raise a support ticket."]
    },
    upiid: {
      title: "UPI ID Withdrawal", theme: "upiid", logo: "upiWordmarkBig", subtitle: null,
      fields: [
        { key: "upi_id", icon: "sendArrow", label: "UPI ID", required: true, placeholder: "Enter UPI ID (e.g., name@okicici)", hint: "Enter the UPI ID where you want to receive the amount" },
        { key: "mobile", icon: "profile", label: "Mobile Number", required: true, placeholder: "Enter Mobile Number", hint: "This number should be linked with the above UPI ID" },
        { key: "alt_mobile", icon: null, label: "Alternate Mobile Number", required: false, placeholder: "Enter Alternate Mobile Number", hint: "Used for additional verification (if needed)" }
      ],
      processingNote: "Your withdrawal will be credited to your UPI ID",
      important: ["Withdrawals are processed only to your registered UPI ID.", "Do not add any extra amount.", "Your withdrawal will be credited after successful processing.", "Not received after 48 hours? Please raise a support ticket."],
      extraNote: "Make sure your UPI ID is active and linked with the entered mobile number."
    },
    phonepe: {
      title: "PhonePe Withdrawal", theme: "phonepe", logo: "phonepeLogo", subtitle: null,
      fields: [
        { key: "mobile", icon: "profile", label: "Mobile Number", required: true, placeholder: "Enter PhonePe Registered Mobile Number" },
        { key: "alt_mobile", icon: null, label: "Alternate Mobile Number", required: false, placeholder: "Enter Alternate Mobile Number" },
        { key: "upi_id", icon: null, label: "UPI ID", required: true, placeholder: "Enter UPI ID (e.g., name@ybl)", hint: "If your PhonePe is linked with a UPI ID, enter here" }
      ],
      processingNote: "Your withdrawal will be credited to your PhonePe account",
      important: ["Withdrawals are processed only to your registered PhonePe account.", "Do not add any extra amount.", "Your withdrawal will be credited after successful processing.", "Not received after 48 hours? Please raise a support ticket."]
    },
    paytm: {
      title: "Paytm Withdrawal", theme: "paytm", logo: "paytmWordmarkBig", subtitle: null,
      fields: [
        { key: "mobile", icon: null, label: "Mobile Number", required: true, placeholder: "Enter Paytm Registered Mobile Number" },
        { key: "alt_mobile", icon: null, label: "Alternate Mobile Number", required: false, placeholder: "Enter Alternate Mobile Number" },
        { key: "upi_id", icon: null, label: "UPI ID", required: true, placeholder: "Enter UPI ID (e.g., abc@paytm)" }
      ],
      processingNote: "Your withdrawal will be credited to your Paytm account",
      important: ["Withdrawals are processed only to your registered Paytm account.", "Do not add any extra amount.", "Your withdrawal will be credited after successful processing.", "Not received after 48 hours? Please raise a support ticket."]
    },
    gpay: {
      title: "Google Pay Withdrawal", theme: "gpay", logo: "gpayWordmarkBig", subtitle: null,
      fields: [
        { key: "mobile", icon: "profile", label: "Mobile Number", required: true, placeholder: "Enter Google Pay Registered Mobile Number" },
        { key: "alt_mobile", icon: null, label: "Alternate Mobile Number", required: false, placeholder: "Enter Alternate Mobile Number" },
        { key: "upi_id", icon: null, label: "UPI ID", required: true, placeholder: "Enter UPI ID (e.g., name@okicici)", hint: "If your Google Pay is linked with a UPI ID, enter here" }
      ],
      processingNote: "Your withdrawal will be credited to your Google Pay account",
      important: ["Withdrawals are processed only to your registered Google Pay account.", "Do not add any extra amount.", "Your withdrawal will be credited after successful processing.", "Not received after 48 hours? Please raise a support ticket."]
    },
    bank: {
      title: "Bank Transfer", theme: "bank", logo: "bank", subtitle: null,
      isBank: true,
      processingNote: "Your withdrawal will be credited to your bank account",
      processingTime: "2 - 3 Working Days",
      important: ["Withdrawals are processed only to your registered bank account.", "Do not add any extra amount.", "Your withdrawal will be credited after successful processing.", "Not received after 4 working days? Please raise a support ticket."]
    }
  }
};

// expose for app.js
window.MOCK = MOCK;
