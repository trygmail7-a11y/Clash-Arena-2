/**
 * CAPACITOR NATIVE BOOTSTRAP
 * --------------------------------------------------
 * Runs only when the app is actually running inside the native Capacitor
 * shell (Android APK) — completely inert in a plain browser tab, so it's
 * safe to leave in place for local testing too.
 *
 * What it does:
 *  1. Forces the Android status bar (where the clock/battery show) to a
 *     white background with dark icons, matching the app's white theme.
 *  2. Keeps the native splash screen (showing the Clash Arena logo, built
 *     from resources/splash.png via @capacitor/assets) visible until the
 *     web UI has actually finished rendering, then fades it out — instead
 *     of the default blank/instant splash.
 */
(function () {
  function isNative() {
    return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (!isNative() || !window.Capacitor.Plugins) return;

    var StatusBar = window.Capacitor.Plugins.StatusBar;
    var SplashScreen = window.Capacitor.Plugins.SplashScreen;

    if (StatusBar) {
      // "Light" style = dark icons/text, correct for our white status bar
      StatusBar.setStyle({ style: "LIGHT" }).catch(function () {});
      StatusBar.setBackgroundColor({ color: "#FFFFFF" }).catch(function () {});
      StatusBar.setOverlaysWebView({ overlay: false }).catch(function () {});
    }

    // Give the login screen a moment to paint, then hide the native splash
    // with a smooth fade instead of an abrupt cut.
    setTimeout(function () {
      if (SplashScreen) {
        SplashScreen.hide({ fadeOutDuration: 300 }).catch(function () {});
      }
    }, 700);
  });
})();
