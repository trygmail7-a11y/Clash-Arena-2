/**
 * CAPACITOR NATIVE BOOTSTRAP
 * --------------------------------------------------
 * Runs only when the app is actually running inside the native Capacitor
 * shell (Android APK) — completely inert in a plain browser tab, so it's
 * safe to leave in place for local testing too.
 *
 * What it does:
 *  1. Forces the Android status bar (where the clock/battery show) to a
 *     white background with dark icons, matching the app's white theme.
 *
 * The native splash screen itself (logo + white background, built from
 * resources/splash.png) is now shown and hidden entirely by Capacitor's
 * own launchAutoHide/launchShowDuration config in capacitor.config.json —
 * deliberately NOT depending on this JS file running successfully to hide
 * it, so a slow-loading WebView can never leave the splash stuck on screen.
 */
(function () {
  function isNative() {
    return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (!isNative() || !window.Capacitor.Plugins) return;

    var StatusBar = window.Capacitor.Plugins.StatusBar;
    if (StatusBar) {
      // "Light" style = dark icons/text, correct for our white status bar
      StatusBar.setStyle({ style: "LIGHT" }).catch(function () {});
      StatusBar.setBackgroundColor({ color: "#FFFFFF" }).catch(function () {});
      StatusBar.setOverlaysWebView({ overlay: false }).catch(function () {});
    }
  });
})();
