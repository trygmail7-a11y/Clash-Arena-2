/**
 * CLASH ARENA — APP CONTROLLER
 * --------------------------------------------------
 * Plain JS SPA. Handles screen navigation, rendering mock data into the DOM,
 * and simple interactions (join tournament, add coins, withdraw, etc).
 *
 * NOTE: This is the TESTING/UI phase. All actions here simulate what will
 * later call Supabase / Cashfree / Firebase. Search for "TODO(backend)"
 * to find every point where a real API call will replace mock logic.
 */

const NAV_ITEMS = [
  { screen: "screen-home", icon: "🏠", label: "Home" },
  { screen: "screen-tournaments", icon: "🏆", label: "Tournaments" },
  { screen: "screen-matches", icon: "🎮", label: "My Matches" },
  { screen: "screen-wallet", icon: "💳", label: "Wallet" },
  { screen: "screen-profile", icon: "👤", label: "Profile" }
];

let state = {
  currentScreen: "screen-login",
  history: [],
  tournamentFilter: "ALL",
  matchFilter: "Ongoing",
  addAmount: 100,
  withdrawAmount: 100,
  activeTournamentId: null
};

/* ---------------- NAVIGATION ---------------- */

function navigate(screenId, pushHistory = true) {
  if (!document.getElementById(screenId)) return;
  if (pushHistory && state.currentScreen && state.currentScreen !== screenId) {
    state.history.push(state.currentScreen);
  }
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById(screenId).classList.add("active");
  state.currentScreen = screenId;
  renderScreen(screenId);
  window.scrollTo(0, 0);
}

function goBack() {
  const prev = state.history.pop();
  if (prev) navigate(prev, false);
}

/* ---------------- BOTTOM NAV ---------------- */

function buildBottomNav() {
  const navs = document.querySelectorAll(".bottom-nav");
  navs.forEach(nav => {
    nav.innerHTML = NAV_ITEMS.map(item => `
      <div class="nav-item" data-nav="${item.screen}">
        <span class="nav-icon">${item.icon}</span>
        <span>${item.label}</span>
      </div>
    `).join("");
  });
}

function updateBottomNavActive() {
  document.querySelectorAll(".nav-item").forEach(el => {
    el.classList.toggle("active", el.dataset.nav === state.currentScreen);
  });
}

/* ---------------- RENDER FUNCTIONS ---------------- */

function tournamentCard(t, opts = {}) {
  const [c1, c2] = t.banner_color.split(",");
  return `
    <div class="t-card" data-open-tournament="${t.id}">
      <div class="t-thumb" style="background:linear-gradient(135deg,${c1},${c2})">${t.type.toUpperCase()}</div>
      <div class="t-info">
        <div class="t-title-row">
          <span class="t-title">${t.name}</span>
          <span class="t-timer">⏱ ${t.countdown}</span>
        </div>
        <div class="t-meta">
          <span>Entry: <b>● ${t.entry_fee}</b></span>
          <span>Prize: <b>₹${t.prize_pool}</b></span>
        </div>
        <div class="t-bottom-row">
          <span class="t-players">${t.joined}/${t.slots} joined</span>
          <button class="t-join-btn" data-open-tournament="${t.id}">JOIN</button>
        </div>
      </div>
    </div>`;
}

function renderHomeTournaments() {
  const list = MOCK.tournaments.slice(0, 4);
  document.getElementById("home-tournament-list").innerHTML = list.map(t => tournamentCard(t)).join("");
}

function renderTournamentsFull() {
  let list = MOCK.tournaments;
  if (state.tournamentFilter !== "ALL") {
    list = list.filter(t => t.category === state.tournamentFilter || t.type === state.tournamentFilter);
  }
  const el = document.getElementById("tournament-list-full");
  el.innerHTML = list.length
    ? list.map(t => tournamentCard(t)).join("")
    : `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">No tournaments in this category yet.</p>`;
}

function openTournamentDetails(id) {
  const t = MOCK.tournaments.find(x => x.id === id);
  if (!t) return;
  state.activeTournamentId = id;
  const [c1, c2] = t.banner_color.split(",");
  const banner = document.getElementById("details-banner");
  banner.style.background = `linear-gradient(135deg,${c1},${c2})`;
  banner.innerHTML = `<h2 style="margin:0;font-size:20px;">${t.name}</h2>`;
  document.getElementById("d-entry").textContent = `● ${t.entry_fee}`;
  document.getElementById("d-prize").textContent = `₹${t.prize_pool}`;
  document.getElementById("d-mode").textContent = t.mode;
  document.getElementById("d-team").textContent = t.team_type;
  document.getElementById("d-perkill").textContent = t.per_kill;
  document.getElementById("d-map").textContent = t.map;
  document.getElementById("d-version").textContent = t.version;
  document.getElementById("d-room").textContent = t.room_type;
  document.getElementById("d-teams").textContent = t.total_teams;
  document.getElementById("d-ends").textContent = t.reg_ends;
  document.getElementById("d-join-cost").textContent = `${t.entry_fee} ●`;
  navigate("screen-tournament-details");
}

function matchCard(m, tab) {
  if (tab === "Ongoing") {
    return `
      <div class="t-card">
        <div class="t-thumb" style="background:linear-gradient(135deg,#232526,#414345)">${m.name.slice(0,2).toUpperCase()}</div>
        <div class="t-info">
          <div class="t-title-row">
            <span class="t-title">${m.name}</span>
            <span class="status-tag status-ongoing">LIVE</span>
          </div>
          <div class="t-meta"><span>Entry: <b>● ${m.entry}</b></span><span>⏱ ${m.countdown}</span></div>
          <div class="t-bottom-row">
            <span class="t-players">Rank ${m.rank} · ${m.kills} Kills</span>
            <button class="t-rank-btn">VIEW</button>
          </div>
        </div>
      </div>`;
  }
  const statusClass = tab === "Completed" ? "status-completed" : "status-cancelled";
  return `
    <div class="t-card">
      <div class="t-thumb" style="background:linear-gradient(135deg,#232526,#414345)">${m.name.slice(0,2).toUpperCase()}</div>
      <div class="t-info">
        <div class="t-title-row">
          <span class="t-title">${m.name}</span>
          <span class="status-tag ${statusClass}">${tab.toUpperCase()}</span>
        </div>
        <div class="t-meta"><span>Entry: <b>● ${m.entry}</b></span><span>Prize: <b>₹${m.prize || 0}</b></span></div>
        <div class="t-bottom-row">
          <span class="t-players">Rank ${m.rank} · ${m.kills} Kills</span>
          <button class="t-rank-btn">DETAILS</button>
        </div>
      </div>
    </div>`;
}

function renderMatches() {
  const list = MOCK.matches[state.matchFilter] || [];
  const el = document.getElementById("match-list");
  el.innerHTML = list.length
    ? list.map(m => matchCard(m, state.matchFilter)).join("")
    : `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">No ${state.matchFilter.toLowerCase()} matches.</p>`;
}

function txRow(tx) {
  const positive = tx.amount > 0;
  return `
    <div class="tx-row">
      <div>
        <div class="tx-name">${tx.label}</div>
        <div class="tx-date">${tx.date}</div>
      </div>
      <div class="tx-amt ${positive ? 'pos' : 'neg'}">${positive ? '+' : ''}${tx.amount} ●</div>
    </div>`;
}

function renderWallet() {
  document.getElementById("wallet-balance").textContent = MOCK.user.coin_balance.toLocaleString();
  document.getElementById("home-balance").textContent = MOCK.user.coin_balance.toLocaleString();
  document.getElementById("wallet-tx-list").innerHTML = MOCK.transactions.slice(0, 4).map(txRow).join("");
}

function renderHistory() {
  document.getElementById("history-tx-list").innerHTML = MOCK.transactions.map(txRow).join("");
}

function renderWithdrawHistory() {
  document.getElementById("withdraw-avail").textContent = MOCK.user.winning_balance.toLocaleString();
  document.getElementById("withdraw-history-list").innerHTML = MOCK.withdrawals.map(w => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${w.label}</div>
        <div class="tx-date">${w.date} · ${w.status}</div>
      </div>
      <div class="tx-amt neg">${w.amount} ●</div>
    </div>`).join("");
}

function renderGiveaways() {
  document.getElementById("giveaway-list").innerHTML = MOCK.giveaways.map(g => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${g.name}</div>
        <div class="tx-date">${g.ends}</div>
      </div>
      <button class="t-join-btn" data-action="participate">Participate</button>
    </div>`).join("");
}

function renderReferrals() {
  document.getElementById("referral-list").innerHTML = MOCK.referrals.map(r => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${r.label}</div>
        <div class="tx-date">${r.date}</div>
      </div>
      <div class="tx-amt pos">+${r.amount} ●</div>
    </div>`).join("");
}

function renderNotifications() {
  document.getElementById("notification-list").innerHTML = MOCK.notifications.map(n => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${n.label}</div>
        <div class="tx-date">${n.body}</div>
      </div>
      <div class="tx-date">${n.date}</div>
    </div>`).join("");
}

function renderScreen(id) {
  updateBottomNavActive();
  switch (id) {
    case "screen-home": renderHomeTournaments(); break;
    case "screen-tournaments": renderTournamentsFull(); break;
    case "screen-matches": renderMatches(); break;
    case "screen-wallet": renderWallet(); break;
    case "screen-history": renderHistory(); break;
    case "screen-withdraw": renderWithdrawHistory(); break;
    case "screen-giveaway": renderGiveaways(); break;
    case "screen-refer": renderReferrals(); break;
    case "screen-notifications": renderNotifications(); break;
  }
}

/* ---------------- TOAST ---------------- */

let toastTimer = null;
function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
}

/* ---------------- ACTIONS ---------------- */

function handleAction(action, el) {
  switch (action) {
    case "login":
      toast("Welcome back!"); // TODO(backend): supabase.auth.signInWithPassword()
      break;
    case "signup":
      toast("Account created!"); // TODO(backend): supabase.auth.signUp()
      break;
    case "verify":
      toast("Email verified!"); // TODO(backend): supabase verify OTP
      break;
    case "reset":
      toast("Reset link sent to your email."); // TODO(backend): supabase.auth.resetPasswordForEmail()
      break;
    case "logout":
      state.history = [];
      toast("Logged out."); // TODO(backend): supabase.auth.signOut()
      break;
    case "join": {
      const t = MOCK.tournaments.find(x => x.id === state.activeTournamentId);
      if (t) {
        if (MOCK.user.coin_balance < t.entry_fee) {
          toast("Insufficient coin balance.");
          return;
        }
        MOCK.user.coin_balance -= t.entry_fee; // TODO(backend): edge function join_tournament()
        MOCK.transactions.unshift({ id: "tx" + Date.now(), label: "Tournament Join", date: "Just now", amount: -t.entry_fee });
        toast(`Joined ${t.name}!`);
        navigate("screen-matches");
      }
      break;
    }
    case "addmoney":
      // TODO(backend): create Cashfree order -> open checkout -> verify webhook -> credit coins
      MOCK.user.coin_balance += state.addAmount;
      MOCK.transactions.unshift({ id: "tx" + Date.now(), label: "Add Money", date: "Just now", amount: state.addAmount });
      toast(`₹${state.addAmount} added successfully!`);
      navigate("screen-wallet");
      break;
    case "withdraw": {
      const amt = Number(document.getElementById("withdraw-custom").value) || state.withdrawAmount;
      if (amt > MOCK.user.winning_balance) {
        toast("Amount exceeds available balance.");
        return;
      }
      // TODO(backend): insert into `withdrawals` table, pending admin/auto approval
      MOCK.user.winning_balance -= amt;
      MOCK.withdrawals.unshift({ id: "w" + Date.now(), label: "Withdraw to UPI", date: "Just now", amount: -amt, status: "Processing" });
      toast("Withdrawal request submitted.");
      navigate("screen-wallet");
      break;
    }
    case "redeem":
      toast("Redeem code applied!"); // TODO(backend): validate against `redeem_codes` table
      break;
    case "copy-code":
      toast("Referral code copied!");
      break;
    case "share":
      toast("Invite link ready to share!"); // TODO: navigator.share()
      break;
    case "submit-ticket":
      toast("Support ticket submitted."); // TODO(backend): insert into `support_tickets`
      navigate("screen-support");
      break;
    case "participate":
      toast("You're in! Good luck 🎉"); // TODO(backend): insert into `giveaway_entries`
      break;
  }
}

/* ---------------- EVENT DELEGATION ---------------- */

document.addEventListener("click", (e) => {
  const navEl = e.target.closest("[data-nav]");
  const openT = e.target.closest("[data-open-tournament]");
  const actionEl = e.target.closest("[data-action]");
  const filterEl = e.target.closest("[data-filter]");
  const amtEl = e.target.closest("[data-amt]");

  if (openT) {
    openTournamentDetails(openT.dataset.openTournament);
    return;
  }

  if (navEl) {
    navigate(navEl.dataset.nav);
  }

  if (filterEl) {
    const parent = filterEl.closest("#tournament-tabs, #match-tabs, .categories");
    if (parent) {
      parent.querySelectorAll("[data-filter]").forEach(x => x.classList.remove("active"));
      filterEl.classList.add("active");
    }
    if (filterEl.closest("#tournament-tabs") || filterEl.closest(".categories")) {
      state.tournamentFilter = filterEl.dataset.filter;
      if (state.currentScreen !== "screen-tournaments") navigate("screen-tournaments");
      else renderTournamentsFull();
    } else if (filterEl.closest("#match-tabs")) {
      state.matchFilter = filterEl.dataset.filter;
      renderMatches();
    }
  }

  if (amtEl) {
    const grid = amtEl.closest("#amount-grid, #withdraw-grid");
    grid.querySelectorAll("[data-amt]").forEach(x => x.classList.remove("active"));
    amtEl.classList.add("active");
    const val = Number(amtEl.dataset.amt);
    if (grid.id === "amount-grid") {
      state.addAmount = val;
      document.getElementById("addmoney-amt").textContent = val;
    } else {
      state.withdrawAmount = val;
      document.getElementById("withdraw-custom").value = val;
    }
  }

  if (actionEl && !navEl) {
    handleAction(actionEl.dataset.action, actionEl);
  } else if (actionEl && navEl) {
    // element has both nav + action (e.g. login button)
    handleAction(actionEl.dataset.action, actionEl);
  }
});

/* ---------------- INIT ---------------- */

document.addEventListener("DOMContentLoaded", () => {
  buildBottomNav();
  document.querySelectorAll("#amount-grid [data-amt='100'], #withdraw-grid [data-amt='100']").forEach(x => x.classList.add("active"));
  navigate("screen-login", false);
});
