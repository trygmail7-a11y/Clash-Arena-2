/**
 * CLASH ARENA — APP CONTROLLER
 * --------------------------------------------------
 * Plain JS SPA. Handles screen navigation, rendering mock data into the DOM,
 * and simple interactions (join tournament, add coins, withdraw, etc).
 *
 * NOTE: This is the TESTING/UI phase. All actions here simulate what will
 * later call Supabase / Cashfree / Firebase. Search for "TODO(backend)"
 * to find every point where a real API call will replace mock logic.
 */

const NAV_ITEMS = [
  { screen: "screen-home", icon: "🏠", label: "Home" },
  { screen: "screen-tournaments", icon: "🏆", label: "Tournaments" },
  { screen: "screen-matches", icon: "🎮", label: "My Matches" },
  { screen: "screen-wallet", icon: "💳", label: "Wallet" },
  { screen: "screen-profile", icon: "👤", label: "Profile" }
];

let state = {
  currentScreen: "screen-login",
  history: [],
  tournamentFilter: "ALL",
  matchFilter: "Ongoing",
  addAmount: 100,
  withdrawAmount: 100,
  activeTournamentId: null,
  selectedAvatarId: null,      // working selection on the avatar-select screen (only committed on Confirm)
  avatarOrigin: "screen-home", // where to return to after confirming an avatar
  pendingChatTopic: null,      // topic to jump straight into when the bot chat screen opens
  chat: null                   // { topicKey, awaiting: 'buttons'|'select'|'input'|null, inputNext }
};

/* ---------------- NAVIGATION ---------------- */

function navigate(screenId, pushHistory = true) {
  if (!document.getElementById(screenId)) return;
  if (pushHistory && state.currentScreen && state.currentScreen !== screenId) {
    state.history.push(state.currentScreen);
  }
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById(screenId).classList.add("active");
  state.currentScreen = screenId;
  refreshAvatarDisplays();
  renderScreen(screenId);
  window.scrollTo(0, 0);
}

function goBack() {
  const prev = state.history.pop();
  if (prev) navigate(prev, false);
}

/* ---------------- BOTTOM NAV ---------------- */

function buildBottomNav() {
  const navs = document.querySelectorAll(".bottom-nav");
  navs.forEach(nav => {
    nav.innerHTML = NAV_ITEMS.map(item => `
      <div class="nav-item" data-nav="${item.screen}">
        <span class="nav-icon">${item.icon}</span>
        <span>${item.label}</span>
      </div>
    `).join("");
  });
}

function updateBottomNavActive() {
  document.querySelectorAll(".nav-item").forEach(el => {
    el.classList.toggle("active", el.dataset.nav === state.currentScreen);
  });
}

/* ---------------- RENDER FUNCTIONS ---------------- */

function tournamentCard(t, opts = {}) {
  const [c1, c2] = t.banner_color.split(",");
  return `
    <div class="t-card" data-open-tournament="${t.id}">
      <div class="t-thumb" style="background:linear-gradient(135deg,${c1},${c2})">${t.type.toUpperCase()}</div>
      <div class="t-info">
        <div class="t-title-row">
          <span class="t-title">${t.name}</span>
          <span class="t-timer">⏱ ${t.countdown}</span>
        </div>
        <div class="t-meta">
          <span>Entry: <b>● ${t.entry_fee}</b></span>
          <span>Prize: <b>₹${t.prize_pool}</b></span>
        </div>
        <div class="t-bottom-row">
          <span class="t-players">${t.joined}/${t.slots} joined</span>
          <button class="t-join-btn" data-open-tournament="${t.id}">JOIN</button>
        </div>
      </div>
    </div>`;
}

function renderHomeTournaments() {
  const list = MOCK.tournaments.slice(0, 4);
  document.getElementById("home-tournament-list").innerHTML = list.map(t => tournamentCard(t)).join("");
}

function renderTournamentsFull() {
  let list = MOCK.tournaments;
  if (state.tournamentFilter !== "ALL") {
    list = list.filter(t => t.category === state.tournamentFilter || t.type === state.tournamentFilter);
  }
  const el = document.getElementById("tournament-list-full");
  el.innerHTML = list.length
    ? list.map(t => tournamentCard(t)).join("")
    : `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">No tournaments in this category yet.</p>`;
}

function openTournamentDetails(id) {
  const t = MOCK.tournaments.find(x => x.id === id);
  if (!t) return;
  state.activeTournamentId = id;
  const [c1, c2] = t.banner_color.split(",");
  const banner = document.getElementById("details-banner");
  banner.style.background = `linear-gradient(135deg,${c1},${c2})`;
  banner.innerHTML = `<h2 style="margin:0;font-size:20px;">${t.name}</h2>`;
  document.getElementById("d-entry").textContent = `● ${t.entry_fee}`;
  document.getElementById("d-prize").textContent = `₹${t.prize_pool}`;
  document.getElementById("d-mode").textContent = t.mode;
  document.getElementById("d-team").textContent = t.team_type;
  document.getElementById("d-perkill").textContent = t.per_kill;
  document.getElementById("d-map").textContent = t.map;
  document.getElementById("d-version").textContent = t.version;
  document.getElementById("d-room").textContent = t.room_type;
  document.getElementById("d-teams").textContent = t.total_teams;
  document.getElementById("d-ends").textContent = t.reg_ends;
  document.getElementById("d-join-cost").textContent = `${t.entry_fee} ●`;
  navigate("screen-tournament-details");
}

function matchCard(m, tab) {
  if (tab === "Ongoing") {
    return `
      <div class="t-card">
        <div class="t-thumb" style="background:linear-gradient(135deg,#232526,#414345)">${m.name.slice(0,2).toUpperCase()}</div>
        <div class="t-info">
          <div class="t-title-row">
            <span class="t-title">${m.name}</span>
            <span class="status-tag status-ongoing">LIVE</span>
          </div>
          <div class="t-meta"><span>Entry: <b>● ${m.entry}</b></span><span>⏱ ${m.countdown}</span></div>
          <div class="t-bottom-row">
            <span class="t-players">Rank ${m.rank} · ${m.kills} Kills</span>
            <button class="t-rank-btn">VIEW</button>
          </div>
        </div>
      </div>`;
  }
  const statusClass = tab === "Completed" ? "status-completed" : "status-cancelled";
  return `
    <div class="t-card">
      <div class="t-thumb" style="background:linear-gradient(135deg,#232526,#414345)">${m.name.slice(0,2).toUpperCase()}</div>
      <div class="t-info">
        <div class="t-title-row">
          <span class="t-title">${m.name}</span>
          <span class="status-tag ${statusClass}">${tab.toUpperCase()}</span>
        </div>
        <div class="t-meta"><span>Entry: <b>● ${m.entry}</b></span><span>Prize: <b>₹${m.prize || 0}</b></span></div>
        <div class="t-bottom-row">
          <span class="t-players">Rank ${m.rank} · ${m.kills} Kills</span>
          <button class="t-rank-btn">DETAILS</button>
        </div>
      </div>
    </div>`;
}

function renderMatches() {
  const list = MOCK.matches[state.matchFilter] || [];
  const el = document.getElementById("match-list");
  el.innerHTML = list.length
    ? list.map(m => matchCard(m, state.matchFilter)).join("")
    : `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">No ${state.matchFilter.toLowerCase()} matches.</p>`;
}

function txRow(tx) {
  const positive = tx.amount > 0;
  return `
    <div class="tx-row">
      <div>
        <div class="tx-name">${tx.label}</div>
        <div class="tx-date">${tx.date}</div>
      </div>
      <div class="tx-amt ${positive ? 'pos' : 'neg'}">${positive ? '+' : ''}${tx.amount} ●</div>
    </div>`;
}

function renderWallet() {
  document.getElementById("wallet-balance").textContent = MOCK.user.coin_balance.toLocaleString();
  document.getElementById("home-balance").textContent = MOCK.user.coin_balance.toLocaleString();
  document.getElementById("wallet-tx-list").innerHTML = MOCK.transactions.slice(0, 4).map(txRow).join("");
}

function renderHistory() {
  document.getElementById("history-tx-list").innerHTML = MOCK.transactions.map(txRow).join("");
}

function renderWithdrawHistory() {
  document.getElementById("withdraw-avail").textContent = MOCK.user.winning_balance.toLocaleString();
  document.getElementById("withdraw-history-list").innerHTML = MOCK.withdrawals.map(w => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${w.label}</div>
        <div class="tx-date">${w.date} · ${w.status}</div>
      </div>
      <div class="tx-amt neg">${w.amount} ●</div>
    </div>`).join("");
}

function renderGiveaways() {
  document.getElementById("giveaway-list").innerHTML = MOCK.giveaways.map(g => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${g.name}</div>
        <div class="tx-date">${g.ends}</div>
      </div>
      <button class="t-join-btn" data-action="participate">Participate</button>
    </div>`).join("");
}

function renderReferrals() {
  document.getElementById("referral-list").innerHTML = MOCK.referrals.map(r => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${r.label}</div>
        <div class="tx-date">${r.date}</div>
      </div>
      <div class="tx-amt pos">+${r.amount} ●</div>
    </div>`).join("");
}

function renderNotifications() {
  document.getElementById("notification-list").innerHTML = MOCK.notifications.map(n => `
    <div class="tx-row">
      <div>
        <div class="tx-name">${n.label}</div>
        <div class="tx-date">${n.body}</div>
      </div>
      <div class="tx-date">${n.date}</div>
    </div>`).join("");
}

/* ---------------- AVATAR SYSTEM ---------------- */
// Avatars are 10 fixed local images. Only the `avatar_id` string is ever
// stored/read from "the database" (MOCK.user.avatar_id here, a real
// `users.avatar_id` column in Phase 2) — never the image itself.

function getAvatarFile(avatarId) {
  const found = MOCK.avatars.find(a => a.id === avatarId);
  return found ? found.file : MOCK.avatars[0].file;
}

function refreshAvatarDisplays() {
  const file = getAvatarFile(MOCK.user.avatar_id);
  const home = document.getElementById("home-avatar-img");
  const profile = document.getElementById("profile-avatar-img");
  if (home) home.src = file;
  if (profile) profile.src = file;
}

function renderAvatarGrid() {
  if (state.selectedAvatarId === null) state.selectedAvatarId = MOCK.user.avatar_id;
  const grid = document.getElementById("avatar-grid");
  grid.innerHTML = MOCK.avatars.filter(a => a.enabled).map(a => `
    <div class="avatar-item ${a.id === state.selectedAvatarId ? 'selected' : ''}" data-avatar-id="${a.id}">
      <img src="${a.file}" alt="${a.id}" />
    </div>`).join("");

  // back / cancel should return wherever the user came from
  state.avatarOrigin = state.history[state.history.length - 1] || "screen-home";
  const backBtn = document.getElementById("avatar-back-btn");
  if (backBtn) backBtn.dataset.nav = state.avatarOrigin;
}

/* ---------------- SUPPORT: QUICK HELP ---------------- */

function renderQuickHelp() {
  const grid = document.getElementById("quick-help-grid");
  if (!grid) return;
  grid.innerHTML = MOCK.quickHelp.map(q => `
    <div class="qh-card" data-open-chat="${q.topic}">
      <span class="qh-icon">${q.icon}</span>
      <span class="qh-title">${q.title}</span>
      <span class="qh-sub">${q.sub}</span>
    </div>`).join("");
}

/* ---------------- SUPPORT BOT (CHAT ENGINE) ---------------- */

function chatTimestamp() {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function scrollChatToBottom() {
  const body = document.getElementById("chat-body");
  if (body) body.scrollTop = body.scrollHeight;
}

function appendBotBubble(text) {
  const body = document.getElementById("chat-body");
  body.insertAdjacentHTML("beforeend", `
    <div class="bubble-row bot">
      <span class="bubble-avatar">🎧</span>
      <div>
        <div class="bubble">${text}</div>
        <span class="bubble-time">${chatTimestamp()}</span>
      </div>
    </div>`);
  scrollChatToBottom();
}

function appendUserBubble(text) {
  const body = document.getElementById("chat-body");
  body.insertAdjacentHTML("beforeend", `
    <div class="bubble-row user">
      <div>
        <div class="bubble">${text}</div>
        <span class="bubble-time">${chatTimestamp()} ✓✓</span>
      </div>
    </div>`);
  scrollChatToBottom();
}

function clearChatControls() {
  const old = document.getElementById("chat-controls");
  if (old) old.remove();
}

function appendChatControls(html) {
  clearChatControls();
  const body = document.getElementById("chat-body");
  body.insertAdjacentHTML("beforeend", `<div id="chat-controls">${html}</div>`);
  scrollChatToBottom();
}

function startChatScreen() {
  const body = document.getElementById("chat-body");
  body.innerHTML = "";
  state.chat = { topicKey: null, awaiting: null, inputNext: null };
  appendBotBubble("👋 Hi! Welcome to Clash Arena Support. How can I help you today?");

  if (state.pendingChatTopic && MOCK.botFlows[state.pendingChatTopic]) {
    const topic = MOCK.chatTopics.find(t => t.topic === state.pendingChatTopic)
      || MOCK.quickHelp.find(t => t.topic === state.pendingChatTopic);
    if (topic) appendUserBubble(topic.label || topic.title);
    runBotFlow(state.pendingChatTopic, MOCK.botFlows[state.pendingChatTopic].start);
  } else {
    showChatTopicMenu();
  }
  state.pendingChatTopic = null;
}

function showChatTopicMenu() {
  appendBotBubble("Please choose a topic");
  const html = `<div class="chat-topic-grid">${MOCK.chatTopics.map(t => `
    <button class="chat-topic-btn" data-chat-topic-btn="${t.topic}" data-chat-topic-label="${t.label}">
      <span>${t.icon}</span>${t.label}<span class="ct-arrow">›</span>
    </button>`).join("")}</div>`;
  appendChatControls(html);
}

function runBotFlow(topicKey, stepKey) {
  const flow = MOCK.botFlows[topicKey];
  if (!flow) return;
  const step = flow.steps[stepKey];
  if (!step) return;

  state.chat.topicKey = topicKey;
  clearChatControls();
  appendBotBubble(step.text);

  if (step.buttons) {
    state.chat.awaiting = "buttons";
    appendChatControls(`<div class="chat-quick-replies">${step.buttons.map((b, i) => `
      <button class="${i === 0 ? 'qr-primary' : 'qr-secondary'}" data-chat-btn-next="${b.next}" data-chat-btn-label="${b.label}" ${b.nav ? `data-chat-btn-nav="${b.nav}"` : ""}>${b.label}</button>`).join("")}</div>`);
  } else if (step.select) {
    state.chat.awaiting = "select";
    appendChatControls(`<div class="chat-topic-grid" style="grid-template-columns:1fr;">${step.select.options.map(opt => `
      <button class="chat-topic-btn" data-chat-select-next="${step.select.next}" data-chat-select-label="${opt}">${opt}<span class="ct-arrow">›</span></button>`).join("")}</div>`);
  } else if (step.input) {
    state.chat.awaiting = "input";
    state.chat.inputNext = step.input.next;
    const inputEl = document.getElementById("chat-text-input");
    if (inputEl) { inputEl.placeholder = step.input.placeholder; inputEl.focus(); }
  } else {
    state.chat.awaiting = null;
    if (step.end && step.createTicket) {
      const t = createTicket(step.createTicket);
      setTimeout(() => appendBotBubble(`A ticket has been raised: <strong>${t.id}</strong>. Track it anytime in My Tickets.`), 300);
    }
    if (step.next) {
      // auto-advance steps with no interaction required (e.g. info-only messages)
      setTimeout(() => runBotFlow(topicKey, step.next), 500);
    }
  }
}

function handleChatButtonClick(next, label, nav) {
  appendUserBubble(label);
  clearChatControls();
  state.chat.awaiting = null;
  if (nav) {
    setTimeout(() => navigate(nav), 400);
    return;
  }
  runBotFlow(state.chat.topicKey, next);
}

function handleChatTopicSelect(topicKey, label) {
  appendUserBubble(label);
  clearChatControls();
  runBotFlow(topicKey, MOCK.botFlows[topicKey].start);
}

function handleChatInputSend() {
  const inputEl = document.getElementById("chat-text-input");
  const val = inputEl.value.trim();
  if (!val) return;
  appendUserBubble(val);
  inputEl.value = "";
  inputEl.placeholder = "Type a message...";
  if (state.chat && state.chat.awaiting === "input") {
    const next = state.chat.inputNext;
    state.chat.awaiting = null;
    runBotFlow(state.chat.topicKey, next);
  }
}

/* ---------------- SUPPORT TICKETS ---------------- */

function generateTicketId() {
  return "CA-" + Math.floor(10000 + Math.random() * 89999);
}

function createTicket({ category, reason, mobile }) {
  const t = {
    id: generateTicketId(),
    category: category || "Other",
    reason: reason || "No details provided",
    mobile: mobile || "N/A",
    status: "open",
    admin_reply: "",
    created: "Just now",
    updated: "Just now"
  };
  MOCK.tickets.unshift(t); // TODO(backend): insert into `support_tickets`
  return t;
}

function statusLabel(status) {
  return status.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
}

function ticketCard(t) {
  return `
    <div class="ticket-card">
      <div class="ticket-top-row">
        <div>
          <div class="ticket-id">${t.id}</div>
          <div class="ticket-cat">${t.category}</div>
        </div>
        <span class="ticket-status status-${t.status.replace(/_/g, '-')}">${statusLabel(t.status)}</span>
      </div>
      <p class="ticket-reason">${t.reason}</p>
      <div class="ticket-dates"><span>Created: ${t.created}</span><span>Updated: ${t.updated}</span></div>
      ${t.admin_reply ? `<div class="ticket-admin-reply"><strong>Admin Reply</strong>${t.admin_reply}</div>` : ""}
    </div>`;
}

function renderTickets() {
  const list = document.getElementById("tickets-list");
  if (!list) return;
  list.innerHTML = MOCK.tickets.length
    ? MOCK.tickets.map(ticketCard).join("")
    : `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">No tickets yet. Create one from the Support Center.</p>`;
}

/* ---------------- HELP CENTER ---------------- */

function renderHelpCenter() {
  const wrap = document.getElementById("help-center-list");
  if (!wrap) return;
  wrap.innerHTML = MOCK.faq.map((cat, ci) => `
    <div class="help-category">
      <div class="help-category-title">${cat.category}</div>
      ${cat.items.map((item, ii) => `
        <div class="help-item" data-help-id="${ci}-${ii}">
          <div class="help-q" data-help-toggle="${ci}-${ii}">${item.q}<span class="help-chevron">›</span></div>
          <div class="help-a"><div class="help-a-inner">${item.a}</div></div>
        </div>`).join("")}
    </div>`).join("");
}

function renderScreen(id) {
  updateBottomNavActive();
  switch (id) {
    case "screen-home": renderHomeTournaments(); break;
    case "screen-tournaments": renderTournamentsFull(); break;
    case "screen-matches": renderMatches(); break;
    case "screen-wallet": renderWallet(); break;
    case "screen-history": renderHistory(); break;
    case "screen-withdraw": renderWithdrawHistory(); break;
    case "screen-giveaway": renderGiveaways(); break;
    case "screen-refer": renderReferrals(); break;
    case "screen-notifications": renderNotifications(); break;
    case "screen-avatar-select": renderAvatarGrid(); break;
    case "screen-support": renderQuickHelp(); break;
    case "screen-support-bot": startChatScreen(); break;
    case "screen-my-tickets": renderTickets(); break;
    case "screen-help-center": renderHelpCenter(); break;
    case "screen-create-ticket":
      document.getElementById("ticket-reason").value = "";
      document.getElementById("ticket-mobile").value = "";
      document.getElementById("reason-word-count").textContent = "(max 10 words)";
      break;
  }
}

/* ---------------- TOAST ---------------- */

let toastTimer = null;
function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
}

/* ---------------- ACTIONS ---------------- */

function handleAction(action, el) {
  switch (action) {
    case "login":
      toast("Welcome back!"); // TODO(backend): supabase.auth.signInWithPassword()
      break;
    case "signup":
      toast("Account created!"); // TODO(backend): supabase.auth.signUp()
      break;
    case "verify":
      toast("Email verified!"); // TODO(backend): supabase verify OTP
      break;
    case "reset":
      toast("Reset link sent to your email."); // TODO(backend): supabase.auth.resetPasswordForEmail()
      break;
    case "logout":
      state.history = [];
      toast("Logged out."); // TODO(backend): supabase.auth.signOut()
      break;
    case "join": {
      const t = MOCK.tournaments.find(x => x.id === state.activeTournamentId);
      if (t) {
        if (MOCK.user.coin_balance < t.entry_fee) {
          toast("Insufficient coin balance.");
          return;
        }
        MOCK.user.coin_balance -= t.entry_fee; // TODO(backend): edge function join_tournament()
        MOCK.transactions.unshift({ id: "tx" + Date.now(), label: "Tournament Join", date: "Just now", amount: -t.entry_fee });
        toast(`Joined ${t.name}!`);
        navigate("screen-matches");
      }
      break;
    }
    case "addmoney":
      // TODO(backend): create Cashfree order -> open checkout -> verify webhook -> credit coins
      MOCK.user.coin_balance += state.addAmount;
      MOCK.transactions.unshift({ id: "tx" + Date.now(), label: "Add Money", date: "Just now", amount: state.addAmount });
      toast(`₹${state.addAmount} added successfully!`);
      navigate("screen-wallet");
      break;
    case "withdraw": {
      const amt = Number(document.getElementById("withdraw-custom").value) || state.withdrawAmount;
      if (amt > MOCK.user.winning_balance) {
        toast("Amount exceeds available balance.");
        return;
      }
      // TODO(backend): insert into `withdrawals` table, pending admin/auto approval
      MOCK.user.winning_balance -= amt;
      MOCK.withdrawals.unshift({ id: "w" + Date.now(), label: "Withdraw to UPI", date: "Just now", amount: -amt, status: "Processing" });
      toast("Withdrawal request submitted.");
      navigate("screen-wallet");
      break;
    }
    case "redeem":
      toast("Redeem code applied!"); // TODO(backend): validate against `redeem_codes` table
      break;
    case "copy-code":
      toast("Referral code copied!");
      break;
    case "share":
      toast("Invite link ready to share!"); // TODO: navigator.share()
      break;
    case "toggle-password": {
      const pw = document.getElementById("login-password");
      if (pw) pw.type = pw.type === "password" ? "text" : "password";
      break;
    }
    case "social-google":
    case "social-facebook":
    case "social-apple":
      toast("Redirecting to sign in..."); // TODO(backend): supabase.auth.signInWithOAuth()
      navigate("screen-home");
      break;
    case "save-avatar":
      MOCK.user.avatar_id = state.selectedAvatarId; // TODO(backend): update users.avatar_id
      refreshAvatarDisplays();
      toast("Avatar updated!");
      navigate(state.avatarOrigin || "screen-home");
      break;
    case "chat-send":
      handleChatInputSend();
      break;
    case "submit-ticket": {
      const isTicketForm = document.getElementById("ticket-category");
      if (isTicketForm) {
        const category = document.getElementById("ticket-category").value;
        const reason = document.getElementById("ticket-reason").value.trim();
        const mobile = document.getElementById("ticket-mobile").value.trim();
        if (!reason) { toast("Please enter a reason."); return; }
        if (!mobile || mobile.length < 10) { toast("Please enter a valid mobile number."); return; }
        const t = createTicket({ category, reason, mobile }); // TODO(backend): insert into `support_tickets`
        toast(`Ticket Created Successfully — ${t.id}`);
        navigate("screen-my-tickets");
      } else {
        toast("Message sent to our support team."); // TODO(backend): insert into `support_tickets` (category: Other)
        navigate("screen-support");
      }
      break;
    }
    case "copy-email":
      toast("Email copied: support@clasharena.com");
      break;
    case "open-whatsapp":
      toast("Opening WhatsApp..."); // TODO: window.open('https://wa.me/919876543210')
      break;
    case "social-link":
      toast("Opening link..."); // TODO: window.open(social url)
      break;
    case "participate":
      toast("You're in! Good luck 🎉"); // TODO(backend): insert into `giveaway_entries`
      break;
  }
}

/* ---------------- EVENT DELEGATION ---------------- */

document.addEventListener("click", (e) => {
  const navEl = e.target.closest("[data-nav]");
  const openT = e.target.closest("[data-open-tournament]");
  const actionEl = e.target.closest("[data-action]");
  const filterEl = e.target.closest("[data-filter]");
  const amtEl = e.target.closest("[data-amt]");
  const avatarEl = e.target.closest("[data-avatar-id]");
  const openChatEl = e.target.closest("[data-open-chat]");
  const helpToggleEl = e.target.closest("[data-help-toggle]");
  const chatTopicBtn = e.target.closest("[data-chat-topic-btn]");
  const chatSelectBtn = e.target.closest("[data-chat-select-next]");
  const chatBtnNext = e.target.closest("[data-chat-btn-next]");

  if (openT) {
    openTournamentDetails(openT.dataset.openTournament);
    return;
  }

  if (avatarEl) {
    state.selectedAvatarId = avatarEl.dataset.avatarId;
    renderAvatarGrid();
    return;
  }

  if (openChatEl) {
    state.pendingChatTopic = openChatEl.dataset.openChat;
    navigate("screen-support-bot");
    return;
  }

  if (helpToggleEl) {
    const item = document.querySelector(`.help-item[data-help-id="${helpToggleEl.dataset.helpToggle}"]`);
    if (item) item.classList.toggle("open");
    return;
  }

  if (chatTopicBtn) {
    handleChatTopicSelect(chatTopicBtn.dataset.chatTopicBtn, chatTopicBtn.dataset.chatTopicLabel);
    return;
  }

  if (chatSelectBtn) {
    handleChatButtonClick(chatSelectBtn.dataset.chatSelectNext, chatSelectBtn.dataset.chatSelectLabel);
    return;
  }

  if (chatBtnNext) {
    handleChatButtonClick(chatBtnNext.dataset.chatBtnNext, chatBtnNext.dataset.chatBtnLabel, chatBtnNext.dataset.chatBtnNav);
    return;
  }

  if (navEl) {
    navigate(navEl.dataset.nav);
  }

  if (filterEl) {
    const parent = filterEl.closest("#tournament-tabs, #match-tabs, .categories");
    if (parent) {
      parent.querySelectorAll("[data-filter]").forEach(x => x.classList.remove("active"));
      filterEl.classList.add("active");
    }
    if (filterEl.closest("#tournament-tabs") || filterEl.closest(".categories")) {
      state.tournamentFilter = filterEl.dataset.filter;
      if (state.currentScreen !== "screen-tournaments") navigate("screen-tournaments");
      else renderTournamentsFull();
    } else if (filterEl.closest("#match-tabs")) {
      state.matchFilter = filterEl.dataset.filter;
      renderMatches();
    }
  }

  if (amtEl) {
    const grid = amtEl.closest("#amount-grid, #withdraw-grid");
    grid.querySelectorAll("[data-amt]").forEach(x => x.classList.remove("active"));
    amtEl.classList.add("active");
    const val = Number(amtEl.dataset.amt);
    if (grid.id === "amount-grid") {
      state.addAmount = val;
      document.getElementById("addmoney-amt").textContent = val;
    } else {
      state.withdrawAmount = val;
      document.getElementById("withdraw-custom").value = val;
    }
  }

  if (actionEl && !navEl) {
    handleAction(actionEl.dataset.action, actionEl);
  } else if (actionEl && navEl) {
    // element has both nav + action (e.g. login button)
    handleAction(actionEl.dataset.action, actionEl);
  }
});

/* ---------------- INIT ---------------- */

document.addEventListener("input", (e) => {
  if (e.target.id === "ticket-reason") {
    let words = e.target.value.trim().split(/\s+/).filter(Boolean);
    if (words.length > 10) {
      e.target.value = words.slice(0, 10).join(" ");
      words = words.slice(0, 10);
    }
    document.getElementById("reason-word-count").textContent = `(${words.length}/10 words)`;
  }
  if (e.target.id === "ticket-mobile" || e.target.id === "chat-mobile") {
    e.target.value = e.target.value.replace(/\D/g, "").slice(0, 10);
  }
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && e.target.id === "chat-text-input") {
    e.preventDefault();
    handleChatInputSend();
  }
});

document.addEventListener("DOMContentLoaded", () => {
  buildBottomNav();
  document.querySelectorAll("#amount-grid [data-amt='100'], #withdraw-grid [data-amt='100']").forEach(x => x.classList.add("active"));
  navigate("screen-login", false);
});
