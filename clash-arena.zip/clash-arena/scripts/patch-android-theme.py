import re, glob

changed_any = False

# 1) Patch every styles.xml under any values*/ folder (values, values-v31, values-night, etc.)
#    Android 12+ reads its OWN splash theme (values-v31/styles.xml) separately from the
#    normal one, so patching only values/styles.xml (as before) missed that file entirely
#    on Android 12+ devices — which is almost certainly why the flash was still happening.
styles_files = glob.glob('android/app/src/main/res/values*/styles.xml')
for path in styles_files:
    with open(path) as f:
        content = f.read()
    original = content
    if 'android:windowBackground' not in content:
        content = re.sub(
            r'(<style name="[^"]*"[^>]*>)',
            r'\1\n        <item name="android:windowBackground">@android:color/white</item>',
            content
        )
    if 'windowSplashScreenBackground' not in content and 'style name="AppTheme"' in content:
        # Android 12+ system splash screen background — force white here too
        content = re.sub(
            r'(<style name="AppTheme"[^>]*>)',
            r'\1\n        <item name="android:windowSplashScreenBackground" tools:targetApi="31">@android:color/white</item>',
            content
        )
        if '<resources' in content and 'xmlns:tools' not in content:
            content = content.replace('<resources', '<resources xmlns:tools="http://schemas.android.com/tools"', 1)
    if content != original:
        with open(path, 'w') as f:
            f.write(content)
        print(f"Patched {path}")
        changed_any = True
    else:
        print(f"{path} already OK, skipping")

# 2) Patch colors.xml so colorBackground can't leak a non-white flash either
colors_files = glob.glob('android/app/src/main/res/values*/colors.xml')
for path in colors_files:
    with open(path) as f:
        content = f.read()
    original = content
    content = re.sub(r'(<color name="colorBackground">)[^<]*(</color>)', r'\1#FFFFFF\2', content)
    if content != original:
        with open(path, 'w') as f:
            f.write(content)
        print(f"Patched colorBackground in {path}")
        changed_any = True

if not styles_files:
    print("No styles.xml found under android/app/src/main/res/ — did `cap add android` run first?")

print("Done. Changed any file:", changed_any)
