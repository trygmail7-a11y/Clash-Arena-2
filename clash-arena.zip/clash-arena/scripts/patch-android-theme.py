import re, sys, glob

styles_files = glob.glob('android/app/src/main/res/values/styles.xml')
if not styles_files:
    print("styles.xml not found, skipping")
    sys.exit(0)

path = styles_files[0]
with open(path) as f:
    content = f.read()

if 'android:windowBackground' not in content:
    # Insert a guaranteed-white window background into every top-level <style> block
    content = re.sub(
        r'(<style name="[^"]*"[^>]*>)',
        r'\1\n        <item name="android:windowBackground">@android:color/white</item>',
        content
    )
    with open(path, 'w') as f:
        f.write(content)
    print("Patched styles.xml with white windowBackground")
else:
    print("windowBackground already present, skipping")
