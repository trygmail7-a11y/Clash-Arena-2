# Clash Arena — User Panel (Phase 1)

Mobile-first tournament app frontend, built to match the provided UI design.
**Status: UI/testing build with mock data.** No backend is connected yet.

## What's included

```
clash-arena/
├── www/                          → the actual web app (Capacitor's webDir)
│   ├── index.html                 → all screens (SPA, single entry point)
│   ├── css/style.css               → black & white theme matching the design reference
│   ├── js/data.js                   → mock data (shaped like the future Supabase tables)
│   ├── js/app.js                     → navigation + rendering + interactions
│   └── assets/logo.png                → app logo
├── supabase/schema.sql            → Phase 2 database schema (not yet connected — reference only)
├── resources/icon.png             → source app icon (auto-generates all Android densities)
├── resources/splash.png           → source splash screen (auto-generates all Android densities)
├── package.json                   → Capacitor dependencies
├── capacitor.config.json          → tells Capacitor the app ID + where www/ is
└── .github/workflows/build-apk.yml → GitHub Actions: auto-builds a debug APK on push
```

## Screens built

Login, Signup, Email Verify, Forgot Password, Home, Tournaments (with category filters),
Tournament Details, My Matches (Ongoing/Completed/Cancelled), Wallet, Add Money, Withdraw,
Transaction History, Giveaway, Refer & Earn, Support, Contact Us, Notifications, Profile, Settings.

All data (tournaments, matches, transactions, wallet balance) currently comes from
`js/data.js` — a mock layer shaped to match the tables in `supabase/schema.sql`,
so Phase 2 can swap in real Supabase queries without touching the HTML/CSS.

## Running it locally right now

No build step needed — it's plain HTML/CSS/JS.

```bash
cd clash-arena/www
python3 -m http.server 8000
# open http://localhost:8000 in your browser, or in Chrome DevTools' device mode for mobile view
```

## App icon, splash screen & status bar

These are now fully wired up (not left as defaults):

- **`resources/icon.png`** (1024×1024) and **`resources/splash.png`** (2732×2732) —
  the actual Clash Arena logo, generated into every Android icon/splash resolution
  automatically by the `capacitor-assets generate` step in the GitHub Actions workflow
  (and in the local build command below). You won't see the logo missing on the
  loading screen anymore, or a placeholder icon.
- **Status bar** (where the clock/battery show) is forced to white with dark icons via
  `@capacitor/status-bar`, configured in `capacitor.config.json` and applied at runtime
  in `www/js/capacitor-init.js`.
- **Splash screen** background is white and shows the logo via `@capacitor/splash-screen`,
  and is hidden by JS shortly after the app UI paints instead of Capacitor's default
  blank flash.
- All of this is inert (no-ops safely) when just opening `www/index.html` in a regular
  browser — it only activates inside the compiled Android app.

## Turning this into a debug APK — via GitHub Actions (automatic)

The repo already includes everything needed: `package.json`, `capacitor.config.json`
(pointing at the `www/` folder), and `.github/workflows/build-apk.yml`.

1. Push this whole `clash-arena` folder to a new GitHub repository (as-is — no need to
   run anything locally first).
2. Go to your repo's **Actions** tab. The **"Build Debug APK"** workflow runs automatically
   on every push to `main`/`master` (or trigger it manually from the Actions tab with
   **Run workflow**).
3. Once it finishes (green check), open the workflow run → scroll to **Artifacts** →
   download **`clash-arena-debug-apk`**. Unzip it to get `app-debug.apk`.

That's it — no Android Studio, no local Gradle setup needed. The workflow does this for you:
Node + JDK 17 setup → `npm install` → `npx cap add android` → `npx cap sync android` →
`./gradlew assembleDebug` → uploads the APK.

### Building it locally instead (optional)

```bash
# 1. Install Node.js first if you don't have it (https://nodejs.org)

# 2. From inside the clash-arena folder:
npm install
npx cap add android
npx capacitor-assets generate --android
npx cap sync android
npx cap open android

# 3. In Android Studio: Build → Build Bundle(s)/APK(s) → Build APK(s)
#    Debug APK will appear in android/app/build/outputs/apk/debug/
```

## What's NOT wired up yet (by design, since this is a testing/UI phase)

- **Supabase auth & database** — Login/Signup buttons currently just navigate + show a toast.
  Schema is ready in `supabase/schema.sql` for Phase 2.
- **Cashfree payment gateway** — "Add Money" instantly credits mock coins instead of opening
  a real checkout. Needs your Cashfree merchant App ID + Secret Key.
- **Firebase Cloud Messaging** — Notifications screen shows mock data; no real push setup yet.

Every place in `js/app.js` where a real backend call will eventually go is marked with
`// TODO(backend): ...` so Phase 2 wiring is a matter of filling those in, not rewriting the UI.

## Next steps (Phase 2, when you're ready)

1. Create a Supabase project → run `supabase/schema.sql` → get your project URL + anon key.
2. Add `@supabase/supabase-js` and replace the `TODO(backend)` blocks in `js/app.js`.
3. Add Cashfree checkout SDK for real payments; verify payment via a Supabase Edge Function webhook.
4. Add Firebase project + FCM for real push notifications.
5. Build the Admin Panel against the same schema (already designed with `status`, `is_banned`,
   `admin_note`, etc. fields for admin control).
