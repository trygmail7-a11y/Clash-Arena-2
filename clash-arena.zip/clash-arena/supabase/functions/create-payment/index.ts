// supabase/functions/create-payment/index.ts
//
// Called by the app's "Add Money" screen. Verifies the logged-in user,
// starts a ZapUPI order, saves a 'pending' row in public.payments, and
// returns the payment_url the app should open so the user can pay.
//
// Required secrets (set once in Supabase Dashboard -> Edge Functions -> Secrets):
//   ZAP_KEY = your ZapUPI key (starts with 'zap...')
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are already available automatically.

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ZAP_KEY = Deno.env.get("ZAP_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

serve(async (req) => {
  try {
    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    // Identify the user from their login session (sent automatically by supabase-js)
    const jwt = req.headers.get("Authorization")?.replace("Bearer ", "");
    const { data: { user }, error: userErr } = await supabase.auth.getUser(jwt);
    if (userErr || !user) {
      return new Response(JSON.stringify({ error: "Not logged in" }), { status: 401 });
    }

    const { amount, mobile } = await req.json();
    if (!amount || Number(amount) < 1) {
      return new Response(JSON.stringify({ error: "Enter a valid amount" }), { status: 400 });
    }

    // Unique order ID for this payment attempt
    const order_id = `CA${Date.now()}${Math.floor(Math.random() * 1000)}`;

    const zapRes = await fetch("https://pay.zapupi.com/api/create-order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        zap_key: ZAP_KEY,
        order_id,
        amount: String(amount),
        customer_mobile: mobile || "9999999999",
        remark: `Clash Arena wallet top-up | user:${user.id}`,
        // These 3 only matter if you build web result pages later; the app
        // itself polls order status instead of relying on redirects.
        success_url: "https://clasharena.app/payment-success",
        failed_url: "https://clasharena.app/payment-failed",
        timeout_url: "https://clasharena.app/payment-timeout",
        webhook_url: `${SUPABASE_URL}/functions/v1/zapupi-webhook`,
      }),
    });

    const zapData = await zapRes.json();
    if (zapData.status !== "success") {
      return new Response(
        JSON.stringify({ error: zapData.message || "Could not start payment" }),
        { status: 400 },
      );
    }

    // Save a pending payment row — the webhook will flip this to 'success' later
    await supabase.from("payments").insert({
      user_id: user.id,
      gateway: "zap_upi",
      gateway_order_id: order_id,
      amount,
      status: "pending",
      method: "upi",
    });

    return new Response(
      JSON.stringify({ payment_url: zapData.payment_url, order_id }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});
