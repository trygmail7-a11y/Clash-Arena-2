-- ==========================================================
-- CLASH ARENA — SUPABASE SCHEMA (Phase 2 reference)
-- ==========================================================
-- NOT executed against a live project yet. This file documents the
-- table structure the frontend mock data (js/data.js) is modeled on,
-- so Phase 2 can wire up real Supabase calls without changing the UI.
-- Every table includes fields an Admin Panel will need to manage it.
-- ==========================================================

create extension if not exists "uuid-ossp";

-- ---------- USERS ----------
create table public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  uid text unique not null,               -- public-facing player ID
  avatar_url text,
  is_banned boolean default false,        -- admin control
  is_verified boolean default false,
  referral_code text unique,
  referred_by uuid references public.users(id),
  created_at timestamptz default now()
);

-- ---------- WALLET ----------
create table public.wallets (
  user_id uuid primary key references public.users(id) on delete cascade,
  winning_balance numeric default 0,
  bonus_balance numeric default 0,
  cash_balance numeric default 0,
  updated_at timestamptz default now()
);

-- ---------- COIN TRANSACTIONS ----------
create table public.coin_transactions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade,
  type text not null,                     -- 'join','winning','add_money','referral','withdraw','admin_adjust'
  amount numeric not null,                -- negative for debits
  balance_type text default 'winning',    -- which balance it affects
  reference_id uuid,                      -- links to tournament/payment/withdrawal
  note text,
  created_at timestamptz default now()
);

-- ---------- PAYMENTS (Cashfree) ----------
create table public.payments (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade,
  cashfree_order_id text unique,
  amount numeric not null,
  status text default 'pending',          -- 'pending','success','failed'
  method text,                            -- upi/card/netbanking/wallet
  created_at timestamptz default now(),
  verified_at timestamptz
);

-- ---------- WITHDRAWALS ----------
create table public.withdrawals (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade,
  amount numeric not null,
  destination_type text not null,         -- 'upi','bank','paytm'
  destination_value text not null,
  status text default 'pending',          -- 'pending','processing','completed','rejected' (admin sets this)
  admin_note text,
  created_at timestamptz default now(),
  processed_at timestamptz
);

-- ---------- TOURNAMENTS ----------
create table public.tournaments (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  category text not null,                 -- 'Classic Squad','Clash Squad','Battle Royale','Lone Wolf','Solo','Duo'
  banner_url text,
  entry_fee numeric not null,
  prize_pool numeric not null,
  per_kill_reward numeric default 0,
  map text,
  mode text,
  team_type text,
  version text,
  room_type text default 'Custom',
  max_slots int not null,
  registration_ends_at timestamptz not null,
  match_starts_at timestamptz,
  rules text,
  status text default 'upcoming',         -- 'upcoming','live','completed','cancelled' (admin controlled)
  created_by uuid references public.users(id),
  created_at timestamptz default now()
);

-- ---------- TOURNAMENT ROOMS ----------
create table public.tournament_rooms (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  room_id text,                           -- in-game room ID (admin sets before match)
  room_password text,
  released_at timestamptz
);

-- ---------- PARTICIPANTS ----------
create table public.participants (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  team_name text,
  joined_at timestamptz default now(),
  unique(tournament_id, user_id)
);

-- ---------- MATCH RESULTS ----------
create table public.match_results (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  rank int,
  kills int default 0,
  prize_won numeric default 0,
  status text default 'ongoing',          -- 'ongoing','completed','cancelled'
  updated_by uuid references public.users(id), -- admin who entered result
  created_at timestamptz default now()
);

-- ---------- NOTIFICATIONS ----------
create table public.notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade, -- null = broadcast to all
  title text not null,
  body text not null,
  type text default 'announcement',       -- 'tournament_reminder','match_started','match_result','coin_added','withdrawal_update','announcement'
  is_read boolean default false,
  created_at timestamptz default now()
);

-- ---------- REDEEM CODES ----------
create table public.redeem_codes (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  reward_coins numeric default 0,
  max_uses int default 1,
  used_count int default 0,
  expires_at timestamptz,
  created_by uuid references public.users(id),
  created_at timestamptz default now()
);

create table public.redeem_code_uses (
  id uuid primary key default uuid_generate_v4(),
  code_id uuid references public.redeem_codes(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  used_at timestamptz default now(),
  unique(code_id, user_id)
);

-- ---------- GIVEAWAYS ----------
create table public.giveaways (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  banner_url text,
  reward_description text,
  ends_at timestamptz not null,
  status text default 'active',           -- 'active','ended' (admin controlled)
  created_at timestamptz default now()
);

create table public.giveaway_entries (
  id uuid primary key default uuid_generate_v4(),
  giveaway_id uuid references public.giveaways(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  entered_at timestamptz default now(),
  is_winner boolean default false,
  unique(giveaway_id, user_id)
);

-- ---------- REFERRALS ----------
create table public.referrals (
  id uuid primary key default uuid_generate_v4(),
  referrer_id uuid references public.users(id) on delete cascade,
  referred_id uuid references public.users(id) on delete cascade,
  reward_coins numeric default 50,        -- admin-configurable
  created_at timestamptz default now(),
  unique(referred_id)
);

-- ---------- SUPPORT TICKETS ----------
create table public.support_tickets (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade,
  subject text not null,
  message text not null,
  status text default 'open',             -- 'open','in_progress','resolved' (admin controlled)
  admin_reply text,
  created_at timestamptz default now(),
  resolved_at timestamptz
);

-- ---------- ANNOUNCEMENTS ----------
create table public.announcements (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  body text not null,
  is_active boolean default true,         -- admin controlled
  created_at timestamptz default now()
);

-- ==========================================================
-- ROW LEVEL SECURITY (enable + baseline policies)
-- Every table: users can only read/write their own rows.
-- Admin role (added in Phase 2) will bypass via service_role or a
-- `is_admin` claim checked in policies.
-- ==========================================================
alter table public.users enable row level security;
alter table public.wallets enable row level security;
alter table public.coin_transactions enable row level security;
alter table public.payments enable row level security;
alter table public.withdrawals enable row level security;
alter table public.participants enable row level security;
alter table public.match_results enable row level security;
alter table public.notifications enable row level security;
alter table public.support_tickets enable row level security;
alter table public.giveaway_entries enable row level security;
alter table public.referrals enable row level security;

create policy "Users read own profile" on public.users for select using (auth.uid() = id);
create policy "Users update own profile" on public.users for update using (auth.uid() = id);

create policy "Users read own wallet" on public.wallets for select using (auth.uid() = user_id);
create policy "Users read own transactions" on public.coin_transactions for select using (auth.uid() = user_id);
create policy "Users read own payments" on public.payments for select using (auth.uid() = user_id);
create policy "Users read own withdrawals" on public.withdrawals for select using (auth.uid() = user_id);
create policy "Users insert own withdrawals" on public.withdrawals for insert with check (auth.uid() = user_id);

create policy "Users read own participation" on public.participants for select using (auth.uid() = user_id);
create policy "Users join tournaments" on public.participants for insert with check (auth.uid() = user_id);

create policy "Users read own results" on public.match_results for select using (auth.uid() = user_id);

create policy "Users read own notifications" on public.notifications for select using (auth.uid() = user_id or user_id is null);

create policy "Users manage own tickets" on public.support_tickets for all using (auth.uid() = user_id);

create policy "Users read own giveaway entries" on public.giveaway_entries for select using (auth.uid() = user_id);
create policy "Users enter giveaways" on public.giveaway_entries for insert with check (auth.uid() = user_id);

create policy "Users read own referrals" on public.referrals for select using (auth.uid() = referrer_id);

-- Public read tables (tournaments, giveaways, announcements, redeem_codes list)
-- are intentionally left without RLS restriction on SELECT so all users can browse them.
alter table public.tournaments enable row level security;
create policy "Anyone can view tournaments" on public.tournaments for select using (true);

alter table public.giveaways enable row level security;
create policy "Anyone can view giveaways" on public.giveaways for select using (true);

alter table public.announcements enable row level security;
create policy "Anyone can view active announcements" on public.announcements for select using (is_active = true);
