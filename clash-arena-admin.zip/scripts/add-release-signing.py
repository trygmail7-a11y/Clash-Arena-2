#!/usr/bin/env python3
"""
Appends a release signing configuration to android/app/build.gradle, so
`./gradlew assembleRelease` produces a properly signed APK instead of an
unsigned one (which most Android phones refuse to install).

Reads the actual passwords/alias from environment variables at build time
(never hardcoded here) — set as GitHub secrets and passed in by the workflow.

Must run AFTER `npx cap add android` (so build.gradle exists) and after
android/app/release.keystore has been placed, but BEFORE the Gradle build step.

Safe to run multiple times — Gradle allows re-opening the `android { }`
block to add more configuration, so this always just appends a fresh block
rather than trying to edit the existing one in place (much less fragile
than regex-splicing into content whose exact formatting can vary).
"""

app_gradle_path = "android/app/build.gradle"
with open(app_gradle_path, "r") as f:
    content = f.read()

signing_block = """
// --- Release signing (added by scripts/add-release-signing.py) ---
android {
    signingConfigs {
        release {
            storeFile file(System.getenv("RELEASE_STORE_FILE") ?: "release.keystore")
            storePassword System.getenv("RELEASE_STORE_PASSWORD")
            keyAlias System.getenv("RELEASE_KEY_ALIAS")
            keyPassword System.getenv("RELEASE_KEY_PASSWORD")
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
"""

marker = "add-release-signing.py"
if marker not in content:
    content += signing_block
    with open(app_gradle_path, "w") as f:
        f.write(content)
    print(f"Added release signing config to {app_gradle_path}")
else:
    print(f"Release signing config already present in {app_gradle_path}")
