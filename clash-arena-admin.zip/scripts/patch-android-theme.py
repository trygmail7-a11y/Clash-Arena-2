import re, glob

changed_any = False


def force_item_white(content, item_name, value="@android:color/white"):
    """Ensure `item_name` exists with a white value inside every <style> block
    in this file. If it already exists (any value), overwrite it. If missing,
    insert it right after the opening <style> tag."""
    parts = re.split(r'(</style>)', content)
    rebuilt = ""
    for part in parts:
        if part == '</style>':
            rebuilt += part
            continue
        m = re.search(r'<style name="[^"]*"[^>]*>', part)
        if m:
            head = part[:m.end()]
            body = part[m.end():]
            pattern = rf'(<item name="{item_name}"[^>]*>)[^<]*(</item>)'
            if re.search(pattern, body):
                body = re.sub(pattern, rf'\1{value}\2', body)
            else:
                body = f'\n        <item name="{item_name}">{value}</item>' + body
            part = head + body
        rebuilt += part
    return rebuilt


# 1) Patch every styles.xml under any values*/ folder (values, values-v31, values-night, etc.)
#    Android 12+ reads its own splash theme (values-v31/styles.xml) separately, so this
#    has to cover every variant, not just the default values/styles.xml.
styles_files = glob.glob('android/app/src/main/res/values*/styles.xml')
for path in styles_files:
    with open(path) as f:
        content = f.read()
    original = content
    content = force_item_white(content, "android:windowBackground")
    content = force_item_white(content, "android:colorBackground")
    if 'v31' in path or 'style name="AppTheme"' in content:
        content = force_item_white(content, "android:windowSplashScreenBackground")
        if '<resources' in content and 'xmlns:tools' not in content:
            content = content.replace('<resources', '<resources xmlns:tools="http://schemas.android.com/tools"', 1)
    if content != original:
        with open(path, 'w') as f:
            f.write(content)
        print(f"Patched {path}")
        changed_any = True
    else:
        print(f"{path} unchanged")

# 2) Patch colors.xml so colorBackground can't leak a non-white flash either
colors_files = glob.glob('android/app/src/main/res/values*/colors.xml')
for path in colors_files:
    with open(path) as f:
        content = f.read()
    original = content
    content = re.sub(r'(<color name="colorBackground">)[^<]*(</color>)', r'\1#FFFFFF\2', content)
    if content != original:
        with open(path, 'w') as f:
            f.write(content)
        print(f"Patched colorBackground in {path}")
        changed_any = True

if not styles_files:
    print("WARNING: No styles.xml found under android/app/src/main/res/ — did `cap add android` run first?")

print("Done. Changed any file:", changed_any)
