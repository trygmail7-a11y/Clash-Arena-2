/**
 * CLASH ARENA — ADMIN PANEL V2
 * --------------------------------------------------
 * A separate mini-app from the player app, connecting to the same
 * Supabase project. Every privileged action goes through a `security
 * definer` Postgres function (see supabase/admin-panel-v2-setup.sql) that
 * checks is_admin = true first — this file never needs the service_role key.
 */

const SUPABASE_URL = "https://byxtpznjawxpiqnvebnm.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_gqpHmF1RoFePOiwEol74kg_KH4k-Pnw";
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let currentUserId = null; // the UUID currently open in the User Detail panel

/* ---------------- TOAST ---------------- */
function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  const duration = Math.max(2600, msg.length * 60);
  clearTimeout(el._hideTimer);
  el._hideTimer = setTimeout(() => el.classList.remove("show"), duration);
}

function fmtDate(d) { return d ? new Date(d).toLocaleString([], { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "—"; }
function fmtDateShort(d) { return d ? new Date(d).toLocaleDateString() : "—"; }
function toLocalInput(d) { return d ? new Date(d).toISOString().slice(0, 16) : ""; }

/* ---------------- AUTH ---------------- */
async function tryLogin() {
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value;
  const errorEl = document.getElementById("login-error");
  errorEl.textContent = "";
  if (!email || !password) { errorEl.textContent = "Enter your email and password."; return; }

  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) { errorEl.textContent = error.message; return; }

  const { data: profile } = await sb.from("users").select("is_admin, username").eq("id", data.user.id).single();
  if (!profile || !profile.is_admin) {
    errorEl.textContent = "This account doesn't have admin access.";
    await sb.auth.signOut();
    return;
  }
  showApp();
}

async function checkExistingSession() {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) return;
  const { data: profile } = await sb.from("users").select("is_admin").eq("id", session.user.id).single();
  if (profile && profile.is_admin) showApp();
}

function showApp() {
  document.getElementById("view-login").classList.add("hidden");
  document.getElementById("view-app").classList.remove("hidden");
  switchTab("dashboard");
}

document.getElementById("login-btn").addEventListener("click", tryLogin);
document.getElementById("login-password").addEventListener("keydown", (e) => { if (e.key === "Enter") tryLogin(); });
document.getElementById("logout-btn").addEventListener("click", async () => { await sb.auth.signOut(); location.reload(); });

/* ---------------- NAVIGATION ---------------- */
document.querySelectorAll(".nav-parent").forEach((btn) => {
  btn.addEventListener("click", () => {
    btn.nextElementSibling.classList.toggle("hidden");
  });
});

document.querySelectorAll(".nav-item[data-tab]").forEach((btn) => {
  btn.addEventListener("click", () => switchTab(btn.dataset.tab));
});

const TAB_LOADERS = {
  dashboard: loadDashboard,
  "users-all": () => loadUsers("all"),
  "users-active": () => loadUsers("active"),
  "users-blocked": () => loadUsers("blocked"),
  "users-activity": loadUserActivity,
  "tournaments-all": loadTournamentsAll,
  "tournaments-create": populateTournamentDropdowns,
  "tournaments-categories": loadCategories,
  "matches-upcoming": () => loadMatches("upcoming"),
  "matches-live": () => loadMatches("live"),
  "matches-completed": () => loadMatches("completed"),
  "matches-results": populateTournamentDropdowns,
  "wallet-transactions": () => loadWalletTx("tx"),
  "wallet-history": () => loadWalletTx("history"),
  "payments-deposits": loadDeposits,
  "payments-withdrawals": loadWithdrawals,
  "payments-history": loadPaymentHistory,
  "redeem-active": () => loadRedeemCodes("active"),
  "redeem-expired": () => loadRedeemCodes("expired"),
  "promotions-homebanners": loadHomeBanners,
  "promotions-banners": loadAnnouncements,
  "promotions-offers": loadGiveawaysAdmin,
  "support-tickets": loadTickets,
  "reports-overview": loadReports,
  notifications: loadSentNotifications,
  settings: loadSettings,
  "contacts-emails": loadEmails,
  "contacts-mobiles": loadMobiles,
  "admin-audit": loadAuditLog,
};

/* ---------------- MOBILE SIDEBAR TOGGLE ---------------- */
document.getElementById("hamburger-btn").addEventListener("click", () => {
  document.getElementById("sidebar").classList.add("sidebar-open");
  document.getElementById("sidebar-overlay").classList.add("active");
});
document.getElementById("sidebar-overlay").addEventListener("click", closeSidebar);
function closeSidebar() {
  document.getElementById("sidebar").classList.remove("sidebar-open");
  document.getElementById("sidebar-overlay").classList.remove("active");
}

function switchTab(tab) {
  closeSidebar();
  document.querySelectorAll(".nav-item").forEach((b) => b.classList.remove("active"));
  document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
  const navBtn = document.querySelector(`.nav-item[data-tab="${tab}"]`);
  if (navBtn) {
    navBtn.classList.add("active");
    const parentGroup = navBtn.closest(".nav-children");
    if (parentGroup) parentGroup.classList.remove("hidden");
  }
  const panel = document.getElementById("tab-" + tab);
  if (panel) panel.classList.add("active");
  if (TAB_LOADERS[tab]) TAB_LOADERS[tab]();
}

/* ---------------- DASHBOARD ---------------- */
async function loadDashboard() {
  const [users, banned, wallets, payments, withdrawals, pendingW, tournaments, redeem, tickets] = await Promise.all([
    sb.from("users").select("id", { count: "exact", head: true }),
    sb.from("users").select("id", { count: "exact", head: true }).eq("is_banned", true),
    sb.from("wallets").select("winning_balance, bonus_balance, cash_balance"),
    sb.from("payments").select("amount").eq("status", "success"),
    sb.from("withdrawals").select("amount").eq("status", "completed"),
    sb.from("withdrawals").select("id", { count: "exact", head: true }).eq("status", "pending"),
    sb.from("tournaments").select("id, status"),
    sb.from("redeem_codes").select("id, used_count"),
    sb.from("support_tickets").select("id", { count: "exact", head: true }).in("status", ["open", "in_review"]),
  ]);

  const totalCoins = (wallets.data || []).reduce((s, w) => s + (w.winning_balance || 0) + (w.bonus_balance || 0) + (w.cash_balance || 0), 0);
  const totalDeposits = (payments.data || []).reduce((s, p) => s + Number(p.amount), 0);
  const totalWithdrawn = (withdrawals.data || []).reduce((s, w) => s + Number(w.amount), 0);
  const tData = tournaments.data || [];
  const totalUsedRedeem = (redeem.data || []).reduce((s, r) => s + (r.used_count || 0), 0);

  const stats = [
    ["Total Users", users.count || 0],
    ["Blocked Users", banned.count || 0],
    ["Total Coins in Wallets", totalCoins.toLocaleString()],
    ["Total Deposits", "₹" + totalDeposits.toLocaleString()],
    ["Total Withdrawn", "₹" + totalWithdrawn.toLocaleString()],
    ["Pending Withdrawals", pendingW.count || 0],
    ["Total Tournaments", tData.length],
    ["Live Tournaments", tData.filter((t) => t.status === "live").length],
    ["Upcoming Tournaments", tData.filter((t) => t.status === "upcoming").length],
    ["Completed Tournaments", tData.filter((t) => t.status === "completed").length],
    ["Total Redeem Codes", (redeem.data || []).length],
    ["Redeem Uses", totalUsedRedeem],
    ["Pending Tickets", tickets.count || 0],
  ];
  document.getElementById("dashboard-stats").innerHTML = stats.map(([label, val]) =>
    `<div class="stat-card"><div class="stat-val">${val}</div><div class="stat-label">${label}</div></div>`
  ).join("");

  const [recentUsers, recentPayments, recentWithdrawals, recentTickets] = await Promise.all([
    sb.from("users").select("username, uid, created_at").order("created_at", { ascending: false }).limit(6),
    sb.from("payments").select("amount, status, created_at, users(username)").order("created_at", { ascending: false }).limit(6),
    sb.from("withdrawals").select("amount, status, created_at, users(username)").order("created_at", { ascending: false }).limit(6),
    sb.from("support_tickets").select("ticket_number, reason, created_at").in("status", ["open", "in_review"]).order("created_at", { ascending: false }).limit(6),
  ]);

  document.getElementById("dash-recent-users").innerHTML = (recentUsers.data || []).map((u) =>
    `<div class="mini-row"><span>${u.username} (${u.uid})</span><span>${fmtDateShort(u.created_at)}</span></div>`
  ).join("") || `<p class="hint">No users yet.</p>`;

  document.getElementById("dash-recent-payments").innerHTML = (recentPayments.data || []).map((p) =>
    `<div class="mini-row"><span>${p.users?.username || "—"}</span><span>₹${p.amount} · ${p.status}</span></div>`
  ).join("") || `<p class="hint">No payments yet.</p>`;

  document.getElementById("dash-recent-withdrawals").innerHTML = (recentWithdrawals.data || []).map((w) =>
    `<div class="mini-row"><span>${w.users?.username || "—"}</span><span>₹${w.amount} · ${w.status}</span></div>`
  ).join("") || `<p class="hint">No withdrawals yet.</p>`;

  document.getElementById("dash-recent-tickets").innerHTML = (recentTickets.data || []).map((t) =>
    `<div class="mini-row"><span>${t.ticket_number}</span><span>${(t.reason || "").slice(0, 30)}</span></div>`
  ).join("") || `<p class="hint">No pending tickets.</p>`;
}

/* ---------------- USERS ---------------- */
async function loadUsers(status) {
  let q = sb.from("users").select("*, wallets(winning_balance, bonus_balance, cash_balance)").order("created_at", { ascending: false });
  if (status === "active") q = q.eq("is_banned", false);
  if (status === "blocked") q = q.eq("is_banned", true);
  const { data, error } = await q;
  if (error) { toast("Could not load users: " + error.message); return; }
  renderUsersTable(status, data || []);
}

function renderUsersTable(status, list) {
  const tbodyId = status === "active" ? "users-active-tbody" : status === "blocked" ? "users-blocked-tbody" : "users-all-tbody";
  const tbody = document.getElementById(tbodyId);

  if (status === "blocked") {
    tbody.innerHTML = list.map((u) => `
      <tr><td>${u.uid || "—"}</td><td>${u.username || "—"}</td><td>${u.full_name || "—"}</td><td>${fmtDateShort(u.created_at)}</td>
      <td><button class="row-btn" data-view="${u.id}">View</button><button class="row-btn success" data-ban="${u.id}" data-banned="true">Unban</button></td></tr>
    `).join("") || emptyRow(5);
  } else if (status === "active") {
    tbody.innerHTML = list.map((u) => {
      const w = u.wallets || {};
      return `<tr><td>${u.uid || "—"}</td><td>${u.username || "—"}</td><td>${u.full_name || "—"}</td>
        <td>${(w.winning_balance || 0).toLocaleString()}</td><td>${(w.bonus_balance || 0).toLocaleString()}</td><td>${(w.cash_balance || 0).toLocaleString()}</td>
        <td>${fmtDateShort(u.created_at)}</td>
        <td><button class="row-btn" data-view="${u.id}">View</button><button class="row-btn danger" data-ban="${u.id}" data-banned="false">Ban</button></td></tr>`;
    }).join("") || emptyRow(8);
  } else {
    tbody.innerHTML = list.map((u) => {
      const w = u.wallets || {};
      return `<tr><td>${u.uid || "—"}</td><td>${u.username || "—"}</td><td>${u.full_name || "—"}</td><td>${u.mobile || "—"}</td>
        <td>${(w.winning_balance || 0).toLocaleString()}</td><td>${(w.bonus_balance || 0).toLocaleString()}</td><td>${(w.cash_balance || 0).toLocaleString()}</td>
        <td>${fmtDateShort(u.created_at)}</td>
        <td>${u.is_banned ? '<span class="badge badge-banned">Banned</span>' : '<span class="badge badge-active">Active</span>'}</td>
        <td><button class="row-btn" data-view="${u.id}">View</button>
        <button class="row-btn" data-coins="${u.id}" data-username="${u.username}">Coins</button>
        <button class="row-btn ${u.is_banned ? "success" : "danger"}" data-ban="${u.id}" data-banned="${u.is_banned}">${u.is_banned ? "Unban" : "Ban"}</button>
        <button class="row-btn danger" data-delete="${u.id}">Delete</button></td></tr>`;
    }).join("") || emptyRow(10);
  }

  wireUserRowButtons();
}

function emptyRow(cols) { return `<tr><td colspan="${cols}" style="text-align:center;color:var(--text-muted);padding:30px;">Nothing here yet.</td></tr>`; }

function wireUserRowButtons() {
  document.querySelectorAll("[data-view]").forEach((btn) => btn.addEventListener("click", () => openUserDetail(btn.dataset.view)));
  document.querySelectorAll("[data-coins]").forEach((btn) => btn.addEventListener("click", () => openCoinsModal(btn.dataset.coins, btn.dataset.username)));
  document.querySelectorAll("[data-ban]").forEach((btn) => btn.addEventListener("click", async () => {
    const currentlyBanned = btn.dataset.banned === "true";
    const { data, error } = await sb.rpc("admin_set_ban", { p_user_id: btn.dataset.ban, p_banned: !currentlyBanned });
    if (error || data.error) { toast((data && data.error) || error.message); return; }
    toast(currentlyBanned ? "User unbanned." : "User banned.");
    switchTab(document.querySelector(".tab-panel.active").id.replace("tab-", ""));
  }));
  document.querySelectorAll("[data-delete]").forEach((btn) => btn.addEventListener("click", async () => {
    if (!confirm("Delete this user? Their personal info will be scrubbed and the account permanently banned. This can't be undone.")) return;
    const { data, error } = await sb.rpc("admin_delete_user", { p_user_id: btn.dataset.delete });
    if (error || data.error) { toast((data && data.error) || error.message); return; }
    toast("User deleted.");
    switchTab(document.querySelector(".tab-panel.active").id.replace("tab-", ""));
  }));
}

document.getElementById("users-all-search").addEventListener("input", async (e) => {
  const q = e.target.value.trim().toLowerCase();
  const { data } = await sb.from("users").select("*, wallets(winning_balance, bonus_balance, cash_balance)").order("created_at", { ascending: false });
  const filtered = !q ? (data || []) : (data || []).filter((u) =>
    (u.username || "").toLowerCase().includes(q) || (u.uid || "").toLowerCase().includes(q) ||
    (u.full_name || "").toLowerCase().includes(q) || (u.mobile || "").toLowerCase().includes(q)
  );
  renderUsersTable("all", filtered);
});

/* ---------------- USER ACTIVITY ---------------- */
async function loadUserActivity() {
  const { data, error } = await sb.from("coin_transactions").select("*, users!user_id(username, uid)").order("created_at", { ascending: false }).limit(80);
  if (error) { toast("Could not load activity: " + error.message); return; }
  document.getElementById("users-activity-tbody").innerHTML = (data || []).map((tx) => `
    <tr><td>${fmtDate(tx.created_at)}</td><td>${tx.users?.username || "—"} (${tx.users?.uid || "—"})</td>
    <td>${tx.type}${tx.note ? " — " + tx.note : ""}</td>
    <td style="color:${tx.amount >= 0 ? "var(--success)" : "var(--danger)"}">${tx.amount >= 0 ? "+" : ""}${tx.amount}</td></tr>
  `).join("") || emptyRow(4);
}

/* ---------------- USER DETAIL ---------------- */
async function openUserDetail(userId) {
  currentUserId = userId;
  const { data, error } = await sb.rpc("admin_get_user_detail", { p_user_id: userId });
  if (error || data.error) { toast((data && data.error) || error.message); return; }

  const u = data.user, w = data.wallet || {}, t = data.totals || {};
  document.getElementById("ud-username").textContent = u.username + " (" + (u.uid || "—") + ")";
  document.getElementById("ud-profile").innerHTML = [
    ["Full Name", u.full_name || "—"], ["Mobile", u.mobile || "—"], ["Gender", u.gender || "Not Set"],
    ["Date of Birth", u.date_of_birth || "Not Set"], ["Joined", fmtDate(u.created_at)],
    ["Status", u.is_banned ? "Banned" : "Active"],
  ].map(([k, v]) => `<div class="dl-row"><span>${k}</span><span>${v}</span></div>`).join("");

  document.getElementById("ud-wallet").innerHTML = [
    ["Winning Balance", (w.winning_balance || 0).toLocaleString()],
    ["Bonus Balance", (w.bonus_balance || 0).toLocaleString()],
    ["Cash Balance", (w.cash_balance || 0).toLocaleString()],
  ].map(([k, v]) => `<div class="dl-row"><span>${k}</span><span>${v}</span></div>`).join("");

  document.getElementById("ud-totals").innerHTML = [
    ["Total Added", "₹" + (t.total_added || 0)], ["Total Spent", (t.total_spent || 0) + " coins"],
    ["Total Rewards", (t.total_rewards || 0) + " coins"], ["Total Withdrawn", "₹" + (t.total_withdrawn || 0)],
  ].map(([k, v]) => `<div class="dl-row"><span>${k}</span><span>${v}</span></div>`).join("");

  switchTab("user-detail");
  loadUserDetailSubTab("payments");
}
document.getElementById("user-detail-back").addEventListener("click", () => switchTab("users-all"));
document.getElementById("ud-add-coins-btn").addEventListener("click", () => openCoinsModal(currentUserId, document.getElementById("ud-username").textContent));
document.getElementById("ud-deduct-coins-btn").addEventListener("click", () => openCoinsModal(currentUserId, document.getElementById("ud-username").textContent));

document.querySelectorAll(".sub-tab").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".sub-tab").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    ["payments", "matches", "activity"].forEach((k) => document.getElementById(`ud-${k}-wrap`).classList.toggle("hidden", k !== btn.dataset.udtab));
    loadUserDetailSubTab(btn.dataset.udtab);
  });
});

async function loadUserDetailSubTab(tab) {
  if (!currentUserId) return;
  if (tab === "payments") {
    const { data } = await sb.from("payments").select("*").eq("user_id", currentUserId).order("created_at", { ascending: false });
    document.getElementById("ud-payments-tbody").innerHTML = (data || []).map((p) =>
      `<tr><td>${fmtDate(p.created_at)}</td><td>${p.gateway_order_id || "—"}</td><td>₹${p.amount}</td><td>${p.method}</td><td>${p.status}</td></tr>`
    ).join("") || emptyRow(5);
  } else if (tab === "matches") {
    const { data } = await sb.from("participants").select("*, tournaments(name, entry_fee, created_at), match_results(rank, prize_won)").eq("user_id", currentUserId).order("joined_at", { ascending: false });
    document.getElementById("ud-matches-tbody").innerHTML = (data || []).map((p) => {
      const r = Array.isArray(p.match_results) ? p.match_results[0] : null;
      return `<tr><td>${p.tournaments?.name || "—"}</td><td>${fmtDateShort(p.tournaments?.created_at)}</td><td>₹${p.tournaments?.entry_fee || 0}</td><td>${r ? "#" + r.rank : "—"}</td><td>${r ? "₹" + r.prize_won : "—"}</td></tr>`;
    }).join("") || emptyRow(5);
  } else {
    const { data } = await sb.from("coin_transactions").select("*").eq("user_id", currentUserId).order("created_at", { ascending: false });
    document.getElementById("ud-activity-tbody").innerHTML = (data || []).map((tx) =>
      `<tr><td>${fmtDate(tx.created_at)}</td><td>${tx.type}${tx.note ? " — " + tx.note : ""}</td><td style="color:${tx.amount >= 0 ? "var(--success)" : "var(--danger)"}">${tx.amount >= 0 ? "+" : ""}${tx.amount}</td></tr>`
    ).join("") || emptyRow(3);
  }
}

/* ---------------- COINS MODAL ---------------- */
let coinsModalUserId = null;
function openCoinsModal(userId, username) {
  coinsModalUserId = userId;
  document.getElementById("coins-modal-username").textContent = username;
  document.getElementById("coins-adjust").value = "";
  document.getElementById("coins-set").value = "";
  document.getElementById("coins-reason").value = "";
  document.getElementById("coins-modal").classList.add("active");
}
document.getElementById("coins-cancel-btn").addEventListener("click", () => document.getElementById("coins-modal").classList.remove("active"));
document.getElementById("coins-save-btn").addEventListener("click", async () => {
  const balanceType = document.getElementById("coins-type").value;
  const adjustVal = document.getElementById("coins-adjust").value;
  const setVal = document.getElementById("coins-set").value;
  const reason = document.getElementById("coins-reason").value.trim() || "Admin adjustment";
  if (!adjustVal && !setVal) { toast("Enter an amount to add/subtract, or an exact value to set."); return; }

  const result = setVal
    ? await sb.rpc("admin_set_coin_balance", { p_user_id: coinsModalUserId, p_new_amount: Number(setVal), p_balance_type: balanceType, p_note: reason })
    : await sb.rpc("admin_adjust_coins", { p_user_id: coinsModalUserId, p_amount: Number(adjustVal), p_balance_type: balanceType, p_note: reason });
  if (result.error || (result.data && result.data.error)) { toast((result.data && result.data.error) || result.error.message); return; }
  toast("Coins updated.");
  document.getElementById("coins-modal").classList.remove("active");
  if (currentUserId === coinsModalUserId && document.getElementById("tab-user-detail").classList.contains("active")) openUserDetail(coinsModalUserId);
});

/* ---------------- TOURNAMENTS ---------------- */
async function loadTournamentsAll() {
  const { data, error } = await sb.from("tournaments").select("*, tournament_rooms(room_id)").order("created_at", { ascending: false });
  if (error) { toast("Could not load tournaments: " + error.message); return; }
  document.getElementById("tournaments-all-tbody").innerHTML = (data || []).map((t) => {
    const statusBadge = t.status === "cancelled" ? '<span class="badge badge-banned">Cancelled</span>'
      : t.status === "completed" ? '<span class="badge badge-active">Completed</span>'
      : t.status === "live" ? '<span class="badge badge-pending">Live</span>'
      : '<span class="badge badge-active">Active</span>';
    const canCancel = t.status !== "cancelled" && t.status !== "completed";
    return `
    <tr><td>${t.tournament_number || "—"}</td><td class="clickable-name" data-results="${t.id}" data-tname="${t.name.replace(/"/g, "&quot;")}" style="cursor:pointer;color:var(--black);text-decoration:underline;">${t.name}</td><td>${t.category}</td><td>₹${t.entry_fee}</td><td>₹${t.prize_pool}</td><td>${t.max_slots}</td>
    <td>${statusBadge}</td>
    <td><button class="row-btn" data-results="${t.id}" data-tname="${t.name.replace(/"/g, "&quot;")}">Results</button>${canCancel ? `<button class="row-btn" data-cancel="${t.id}">Cancel</button>` : ""}<button class="row-btn" data-dup="${t.id}">Duplicate</button><button class="row-btn danger" data-tdelete="${t.id}">Delete</button></td></tr>`;
  }).join("") || emptyRow(8);

  document.querySelectorAll("[data-results]").forEach((el) => el.addEventListener("click", () => openResultsModal(el.dataset.results, el.dataset.tname)));

  document.querySelectorAll("[data-cancel]").forEach((btn) => btn.addEventListener("click", async () => {
    if (!confirm("Cancel this tournament? Every joined player will be refunded their entry fee.")) return;
    btn.disabled = true;
    const { data, error } = await sb.rpc("admin_cancel_tournament", { p_tournament_id: btn.dataset.cancel });
    if (error || data.error) { toast((data && data.error) || error.message); btn.disabled = false; return; }
    toast("Tournament cancelled and refunded.");
    loadTournamentsAll();
  }));
  document.querySelectorAll("[data-dup]").forEach((btn) => btn.addEventListener("click", async () => {
    const { data, error } = await sb.rpc("admin_duplicate_tournament", { p_tournament_id: btn.dataset.dup });
    if (error || data.error) { toast((data && data.error) || error.message); return; }
    toast("Duplicated — edit the date/time before it goes live.");
    loadTournamentsAll();
  }));
  document.querySelectorAll("[data-tdelete]").forEach((btn) => btn.addEventListener("click", async () => {
    if (!confirm("Delete this tournament permanently?")) return;
    const { data, error } = await sb.rpc("admin_delete_tournament", { p_tournament_id: btn.dataset.tdelete });
    if (error || data.error) { toast((data && data.error) || error.message); return; }
    toast("Tournament deleted.");
    loadTournamentsAll();
  }));
}

async function loadCategories() {
  const { data } = await sb.from("tournaments").select("category");
  const counts = {};
  (data || []).forEach((t) => { counts[t.category] = (counts[t.category] || 0) + 1; });
  document.getElementById("categories-tbody").innerHTML = Object.entries(counts).map(([cat, count]) =>
    `<tr><td>${cat}</td><td>${count}</td></tr>`
  ).join("") || emptyRow(2);
}

document.getElementById("create-tournament-btn").addEventListener("click", async () => {
  const rules = document.getElementById("t-rules").value.split("\n").map((r) => r.trim()).filter(Boolean);
  const payload = {
    p_name: document.getElementById("t-name").value.trim(),
    p_category: document.getElementById("t-category").value.trim(),
    p_entry_fee: Number(document.getElementById("t-entry").value || 0),
    p_prize_pool: Number(document.getElementById("t-prize").value || 0),
    p_per_kill_reward: Number(document.getElementById("t-perkill").value || 0),
    p_map: document.getElementById("t-map").value.trim(),
    p_mode: document.getElementById("t-mode").value.trim(),
    p_team_type: document.getElementById("t-team").value.trim(),
    p_version: document.getElementById("t-version").value.trim(),
    p_room_type: document.getElementById("t-roomtype").value.trim(),
    p_banner_url: document.getElementById("t-banner").value.trim() || null,
    p_max_slots: Number(document.getElementById("t-slots").value || 0),
    p_registration_ends_at: document.getElementById("t-regends").value ? new Date(document.getElementById("t-regends").value).toISOString() : null,
    p_match_starts_at: document.getElementById("t-starts").value ? new Date(document.getElementById("t-starts").value).toISOString() : null,
    p_rules: rules.join("\n"),
  };
  if (!payload.p_name || !payload.p_category || !payload.p_max_slots || !payload.p_registration_ends_at) { toast("Fill in at least Name, Category, Max Slots, and Registration Ends."); return; }
  const { data, error } = await sb.rpc("admin_create_tournament", payload);
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Tournament created!");
  ["t-name","t-category","t-entry","t-prize","t-perkill","t-slots","t-map","t-mode","t-team","t-version","t-roomtype","t-banner","t-regends","t-starts","t-rules"].forEach((id) => document.getElementById(id).value = "");
});

async function populateTournamentDropdowns() {
  // Cancelled/completed tournaments don't need a room or a result entered
  // anymore — excluding them keeps these dropdowns short and prevents
  // accidentally acting on a match that's already over.
  const { data } = await sb.from("tournaments").select("id, tournament_number, name, status")
    .not("status", "in", "(cancelled,completed)")
    .order("created_at", { ascending: false });
  const options = (data || []).map((t) => `<option value="${t.id}">${t.tournament_number} — ${t.name}</option>`).join("");
  ["r-tournament", "room-tournament", "players-tournament"].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = options;
  });
}

/* ---------------- MATCHES (tournaments filtered by status) ---------------- */
async function loadMatches(status) {
  const statusMap = { upcoming: "upcoming", live: "live", completed: "completed" };
  const { data, error } = await sb.from("tournaments").select("*, tournament_rooms(room_id)").eq("status", statusMap[status]).order("created_at", { ascending: false });
  if (error) { toast("Could not load: " + error.message); return; }
  const tbody = document.getElementById(`matches-${status}-tbody`);
  if (status === "completed") {
    tbody.innerHTML = (data || []).map((t) => `<tr><td>${t.tournament_number}</td><td>${t.name}</td><td>₹${t.entry_fee}</td><td>₹${t.prize_pool}</td></tr>`).join("") || emptyRow(4);
  } else if (status === "live") {
    tbody.innerHTML = (data || []).map((t) => `<tr><td>${t.tournament_number}</td><td>${t.name}</td><td>₹${t.entry_fee}</td><td>₹${t.prize_pool}</td><td>${t.max_slots}</td><td>${t.tournament_rooms?.[0]?.room_id ? "Set" : "—"}</td></tr>`).join("") || emptyRow(6);
  } else {
    tbody.innerHTML = (data || []).map((t) => `<tr><td>${t.tournament_number}</td><td>${t.name}</td><td>₹${t.entry_fee}</td><td>₹${t.prize_pool}</td><td>${t.max_slots}</td><td>${fmtDate(t.registration_ends_at)}</td><td>${t.tournament_rooms?.[0]?.room_id ? "Set" : "—"}</td></tr>`).join("") || emptyRow(7);
  }
}

/* ---------------- MATCH RESULTS / ROOM / PLAYERS ---------------- */
document.getElementById("submit-result-btn").addEventListener("click", async () => {
  const tournamentId = document.getElementById("r-tournament").value;
  const uid = document.getElementById("r-uid").value.trim();
  const rank = Number(document.getElementById("r-rank").value);
  const kills = Number(document.getElementById("r-kills").value || 0);
  const prize = Number(document.getElementById("r-prize").value || 0);
  if (!tournamentId || !uid || !rank) { toast("Select a tournament, and enter a UID and rank."); return; }

  const { data: player } = await sb.from("users").select("id").eq("uid", uid).single();
  if (!player) { toast("No player found with that UID."); return; }

  const { data, error } = await sb.rpc("admin_set_match_result", { p_tournament_id: tournamentId, p_user_id: player.id, p_rank: rank, p_kills: kills, p_prize_won: prize });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Result saved" + (prize > 0 ? ` — ₹${prize} credited.` : "."));
  // The in-app row is saved automatically by the RPC above — this fires
  // the actual phone push notification for it too, best-effort.
  try { await sb.functions.invoke("send-notification", { body: { user_id: player.id, title: "Match Result Declared", body: rank === 1 ? "Congratulations! You won — check My Matches." : "Your result is in — check My Matches for details." } }); } catch (e) {}
  ["r-uid","r-rank","r-kills","r-prize"].forEach((id) => document.getElementById(id).value = "");
});

document.getElementById("save-room-btn").addEventListener("click", async () => {
  const tournamentId = document.getElementById("room-tournament").value;
  const roomId = document.getElementById("room-id").value.trim();
  const roomPassword = document.getElementById("room-password").value.trim();
  // Release time is now optional — leaving it blank releases the room
  // immediately, instead of silently staying hidden forever (the old
  // behavior when this field was required but easy to misconfigure).
  const releaseAtInput = document.getElementById("room-release").value;
  const releasedAt = releaseAtInput ? new Date(releaseAtInput).toISOString() : new Date().toISOString();
  if (!tournamentId || !roomId || !roomPassword) { toast("Fill in the tournament, Room ID, and Password."); return; }

  const { data, error } = await sb.rpc("admin_set_room_details", { p_tournament_id: tournamentId, p_room_id: roomId, p_room_password: roomPassword, p_released_at: releasedAt });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Room details saved.");
  // Push-notify every joined player, not just the in-app row already saved.
  try {
    const { data: players } = await sb.rpc("admin_get_tournament_players", { p_tournament_id: tournamentId });
    for (const p of players || []) {
      try { await sb.functions.invoke("send-notification", { body: { user_id: p.user_id, title: "Room Details Ready", body: "Your Room ID & Password are ready — check My Matches." } }); } catch (e) {}
    }
  } catch (e) {}
  ["room-id","room-password","room-release"].forEach((id) => document.getElementById(id).value = "");
});

document.getElementById("view-players-btn").addEventListener("click", async () => {
  const tournamentId = document.getElementById("players-tournament").value;
  if (!tournamentId) { toast("Select a tournament."); return; }
  const { data, error } = await sb.rpc("admin_get_tournament_players", { p_tournament_id: tournamentId });
  if (error) { toast(error.message); return; }
  document.getElementById("players-tbody").innerHTML = (data || []).map((p) =>
    `<tr><td>${p.uid}</td><td>${p.username}</td><td>${p.game_uid}</td><td>${p.game_name}</td><td>${fmtDate(p.joined_at)}</td></tr>`
  ).join("") || emptyRow(5);
});

/* ---------------- WALLET ---------------- */
async function loadWalletTx(mode) {
  const { data, error } = await sb.from("coin_transactions").select("*, users!user_id(username, uid)").order("created_at", { ascending: false }).limit(150);
  if (error) { toast("Could not load: " + error.message); return; }
  const rows = (data || []).map((tx) => `
    <tr><td>${fmtDate(tx.created_at)}</td><td>${tx.users?.username || "—"} (${tx.users?.uid || "—"})</td><td>${tx.type}</td>
    <td style="color:${tx.amount >= 0 ? "var(--success)" : "var(--danger)"}">${tx.amount >= 0 ? "+" : ""}${tx.amount}</td>
    <td>${tx.balance_type}</td>${mode === "tx" ? `<td>${tx.note || "—"}</td>` : ""}</tr>
  `).join("") || emptyRow(6);
  document.getElementById(mode === "tx" ? "wallet-tx-tbody" : "wallet-history-tbody").innerHTML = rows;
}

document.getElementById("tx-search").addEventListener("input", async (e) => {
  const q = e.target.value.trim().toLowerCase();
  const { data } = await sb.from("coin_transactions").select("*, users!user_id(username, uid)").order("created_at", { ascending: false }).limit(150);
  const filtered = !q ? data : (data || []).filter((tx) => (tx.users?.username || "").toLowerCase().includes(q) || (tx.users?.uid || "").toLowerCase().includes(q));
  document.getElementById("wallet-tx-tbody").innerHTML = (filtered || []).map((tx) => `
    <tr><td>${fmtDate(tx.created_at)}</td><td>${tx.users?.username || "—"} (${tx.users?.uid || "—"})</td><td>${tx.type}</td>
    <td style="color:${tx.amount >= 0 ? "var(--success)" : "var(--danger)"}">${tx.amount >= 0 ? "+" : ""}${tx.amount}</td><td>${tx.balance_type}</td><td>${tx.note || "—"}</td></tr>
  `).join("") || emptyRow(6);
});

document.getElementById("wa-submit-btn").addEventListener("click", async () => {
  const uid = document.getElementById("wa-uid").value.trim();
  const balanceType = document.getElementById("wa-type").value;
  const amount = Number(document.getElementById("wa-amount").value);
  const reason = document.getElementById("wa-reason").value.trim() || "Admin adjustment";
  if (!uid || !amount) { toast("Enter a UID and amount."); return; }

  const { data: player } = await sb.from("users").select("id").eq("uid", uid).single();
  if (!player) { toast("No player found with that UID."); return; }

  const { data, error } = await sb.rpc("admin_adjust_coins", { p_user_id: player.id, p_amount: amount, p_balance_type: balanceType, p_note: reason });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Coins updated.");
  ["wa-uid","wa-amount","wa-reason"].forEach((id) => document.getElementById(id).value = "");
});

/* ---------------- PAYMENTS ---------------- */
async function loadDeposits() {
  const { data, error } = await sb.from("payments").select("*, users(username, uid)").order("created_at", { ascending: false }).limit(150);
  if (error) { toast("Could not load: " + error.message); return; }
  document.getElementById("deposits-tbody").innerHTML = (data || []).map((p) => `
    <tr><td>${fmtDate(p.created_at)}</td><td>${p.users?.username || "—"}</td><td>${p.gateway_order_id || "—"}</td><td>₹${p.amount}</td><td>${p.method}</td><td>${p.utr_number || "—"}</td>
    <td><span class="badge badge-${p.status === "success" ? "active" : p.status === "failed" ? "banned" : "pending"}">${p.status}</span></td></tr>
  `).join("") || emptyRow(7);
}

async function loadWithdrawals() {
  const { data, error } = await sb.from("withdrawals").select("*, users(username, uid)").order("created_at", { ascending: false });
  if (error) { toast("Could not load: " + error.message); return; }
  document.getElementById("withdrawals-tbody").innerHTML = (data || []).map((w) => `
    <tr><td>${w.users?.username || "—"} (${w.users?.uid || "—"})</td><td>₹${w.amount}</td><td>${w.destination_type.toUpperCase()} — ${w.destination_value}</td>
    <td><span class="badge badge-${w.status === "completed" ? "active" : w.status === "rejected" ? "banned" : "pending"}">${w.status}</span></td>
    <td>${fmtDateShort(w.created_at)}</td>
    <td>${w.status === "pending" || w.status === "processing" ? `<button class="row-btn success" data-wapprove="${w.id}">Mark Paid</button><button class="row-btn danger" data-wreject="${w.id}">Reject</button>` : "—"}</td></tr>
  `).join("") || emptyRow(6);

  document.querySelectorAll("[data-wapprove]").forEach((btn) => btn.addEventListener("click", () => updateWithdrawal(btn.dataset.wapprove, "completed")));
  document.querySelectorAll("[data-wreject]").forEach((btn) => btn.addEventListener("click", () => updateWithdrawal(btn.dataset.wreject, "rejected")));
}
async function updateWithdrawal(id, status) {
  const { data, error } = await sb.rpc("admin_update_withdrawal", { p_withdrawal_id: id, p_status: status });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast(status === "completed" ? "Marked as paid." : "Rejected — coins refunded to player.");
  loadWithdrawals();
}

async function loadPaymentHistory() {
  const [deposits, withdrawals] = await Promise.all([
    sb.from("payments").select("*, users(username, uid)").order("created_at", { ascending: false }).limit(100),
    sb.from("withdrawals").select("*, users(username, uid)").order("created_at", { ascending: false }).limit(100),
  ]);
  const combined = [
    ...(deposits.data || []).map((p) => ({ date: p.created_at, user: p.users, type: "Deposit", amount: p.amount, status: p.status })),
    ...(withdrawals.data || []).map((w) => ({ date: w.created_at, user: w.users, type: "Withdrawal", amount: -w.amount, status: w.status })),
  ].sort((a, b) => new Date(b.date) - new Date(a.date));

  renderPaymentHistory(combined);
}
function renderPaymentHistory(list) {
  document.getElementById("payhist-tbody").innerHTML = list.map((r) =>
    `<tr><td>${fmtDate(r.date)}</td><td>${r.user?.username || "—"} (${r.user?.uid || "—"})</td><td>${r.type}</td>
    <td style="color:${r.amount >= 0 ? "var(--success)" : "var(--danger)"}">₹${r.amount}</td><td>${r.status}</td></tr>`
  ).join("") || emptyRow(5);
}
document.getElementById("payhist-search").addEventListener("input", async (e) => {
  const q = e.target.value.trim().toLowerCase();
  const [deposits, withdrawals] = await Promise.all([
    sb.from("payments").select("*, users(username, uid)").order("created_at", { ascending: false }).limit(100),
    sb.from("withdrawals").select("*, users(username, uid)").order("created_at", { ascending: false }).limit(100),
  ]);
  let combined = [
    ...(deposits.data || []).map((p) => ({ date: p.created_at, user: p.users, type: "Deposit", amount: p.amount, status: p.status, order: p.gateway_order_id })),
    ...(withdrawals.data || []).map((w) => ({ date: w.created_at, user: w.users, type: "Withdrawal", amount: -w.amount, status: w.status, order: w.id })),
  ].sort((a, b) => new Date(b.date) - new Date(a.date));
  if (q) combined = combined.filter((r) => (r.user?.username || "").toLowerCase().includes(q) || (r.user?.uid || "").toLowerCase().includes(q) || (r.order || "").toLowerCase().includes(q));
  renderPaymentHistory(combined);
});

/* ---------------- REDEEM CODES ---------------- */
document.getElementById("create-redeem-btn").addEventListener("click", async () => {
  const code = document.getElementById("rc-code").value.trim().toUpperCase();
  const reward = Number(document.getElementById("rc-reward").value);
  const maxUses = Number(document.getElementById("rc-maxuses").value || 1);
  const expires = document.getElementById("rc-expires").value;
  if (!code || !reward) { toast("Enter a code and reward amount."); return; }

  const { data, error } = await sb.rpc("admin_create_redeem_code", { p_code: code, p_reward: reward, p_max_uses: maxUses, p_expires_at: expires ? new Date(expires).toISOString() : null });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Redeem code created!");
  ["rc-code","rc-reward","rc-maxuses","rc-expires"].forEach((id) => document.getElementById(id).value = "");
});

async function loadRedeemCodes(kind) {
  const { data, error } = await sb.from("redeem_codes").select("*").order("created_at", { ascending: false });
  if (error) { toast("Could not load: " + error.message); return; }
  const now = new Date();
  const filtered = (data || []).filter((c) => {
    const isExpired = (c.expires_at && new Date(c.expires_at) < now) || !c.is_active || c.used_count >= c.max_uses;
    return kind === "active" ? !isExpired : isExpired;
  });
  const tbody = document.getElementById(kind === "active" ? "redeem-active-tbody" : "redeem-expired-tbody");
  tbody.innerHTML = filtered.map((c) => `
    <tr><td><strong>${c.code}</strong></td><td>${c.reward_coins} coins</td><td>${c.used_count}</td><td>${c.max_uses}</td>
    <td>${c.expires_at ? fmtDateShort(c.expires_at) : "Never"}</td>
    <td><button class="row-btn" data-viewredeemers="${c.id}" data-code="${c.code}">View Users</button>
    ${kind === "active" ? `<button class="row-btn danger" data-toggle="${c.id}" data-active="false">Disable</button>` : `<button class="row-btn success" data-toggle="${c.id}" data-active="true">Enable</button>`}
    </td></tr>
  `).join("") || emptyRow(6);

  document.querySelectorAll("[data-viewredeemers]").forEach((btn) => btn.addEventListener("click", () => openRedeemersModal(btn.dataset.viewredeemers, btn.dataset.code)));
  document.querySelectorAll("[data-toggle]").forEach((btn) => btn.addEventListener("click", async () => {
    const { error } = await sb.rpc("admin_toggle_redeem_code", { p_code_id: btn.dataset.toggle, p_is_active: btn.dataset.active === "true" });
    if (error) { toast(error.message); return; }
    toast("Updated.");
    loadRedeemCodes(kind);
  }));
}

async function openRedeemersModal(codeId, code) {
  document.getElementById("redeemers-code-label").textContent = code;
  const { data, error } = await sb.rpc("admin_get_redeem_code_users", { p_code_id: codeId });
  if (error) { toast(error.message); return; }
  document.getElementById("redeemers-tbody").innerHTML = (data || []).map((r) =>
    `<tr><td>${r.username} (${r.uid})</td><td>${r.mobile || "—"}</td><td>${fmtDate(r.redeemed_at)}</td><td>—</td></tr>`
  ).join("") || emptyRow(4);
  document.getElementById("redeemers-modal").classList.add("active");
}
document.getElementById("redeemers-close-btn").addEventListener("click", () => document.getElementById("redeemers-modal").classList.remove("active"));

/* ---------------- PROMOTIONS: HOME BANNERS ---------------- */
async function loadHomeBanners() {
  const { data, error } = await sb.from("banners").select("*").order("sort_order", { ascending: true });
  if (error) { toast("Could not load: " + error.message); return; }
  document.getElementById("homebanners-tbody").innerHTML = (data || []).map((b) => `
    <tr><td><img src="${b.image_url}" style="width:120px;height:48px;object-fit:cover;border-radius:6px;" onerror="this.style.opacity=0.2" /></td>
    <td>${b.link_url ? `<a href="${b.link_url}" target="_blank" rel="noopener">${b.link_url.slice(0, 30)}…</a>` : "—"}</td>
    <td>${b.sort_order}</td>
    <td>${b.is_active ? '<span class="badge badge-active">Active</span>' : '<span class="badge badge-banned">Hidden</span>'}</td>
    <td><button class="row-btn" data-bantoggle="${b.id}" data-active="${!b.is_active}">${b.is_active ? "Hide" : "Show"}</button>
    <button class="row-btn danger" data-bandelete="${b.id}">Delete</button></td></tr>
  `).join("") || emptyRow(5);

  document.querySelectorAll("[data-bantoggle]").forEach((btn) => btn.addEventListener("click", async () => {
    await sb.rpc("admin_toggle_banner", { p_id: btn.dataset.bantoggle, p_is_active: btn.dataset.active === "true" });
    loadHomeBanners();
  }));
  document.querySelectorAll("[data-bandelete]").forEach((btn) => btn.addEventListener("click", async () => {
    if (!confirm("Delete this banner?")) return;
    await sb.rpc("admin_delete_banner", { p_id: btn.dataset.bandelete });
    toast("Banner deleted.");
    loadHomeBanners();
  }));
}
document.getElementById("create-banner-btn").addEventListener("click", async () => {
  const image = document.getElementById("hb-image").value.trim();
  const link = document.getElementById("hb-link").value.trim();
  const order = Number(document.getElementById("hb-order").value || 0);
  if (!image) { toast("Enter an image URL."); return; }
  const { data, error } = await sb.rpc("admin_create_banner", { p_image_url: image, p_link_url: link || null, p_sort_order: order });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Banner added!");
  ["hb-image","hb-link"].forEach((id) => document.getElementById(id).value = "");
  document.getElementById("hb-order").value = "0";
  loadHomeBanners();
});

/* ---------------- PROMOTIONS: ANNOUNCEMENTS ---------------- */
async function loadAnnouncements() {
  const { data, error } = await sb.from("announcements").select("*").order("created_at", { ascending: false });
  if (error) { toast("Could not load: " + error.message); return; }
  document.getElementById("announcements-tbody").innerHTML = (data || []).map((a) => `
    <tr><td>${a.title}</td><td>${(a.body || "").slice(0, 60)}</td>
    <td>${a.is_active ? '<span class="badge badge-active">Active</span>' : '<span class="badge badge-banned">Hidden</span>'}</td>
    <td><button class="row-btn" data-antoggle="${a.id}" data-active="${!a.is_active}">${a.is_active ? "Hide" : "Show"}</button></td></tr>
  `).join("") || emptyRow(4);

  document.querySelectorAll("[data-antoggle]").forEach((btn) => btn.addEventListener("click", async () => {
    await sb.rpc("admin_toggle_announcement", { p_id: btn.dataset.antoggle, p_is_active: btn.dataset.active === "true" });
    loadAnnouncements();
  }));
}
document.getElementById("create-announcement-btn").addEventListener("click", async () => {
  const title = document.getElementById("an-title").value.trim();
  const body = document.getElementById("an-body").value.trim();
  if (!title || !body) { toast("Enter a title and body."); return; }
  const { data, error } = await sb.rpc("admin_create_announcement", { p_title: title, p_body: body });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Announcement posted!");
  ["an-title","an-body"].forEach((id) => document.getElementById(id).value = "");
  loadAnnouncements();
});

/* ---------------- PROMOTIONS: GIVEAWAYS ---------------- */
async function loadGiveawaysAdmin() {
  const { data, error } = await sb.from("giveaways").select("*").order("created_at", { ascending: false });
  if (error) { toast("Could not load: " + error.message); return; }
  document.getElementById("giveaways-tbody").innerHTML = (data || []).map((g) =>
    `<tr><td>${g.title}</td><td>${g.reward_description || "—"}</td><td>${fmtDateShort(g.ends_at)}</td><td>${g.status}</td>
    <td><button class="row-btn" data-viewentries="${g.id}" data-gtitle="${g.title.replace(/"/g, "&quot;")}">Participants</button>
    <button class="row-btn danger" data-gdelete="${g.id}">Delete</button></td></tr>`
  ).join("") || emptyRow(5);

  document.querySelectorAll("[data-viewentries]").forEach((btn) => btn.addEventListener("click", () => openGiveawayEntriesModal(btn.dataset.viewentries, btn.dataset.gtitle)));
  document.querySelectorAll("[data-gdelete]").forEach((btn) => btn.addEventListener("click", async () => {
    if (!confirm("Delete this giveaway?")) return;
    const { data, error } = await sb.rpc("admin_delete_giveaway", { p_giveaway_id: btn.dataset.gdelete });
    if (error || data.error) { toast((data && data.error) || error.message); return; }
    toast("Giveaway deleted.");
    loadGiveawaysAdmin();
  }));
}

let currentGiveawayId = null;
async function openGiveawayEntriesModal(giveawayId, title) {
  currentGiveawayId = giveawayId;
  document.getElementById("redeemers-code-label").textContent = title;
  const { data, error } = await sb.rpc("admin_get_giveaway_entries", { p_giveaway_id: giveawayId });
  if (error) { toast(error.message); return; }
  document.getElementById("redeemers-tbody").innerHTML = (data || []).map((r) => `
    <tr><td>${r.username} (${r.uid})<br><span style="font-size:11px;color:var(--text-muted);">${r.email}</span></td>
    <td>${r.mobile || "—"}</td><td>${fmtDate(r.entered_at)}</td>
    <td>${r.is_winner ? '<span class="badge badge-active">🏆 Winner</span>' : `<button class="row-btn" data-selectwinner="${r.user_id}">Select as Winner</button>`}</td></tr>
  `).join("") || emptyRow(4);

  document.querySelectorAll("[data-selectwinner]").forEach((btn) => btn.addEventListener("click", async () => {
    if (!confirm("Select this person as the winner? They'll get a congratulations notification right away.")) return;
    const { data: result, error: selectError } = await sb.rpc("admin_select_giveaway_winner", { p_giveaway_id: currentGiveawayId, p_user_id: btn.dataset.selectwinner });
    if (selectError || result.error) { toast((result && result.error) || selectError.message); return; }
    toast("Winner selected! They've been notified.");
    try { await sb.functions.invoke("send-notification", { body: { user_id: btn.dataset.selectwinner, title: "Congratulations! You Won!", body: "You've been selected as a giveaway winner! Open the app to see the details." } }); } catch (e) {}
    openGiveawayEntriesModal(currentGiveawayId, title);
    loadGiveawaysAdmin();
  }));
  document.getElementById("redeemers-modal").classList.add("active");
}

document.getElementById("create-giveaway-btn").addEventListener("click", async () => {
  const title = document.getElementById("g-title").value.trim();
  const banner = document.getElementById("g-banner").value.trim();
  const reward = document.getElementById("g-reward").value.trim();
  const ends = document.getElementById("g-ends").value;
  if (!title || !ends) { toast("Enter at least a title and end date."); return; }
  const { data, error } = await sb.rpc("admin_create_giveaway", { p_title: title, p_banner_url: banner || null, p_reward_description: reward || null, p_ends_at: new Date(ends).toISOString() });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Giveaway created!");
  ["g-title","g-banner","g-reward","g-ends"].forEach((id) => document.getElementById(id).value = "");
  loadGiveawaysAdmin();
});

/* ---------------- NOTIFICATIONS ---------------- */
document.getElementById("n-target").addEventListener("change", (e) => {
  document.getElementById("n-uid-field").style.display = e.target.value === "one" ? "block" : "none";
});
document.getElementById("send-notification-btn").addEventListener("click", async () => {
  const target = document.getElementById("n-target").value;
  const notifType = document.getElementById("n-type").value; // "push" | "inapp" | "mobileonly"
  const title = document.getElementById("n-title").value.trim();
  const body = document.getElementById("n-body").value.trim();
  const imageUrl = document.getElementById("n-image").value.trim();
  if (!title || !body) { toast("Enter a title and message."); return; }

  let userId = null;
  if (target === "one") {
    const uid = document.getElementById("n-uid").value.trim();
    if (!uid) { toast("Enter a player UID."); return; }
    const { data: player } = await sb.from("users").select("id").eq("uid", uid).single();
    if (!player) { toast("No player found with that UID."); return; }
    userId = player.id;
  }

  // "Mobile Push Only" skips saving any in-app notification row entirely —
  // it just looks up who the push should go to, and fires real phone
  // notifications straight away.
  if (notifType === "mobileonly") {
    const { data: ids, error: idsError } = await sb.rpc("admin_get_target_user_ids", { p_target: target, p_user_id: userId });
    if (idsError) { toast(idsError.message); return; }
    const targetIds = ids || [];
    let sentCount = 0;
    let lastError = "";
    for (const id of targetIds) {
      // invoke() resolves with { data, error } — it does NOT throw for a
      // failed push, so the error has to be checked explicitly, or a
      // total failure would silently look like a success.
      const result = await sb.functions.invoke("send-notification", { body: { user_id: id, title, body, image_url: imageUrl || undefined } });
      if (result.error) { lastError = result.error.message; continue; }
      sentCount++;
    }
    toast(sentCount > 0
      ? `Mobile push sent to ${sentCount} player(s) (no in-app entry saved).`
      : `Push failed for all recipients: ${lastError}`);
    ["n-uid","n-title","n-body","n-image"].forEach((id) => document.getElementById(id).value = "");
    return;
  }

  const sendPush = notifType === "push";
  const { data, error } = await sb.rpc("admin_send_notification", { p_target: target, p_user_id: userId, p_title: title, p_body: body, p_send_push: sendPush });
  if (error || data.error) { toast((data && data.error) || error.message); return; }

  let pushWarning = "";
  if (sendPush) {
    try {
      const pushResult = await sb.functions.invoke("send-notification", { body: { user_id: userId, title, body, image_url: imageUrl || undefined } });
      if (pushResult.error) pushWarning = " (push notification failed: " + pushResult.error.message + ")";
      else if (pushResult.data && pushResult.data.sent === 0) pushWarning = " (saved, but no devices are registered for push yet)";
    } catch (e) {
      pushWarning = " (push notification failed: " + e.message + ")";
    }
  }

  toast(`Notification sent to ${data.count} player(s)!${pushWarning}`);
  ["n-uid","n-title","n-body","n-image"].forEach((id) => document.getElementById(id).value = "");
  loadSentNotifications();
});

async function loadSentNotifications() {
  const { data, error } = await sb.rpc("admin_get_sent_notifications");
  if (error) { toast("Could not load: " + error.message); return; }
  document.getElementById("sent-notifications-tbody").innerHTML = (data || []).map((n) => `
    <tr><td>${n.title}</td><td>${(n.body || "").slice(0, 50)}</td><td>${n.target_count}</td>
    <td>${n.push_sent ? "In-App + Push" : "In-App Only"}</td><td>${fmtDate(n.first_sent_at)}</td>
    <td><button class="row-btn danger" data-delnotif-title="${n.title.replace(/"/g, "&quot;")}" data-delnotif-body="${(n.body || "").replace(/"/g, "&quot;")}">Delete</button></td></tr>
  `).join("") || emptyRow(6);

  document.querySelectorAll("[data-delnotif-title]").forEach((btn) => btn.addEventListener("click", async () => {
    if (!confirm("Delete this notification for everyone who received it?")) return;
    const { error } = await sb.rpc("admin_delete_notification_batch", { p_title: btn.dataset.delnotifTitle, p_body: btn.dataset.delnotifBody });
    if (error) { toast(error.message); return; }
    toast("Deleted.");
    loadSentNotifications();
  }));
}


/* ---------------- SUPPORT TICKETS ---------------- */
let currentTicketId = null;
async function loadTickets() {
  const filter = document.getElementById("ticket-filter").value;
  let q = sb.from("support_tickets").select("*, users(username, uid), support_categories(label)").order("created_at", { ascending: false });
  if (filter !== "all") q = q.eq("status", filter);
  const { data, error } = await q;
  if (error) { toast("Could not load: " + error.message); return; }
  document.getElementById("tickets-tbody").innerHTML = (data || []).map((t) => `
    <tr><td>${t.ticket_number}</td><td>${t.users?.username || "—"}</td><td>${t.support_categories?.label || "—"}</td>
    <td>${(t.reason || "").slice(0, 40)}</td><td><span class="badge badge-pending">${t.status}</span></td><td>${fmtDateShort(t.created_at)}</td>
    <td><button class="row-btn" data-reply="${t.id}" data-num="${t.ticket_number}" data-reason="${(t.reason || "").replace(/"/g, "&quot;")}">Reply</button></td></tr>
  `).join("") || emptyRow(7);

  document.querySelectorAll("[data-reply]").forEach((btn) => btn.addEventListener("click", () => {
    currentTicketId = btn.dataset.reply;
    document.getElementById("ticket-modal-number").textContent = btn.dataset.num;
    document.getElementById("ticket-modal-reason").textContent = btn.dataset.reason;
    document.getElementById("ticket-reply-text").value = "";
    document.getElementById("ticket-modal").classList.add("active");
  }));
}
document.getElementById("ticket-filter").addEventListener("change", loadTickets);
document.getElementById("ticket-cancel-btn").addEventListener("click", () => document.getElementById("ticket-modal").classList.remove("active"));
document.getElementById("ticket-send-btn").addEventListener("click", async () => {
  const message = document.getElementById("ticket-reply-text").value.trim();
  const status = document.getElementById("ticket-reply-status").value;
  if (!message) { toast("Enter a reply."); return; }
  const { data, error } = await sb.rpc("admin_reply_ticket", { p_ticket_id: currentTicketId, p_message: message, p_new_status: status });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Reply sent.");
  document.getElementById("ticket-modal").classList.remove("active");
  loadTickets();
});

/* ---------------- REPORTS ---------------- */
async function loadReports() {
  const [users, payments, withdrawals, tournaments, matches] = await Promise.all([
    sb.from("users").select("id, created_at"),
    sb.from("payments").select("amount, status, created_at"),
    sb.from("withdrawals").select("amount, status"),
    sb.from("tournaments").select("id, status, entry_fee"),
    sb.from("match_results").select("id"),
  ]);
  const uData = users.data || [];
  const pData = (payments.data || []).filter((p) => p.status === "success");
  const wData = (withdrawals.data || []).filter((w) => w.status === "completed");
  const last7 = uData.filter((u) => new Date(u.created_at) > new Date(Date.now() - 7 * 86400000)).length;
  const revenue = pData.reduce((s, p) => s + Number(p.amount), 0) - wData.reduce((s, w) => s + Number(w.amount), 0);

  const stats = [
    ["Total Users", uData.length], ["New Users (7d)", last7],
    ["Total Deposits", "₹" + pData.reduce((s, p) => s + Number(p.amount), 0).toLocaleString()],
    ["Total Withdrawn", "₹" + wData.reduce((s, w) => s + Number(w.amount), 0).toLocaleString()],
    ["Net Revenue (est.)", "₹" + revenue.toLocaleString()],
    ["Total Tournaments", (tournaments.data || []).length],
    ["Matches Completed", (matches.data || []).length],
  ];
  document.getElementById("reports-stats").innerHTML = stats.map(([label, val]) =>
    `<div class="stat-card"><div class="stat-val">${val}</div><div class="stat-label">${label}</div></div>`
  ).join("");
}

/* ---------------- SETTINGS ---------------- */
async function loadSettings() {
  const { data, error } = await sb.from("app_settings").select("*").order("key");
  if (error) { toast("Could not load: " + error.message); return; }
  const socialKeys = ["social_facebook_url", "social_instagram_url", "social_youtube_url", "social_telegram_url"];
  const skip = ["referral_reward_coins", "maintenance_mode", "min_app_version", "update_url", ...socialKeys]; // shown in their own dedicated sections
  document.getElementById("settings-fields").innerHTML = (data || []).filter((s) => !skip.includes(s.key)).map((s) => `
    <div class="field"><label>${s.key.replace(/_/g, " ")}</label><input type="text" data-setting="${s.key}" value="${(s.value || "").replace(/"/g, "&quot;")}" />
    ${s.description ? `<p class="hint" style="margin-top:4px;">${s.description}</p>` : ""}</div>
  `).join("");

  const referral = (data || []).find((s) => s.key === "referral_reward_coins");
  if (referral) document.getElementById("referral-reward-input").value = referral.value;

  const facebook = (data || []).find((s) => s.key === "social_facebook_url");
  const instagram = (data || []).find((s) => s.key === "social_instagram_url");
  const youtube = (data || []).find((s) => s.key === "social_youtube_url");
  const telegram = (data || []).find((s) => s.key === "social_telegram_url");
  if (facebook) document.getElementById("social-facebook-input").value = facebook.value;
  if (instagram) document.getElementById("social-instagram-input").value = instagram.value;
  if (youtube) document.getElementById("social-youtube-input").value = youtube.value;
  if (telegram) document.getElementById("social-telegram-input").value = telegram.value;

  const maintenance = (data || []).find((s) => s.key === "maintenance_mode");
  const minVersion = (data || []).find((s) => s.key === "min_app_version");
  const updateUrl = (data || []).find((s) => s.key === "update_url");
  const maintBtn = document.getElementById("maintenance-toggle-btn");
  const isOn = maintenance && maintenance.value === "true";
  maintBtn.textContent = isOn ? "🔴 ON — App is blocked for everyone" : "🟢 OFF — App is live";
  maintBtn.dataset.on = isOn ? "true" : "false";
  maintBtn.style.background = isOn ? "#fdecec" : "#e6f6ec";
  maintBtn.style.borderColor = isOn ? "#f3b3b3" : "#bfe6cd";
  maintBtn.style.color = isOn ? "var(--danger)" : "var(--success)";
  if (minVersion) document.getElementById("min-version-input").value = minVersion.value;
  if (updateUrl) document.getElementById("update-url-input").value = updateUrl.value;
}
document.getElementById("maintenance-toggle-btn").addEventListener("click", async function () {
  const willTurnOn = this.dataset.on !== "true";
  if (willTurnOn && !confirm("Turn ON maintenance mode? The app will be completely unusable for every player until you turn it back off.")) return;
  const { data, error } = await sb.rpc("admin_update_setting", { p_key: "maintenance_mode", p_value: willTurnOn ? "true" : "false" });
  if (error || (data && data.error)) { toast((data && data.error) || error.message); return; }
  toast(willTurnOn ? "Maintenance mode is now ON." : "Maintenance mode is now OFF.");
  loadSettings();
});
document.getElementById("save-app-control-btn").addEventListener("click", async () => {
  const minVersion = document.getElementById("min-version-input").value.trim();
  const updateUrl = document.getElementById("update-url-input").value.trim();
  if (!minVersion) { toast("Enter a minimum version, e.g. 1.0.0"); return; }
  const r1 = await sb.rpc("admin_update_setting", { p_key: "min_app_version", p_value: minVersion });
  if (r1.error || (r1.data && r1.data.error)) { toast("Failed to save version: " + ((r1.data && r1.data.error) || r1.error.message)); return; }
  const r2 = await sb.rpc("admin_update_setting", { p_key: "update_url", p_value: updateUrl });
  if (r2.error || (r2.data && r2.data.error)) { toast("Failed to save update URL: " + ((r2.data && r2.data.error) || r2.error.message)); return; }
  toast("App control settings saved.");
  loadSettings();
});
document.getElementById("save-settings-btn").addEventListener("click", async () => {
  const inputs = document.querySelectorAll("[data-setting]");
  for (const input of inputs) {
    const r = await sb.rpc("admin_update_setting", { p_key: input.dataset.setting, p_value: input.value });
    if (r.error || (r.data && r.data.error)) { toast(`Failed to save "${input.dataset.setting}": ` + ((r.data && r.data.error) || r.error.message)); return; }
  }
  toast("Settings saved.");
  loadSettings();
});
document.getElementById("save-referral-btn").addEventListener("click", async () => {
  const val = Number(document.getElementById("referral-reward-input").value);
  if (!val || val < 0) { toast("Enter a valid amount."); return; }
  const { data, error } = await sb.rpc("admin_set_referral_reward", { p_amount: val });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Referral reward updated to " + val + " coins.");
});

document.getElementById("save-social-links-btn").addEventListener("click", async () => {
  const links = {
    social_facebook_url: document.getElementById("social-facebook-input").value.trim(),
    social_instagram_url: document.getElementById("social-instagram-input").value.trim(),
    social_youtube_url: document.getElementById("social-youtube-input").value.trim(),
    social_telegram_url: document.getElementById("social-telegram-input").value.trim(),
  };
  for (const [key, value] of Object.entries(links)) {
    const r = await sb.rpc("admin_update_setting", { p_key: key, p_value: value });
    if (r.error || (r.data && r.data.error)) { toast(`Failed to save ${key}: ` + ((r.data && r.data.error) || r.error.message)); return; }
  }
  toast("Social links saved.");
});

/* ---------------- AUDIT LOG ---------------- */
async function loadAuditLog() {
  const { data, error } = await sb.from("admin_audit_log").select("*, users(username)").order("created_at", { ascending: false }).limit(200);
  if (error) { toast("Could not load: " + error.message); return; }
  document.getElementById("audit-tbody").innerHTML = (data || []).map((a) =>
    `<tr><td>${fmtDate(a.created_at)}</td><td>${a.action} ${a.users?.username ? "by " + a.users.username : ""}</td><td>${JSON.stringify(a.details || {})}</td></tr>`
  ).join("") || emptyRow(3);
}

/* ---------------- CONTACTS: EMAILS / MOBILES ---------------- */
function downloadCsv(filename, headers, rows) {
  const csvLines = [headers.join(",")];
  rows.forEach((row) => {
    csvLines.push(row.map((cell) => `"${String(cell ?? "").replace(/"/g, '""')}"`).join(","));
  });
  const blob = new Blob([csvLines.join("\n")], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

let lastEmailsData = [];
async function loadEmails() {
  const { data, error } = await sb.rpc("admin_get_all_emails");
  if (error) { toast("Could not load: " + error.message); return; }
  lastEmailsData = data || [];
  document.getElementById("emails-tbody").innerHTML = lastEmailsData.map((r) =>
    `<tr><td>${r.uid}</td><td>${r.username}</td><td>${r.email}</td><td>${fmtDateShort(r.joined_at)}</td></tr>`
  ).join("") || emptyRow(4);
}
document.getElementById("download-emails-btn").addEventListener("click", () => {
  downloadCsv("clash-arena-emails.csv", ["UID", "Username", "Email", "Joined"],
    lastEmailsData.map((r) => [r.uid, r.username, r.email, fmtDateShort(r.joined_at)]));
});

let lastMobilesData = [];
async function loadMobiles() {
  const { data, error } = await sb.rpc("admin_get_all_mobiles");
  if (error) { toast("Could not load: " + error.message); return; }
  lastMobilesData = data || [];
  document.getElementById("mobiles-tbody").innerHTML = lastMobilesData.map((r) =>
    `<tr><td>${r.uid}</td><td>${r.username}</td><td>${r.mobile || ""}</td><td>${fmtDateShort(r.joined_at)}</td></tr>`
  ).join("") || emptyRow(4);
}
document.getElementById("download-mobiles-btn").addEventListener("click", () => {
  downloadCsv("clash-arena-mobiles.csv", ["UID", "Username", "Mobile", "Joined"],
    lastMobilesData.map((r) => [r.uid, r.username, r.mobile || "", fmtDateShort(r.joined_at)]));
});

/* ---------------- MANAGE RESULTS MODAL (all players, one place) ---------------- */
async function openResultsModal(tournamentId, tName) {
  document.getElementById("results-modal-tname").textContent = tName;
  const { data: players, error } = await sb.rpc("admin_get_tournament_players", { p_tournament_id: tournamentId });
  if (error) { toast(error.message); return; }

  // Pull in any results already entered, so re-opening shows existing values.
  const { data: existing } = await sb.from("match_results").select("*").eq("tournament_id", tournamentId);
  const existingByUser = {};
  (existing || []).forEach((r) => { existingByUser[r.user_id] = r; });

  document.getElementById("results-modal-tbody").innerHTML = (players || []).map((p) => {
    const r = existingByUser[p.user_id] || {};
    return `
    <tr>
      <td>${p.username} (${p.uid})</td>
      <td><input type="number" class="results-input" data-rank="${p.user_id}" value="${r.rank ?? ""}" style="width:60px;padding:6px;border:1px solid var(--border);border-radius:6px;" /></td>
      <td><input type="number" class="results-input" data-kills="${p.user_id}" value="${r.kills ?? 0}" style="width:60px;padding:6px;border:1px solid var(--border);border-radius:6px;" /></td>
      <td><input type="number" class="results-input" data-prize="${p.user_id}" value="${r.prize_won ?? 0}" style="width:80px;padding:6px;border:1px solid var(--border);border-radius:6px;" /></td>
      <td><button class="row-btn" data-saveresult="${p.user_id}">${r.rank ? "Update" : "Save"}</button></td>
    </tr>`;
  }).join("") || emptyRow(5);

  document.querySelectorAll("[data-saveresult]").forEach((btn) => btn.addEventListener("click", async () => {
    const userId = btn.dataset.saveresult;
    const rank = Number(document.querySelector(`[data-rank="${userId}"]`).value);
    const kills = Number(document.querySelector(`[data-kills="${userId}"]`).value || 0);
    const prize = Number(document.querySelector(`[data-prize="${userId}"]`).value || 0);
    if (!rank) { toast("Enter a rank for this player."); return; }
    btn.disabled = true;
    const { data, error: saveError } = await sb.rpc("admin_set_match_result", { p_tournament_id: tournamentId, p_user_id: userId, p_rank: rank, p_kills: kills, p_prize_won: prize });
    if (saveError || data.error) { toast((data && data.error) || saveError.message); btn.disabled = false; return; }
    try { await sb.functions.invoke("send-notification", { body: { user_id: userId, title: "Match Result Declared", body: rank === 1 ? "Congratulations! You won — check My Matches." : "Your result is in — check My Matches for details." } }); } catch (e) {}
    btn.textContent = "Saved ✓";
    setTimeout(() => { btn.textContent = "Update"; btn.disabled = false; }, 1500);
  }));

  document.getElementById("results-modal").classList.add("active");
}
document.getElementById("results-modal-close-btn").addEventListener("click", () => {
  document.getElementById("results-modal").classList.remove("active");
  loadTournamentsAll();
});

/* ---------------- BOOT ---------------- */
checkExistingSession();
