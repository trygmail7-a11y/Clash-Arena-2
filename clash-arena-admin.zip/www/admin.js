/**
 * CLASH ARENA — ADMIN PANEL
 * --------------------------------------------------
 * A separate mini-app from the player app, but connects to the exact same
 * Supabase project. Every privileged action (ban, add coins, create a
 * tournament, etc.) goes through a `security definer` Postgres function
 * (see supabase/admin-panel-setup.sql) that checks the logged-in account
 * has is_admin = true before doing anything — so this file never needs
 * the powerful service_role key, just a normal admin login.
 */

const SUPABASE_URL = "https://byxtpznjawxpiqnvebnm.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_gqpHmF1RoFePOiwEol74kg_KH4k-Pnw";
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let allUsers = [];
let allTournaments = [];

/* ---------------- TOAST ---------------- */
function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2600);
}

/* ---------------- AUTH ---------------- */
async function tryLogin() {
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value;
  const errorEl = document.getElementById("login-error");
  errorEl.textContent = "";
  if (!email || !password) { errorEl.textContent = "Enter your email and password."; return; }

  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) { errorEl.textContent = error.message; return; }

  const { data: profile } = await sb.from("users").select("is_admin, username").eq("id", data.user.id).single();
  if (!profile || !profile.is_admin) {
    errorEl.textContent = "This account doesn't have admin access.";
    await sb.auth.signOut();
    return;
  }

  showApp();
}

async function checkExistingSession() {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) return;
  const { data: profile } = await sb.from("users").select("is_admin").eq("id", session.user.id).single();
  if (profile && profile.is_admin) showApp();
}

function showApp() {
  document.getElementById("view-login").classList.add("hidden");
  document.getElementById("view-app").classList.remove("hidden");
  loadAllData();
}

document.getElementById("login-btn").addEventListener("click", tryLogin);
document.getElementById("login-password").addEventListener("keydown", (e) => { if (e.key === "Enter") tryLogin(); });
document.getElementById("logout-btn").addEventListener("click", async () => {
  await sb.auth.signOut();
  location.reload();
});

/* ---------------- TAB NAVIGATION ---------------- */
document.querySelectorAll(".nav-item").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
  });
});

function loadAllData() {
  fetchUsers();
  fetchTournaments();
  fetchWithdrawals();
  fetchGiveaways();
  fetchRedeemCodes();
  fetchReferralReward();
}

/* ---------------- USERS ---------------- */
async function fetchUsers() {
  const { data, error } = await sb
    .from("users")
    .select("*, wallets(winning_balance, bonus_balance, cash_balance)")
    .order("created_at", { ascending: false });
  if (error) { toast("Could not load users: " + error.message); return; }
  allUsers = data || [];
  renderUsers(allUsers);
}

function renderUsers(list) {
  document.getElementById("users-tbody").innerHTML = list.map((u) => {
    const w = u.wallets || {};
    return `
    <tr>
      <td>${u.uid || "—"}</td>
      <td>${u.username || "—"}</td>
      <td>${u.full_name || "—"}</td>
      <td>${(w.winning_balance || 0).toLocaleString()}</td>
      <td>${(w.bonus_balance || 0).toLocaleString()}</td>
      <td>${(w.cash_balance || 0).toLocaleString()}</td>
      <td>${u.is_banned ? '<span class="badge badge-banned">Banned</span>' : '<span class="badge badge-active">Active</span>'}</td>
      <td>
        <button class="row-btn" data-coins="${u.id}" data-username="${u.username}">Edit Coins</button>
        <button class="row-btn ${u.is_banned ? "success" : "danger"}" data-ban="${u.id}" data-banned="${u.is_banned}">${u.is_banned ? "Unban" : "Ban"}</button>
      </td>
    </tr>`;
  }).join("") || `<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:30px;">No users yet.</td></tr>`;

  document.querySelectorAll("[data-ban]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const userId = btn.dataset.ban;
      const currentlyBanned = btn.dataset.banned === "true";
      const { data, error } = await sb.rpc("admin_set_ban", { p_user_id: userId, p_banned: !currentlyBanned });
      if (error || data.error) { toast((data && data.error) || error.message); return; }
      toast(currentlyBanned ? "User unbanned." : "User banned.");
      fetchUsers();
    });
  });

  document.querySelectorAll("[data-coins]").forEach((btn) => {
    btn.addEventListener("click", () => openCoinsModal(btn.dataset.coins, btn.dataset.username));
  });
}

document.getElementById("user-search").addEventListener("input", (e) => {
  const q = e.target.value.trim().toLowerCase();
  if (!q) { renderUsers(allUsers); return; }
  renderUsers(allUsers.filter((u) =>
    (u.username || "").toLowerCase().includes(q) ||
    (u.uid || "").toLowerCase().includes(q) ||
    (u.full_name || "").toLowerCase().includes(q)
  ));
});

/* ---------------- EDIT COINS MODAL ---------------- */
let coinsModalUserId = null;
function openCoinsModal(userId, username) {
  coinsModalUserId = userId;
  document.getElementById("coins-modal-username").textContent = username;
  document.getElementById("coins-adjust").value = "";
  document.getElementById("coins-set").value = "";
  document.getElementById("coins-modal").classList.add("active");
}
document.getElementById("coins-cancel-btn").addEventListener("click", () => {
  document.getElementById("coins-modal").classList.remove("active");
});
document.getElementById("coins-save-btn").addEventListener("click", async () => {
  const balanceType = document.getElementById("coins-type").value;
  const adjustVal = document.getElementById("coins-adjust").value;
  const setVal = document.getElementById("coins-set").value;

  if (!adjustVal && !setVal) { toast("Enter an amount to add/subtract, or an exact value to set."); return; }

  let result;
  if (setVal) {
    result = await sb.rpc("admin_set_coin_balance", { p_user_id: coinsModalUserId, p_new_amount: Number(setVal), p_balance_type: balanceType });
  } else {
    result = await sb.rpc("admin_adjust_coins", { p_user_id: coinsModalUserId, p_amount: Number(adjustVal), p_balance_type: balanceType });
  }
  if (result.error || (result.data && result.data.error)) { toast((result.data && result.data.error) || result.error.message); return; }
  toast("Coins updated.");
  document.getElementById("coins-modal").classList.remove("active");
  fetchUsers();
});

/* ---------------- TOURNAMENTS ---------------- */
async function fetchTournaments() {
  const { data, error } = await sb.from("tournaments").select("*, tournament_rooms(room_id, room_password, released_at)").order("created_at", { ascending: false });
  if (error) { toast("Could not load tournaments: " + error.message); return; }
  allTournaments = data || [];
  renderTournaments(allTournaments);
  populateTournamentDropdowns(allTournaments);
}

function renderTournaments(list) {
  document.getElementById("tournaments-tbody").innerHTML = list.map((t) => `
    <tr>
      <td>${t.tournament_number || "—"}</td>
      <td>${t.name}</td>
      <td>${t.category}</td>
      <td>₹${t.entry_fee}</td>
      <td>₹${t.prize_pool}</td>
      <td>${t.max_slots}</td>
      <td>${t.status}</td>
      <td>${t.tournament_rooms?.[0]?.room_id ? "Set" : "—"}</td>
    </tr>`).join("") || `<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:30px;">No tournaments yet.</td></tr>`;
}

function populateTournamentDropdowns(list) {
  const options = list.map((t) => `<option value="${t.id}">${t.tournament_number} — ${t.name}</option>`).join("");
  document.getElementById("r-tournament").innerHTML = options;
  document.getElementById("room-tournament").innerHTML = options;
}

document.getElementById("create-tournament-btn").addEventListener("click", async () => {
  const rules = document.getElementById("t-rules").value.split("\n").map((r) => r.trim()).filter(Boolean);
  const payload = {
    p_name: document.getElementById("t-name").value.trim(),
    p_category: document.getElementById("t-category").value.trim(),
    p_entry_fee: Number(document.getElementById("t-entry").value || 0),
    p_prize_pool: Number(document.getElementById("t-prize").value || 0),
    p_per_kill_reward: Number(document.getElementById("t-perkill").value || 0),
    p_map: document.getElementById("t-map").value.trim(),
    p_mode: document.getElementById("t-mode").value.trim(),
    p_team_type: document.getElementById("t-team").value.trim(),
    p_version: document.getElementById("t-version").value.trim(),
    p_room_type: document.getElementById("t-roomtype").value.trim(),
    p_max_slots: Number(document.getElementById("t-slots").value || 0),
    p_registration_ends_at: document.getElementById("t-regends").value ? new Date(document.getElementById("t-regends").value).toISOString() : null,
    p_match_starts_at: document.getElementById("t-starts").value ? new Date(document.getElementById("t-starts").value).toISOString() : null,
    p_rules: rules.join("\n"),
  };
  if (!payload.p_name || !payload.p_category || !payload.p_max_slots || !payload.p_registration_ends_at) {
    toast("Fill in at least Name, Category, Max Slots, and Registration Ends.");
    return;
  }
  const { data, error } = await sb.rpc("admin_create_tournament", payload);
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Tournament created!");
  ["t-name","t-category","t-entry","t-prize","t-perkill","t-slots","t-map","t-mode","t-team","t-version","t-roomtype","t-regends","t-starts","t-rules"]
    .forEach((id) => document.getElementById(id).value = "");
  fetchTournaments();
});

/* ---------------- MATCH RESULTS ---------------- */
document.getElementById("submit-result-btn").addEventListener("click", async () => {
  const tournamentId = document.getElementById("r-tournament").value;
  const uid = document.getElementById("r-uid").value.trim();
  const rank = Number(document.getElementById("r-rank").value);
  const kills = Number(document.getElementById("r-kills").value || 0);
  const prize = Number(document.getElementById("r-prize").value || 0);

  if (!tournamentId || !uid || !rank) { toast("Select a tournament, and enter a UID and rank."); return; }

  const { data: player } = await sb.from("users").select("id").eq("uid", uid).single();
  if (!player) { toast("No player found with that UID."); return; }

  const { data, error } = await sb.rpc("admin_set_match_result", {
    p_tournament_id: tournamentId, p_user_id: player.id, p_rank: rank, p_kills: kills, p_prize_won: prize,
  });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Result saved" + (prize > 0 ? ` — ₹${prize} credited.` : "."));
  ["r-uid","r-rank","r-kills","r-prize"].forEach((id) => document.getElementById(id).value = "");
});

document.getElementById("save-room-btn").addEventListener("click", async () => {
  const tournamentId = document.getElementById("room-tournament").value;
  const roomId = document.getElementById("room-id").value.trim();
  const roomPassword = document.getElementById("room-password").value.trim();
  const releaseAt = document.getElementById("room-release").value;

  if (!tournamentId || !roomId || !roomPassword || !releaseAt) { toast("Fill in all room fields."); return; }

  const { data, error } = await sb.rpc("admin_set_room_details", {
    p_tournament_id: tournamentId, p_room_id: roomId, p_room_password: roomPassword,
    p_released_at: new Date(releaseAt).toISOString(),
  });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Room details saved.");
  ["room-id","room-password","room-release"].forEach((id) => document.getElementById(id).value = "");
  fetchTournaments();
});

/* ---------------- WITHDRAWALS ---------------- */
async function fetchWithdrawals() {
  const { data, error } = await sb.from("withdrawals").select("*, users(username, uid)").order("created_at", { ascending: false });
  if (error) { toast("Could not load withdrawals: " + error.message); return; }
  renderWithdrawals(data || []);
}

function renderWithdrawals(list) {
  document.getElementById("withdrawals-tbody").innerHTML = list.map((w) => `
    <tr>
      <td>${w.users?.username || "—"} (${w.users?.uid || "—"})</td>
      <td>₹${w.amount}</td>
      <td>${w.destination_type.toUpperCase()} — ${w.destination_value}</td>
      <td><span class="badge badge-${w.status === "completed" ? "active" : w.status === "rejected" ? "banned" : "pending"}">${w.status}</span></td>
      <td>${new Date(w.created_at).toLocaleDateString()}</td>
      <td>
        ${w.status === "pending" || w.status === "processing" ? `
          <button class="row-btn success" data-wapprove="${w.id}">Complete</button>
          <button class="row-btn danger" data-wreject="${w.id}">Reject</button>
        ` : "—"}
      </td>
    </tr>`).join("") || `<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:30px;">No withdrawals yet.</td></tr>`;

  document.querySelectorAll("[data-wapprove]").forEach((btn) => {
    btn.addEventListener("click", () => updateWithdrawal(btn.dataset.wapprove, "completed"));
  });
  document.querySelectorAll("[data-wreject]").forEach((btn) => {
    btn.addEventListener("click", () => updateWithdrawal(btn.dataset.wreject, "rejected"));
  });
}

async function updateWithdrawal(id, status) {
  const { data, error } = await sb.rpc("admin_update_withdrawal", { p_withdrawal_id: id, p_status: status });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast(status === "completed" ? "Marked as completed." : "Rejected — coins refunded to player.");
  fetchWithdrawals();
}

/* ---------------- GIVEAWAYS ---------------- */
async function fetchGiveaways() {
  const { data, error } = await sb.from("giveaways").select("*").order("created_at", { ascending: false });
  if (error) { toast("Could not load giveaways: " + error.message); return; }
  document.getElementById("giveaways-tbody").innerHTML = (data || []).map((g) => `
    <tr><td>${g.title}</td><td>${g.reward_description || "—"}</td><td>${new Date(g.ends_at).toLocaleDateString()}</td></tr>
  `).join("") || `<tr><td colspan="3" style="text-align:center;color:var(--text-muted);padding:30px;">No giveaways yet.</td></tr>`;
}

document.getElementById("create-giveaway-btn").addEventListener("click", async () => {
  const title = document.getElementById("g-title").value.trim();
  const banner = document.getElementById("g-banner").value.trim();
  const reward = document.getElementById("g-reward").value.trim();
  const ends = document.getElementById("g-ends").value;
  if (!title || !ends) { toast("Enter at least a title and end date."); return; }

  const { data, error } = await sb.rpc("admin_create_giveaway", {
    p_title: title, p_banner_url: banner || null, p_reward_description: reward || null,
    p_ends_at: new Date(ends).toISOString(),
  });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Giveaway created!");
  ["g-title","g-banner","g-reward","g-ends"].forEach((id) => document.getElementById(id).value = "");
  fetchGiveaways();
});

/* ---------------- REDEEM CODES ---------------- */
async function fetchRedeemCodes() {
  const { data, error } = await sb.from("redeem_codes").select("*").order("created_at", { ascending: false });
  if (error) { toast("Could not load redeem codes: " + error.message); return; }
  document.getElementById("redeem-tbody").innerHTML = (data || []).map((c) => `
    <tr>
      <td><strong>${c.code}</strong></td>
      <td>${c.reward_coins} coins</td>
      <td>${c.used_count}</td>
      <td>${c.max_uses}</td>
      <td>${c.expires_at ? new Date(c.expires_at).toLocaleDateString() : "Never"}</td>
    </tr>`).join("") || `<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:30px;">No redeem codes yet.</td></tr>`;
}

document.getElementById("create-redeem-btn").addEventListener("click", async () => {
  const code = document.getElementById("rc-code").value.trim().toUpperCase();
  const reward = Number(document.getElementById("rc-reward").value);
  const maxUses = Number(document.getElementById("rc-maxuses").value || 1);
  const expires = document.getElementById("rc-expires").value;
  if (!code || !reward) { toast("Enter a code and reward amount."); return; }

  const { data, error } = await sb.rpc("admin_create_redeem_code", {
    p_code: code, p_reward: reward, p_max_uses: maxUses,
    p_expires_at: expires ? new Date(expires).toISOString() : null,
  });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Redeem code created!");
  ["rc-code","rc-reward","rc-maxuses","rc-expires"].forEach((id) => document.getElementById(id).value = "");
  fetchRedeemCodes();
});

/* ---------------- REFERRAL REWARD ---------------- */
async function fetchReferralReward() {
  const { data, error } = await sb.from("app_settings").select("value").eq("key", "referral_reward_coins").single();
  if (error) return;
  document.getElementById("referral-reward-input").value = data.value;
}

document.getElementById("save-referral-btn").addEventListener("click", async () => {
  const val = Number(document.getElementById("referral-reward-input").value);
  if (!val || val < 0) { toast("Enter a valid amount."); return; }
  const { data, error } = await sb.rpc("admin_set_referral_reward", { p_amount: val });
  if (error || data.error) { toast((data && data.error) || error.message); return; }
  toast("Referral reward updated to " + val + " coins.");
});

/* ---------------- NOTIFICATIONS ---------------- */
document.getElementById("n-target").addEventListener("change", (e) => {
  document.getElementById("n-uid-field").style.display = e.target.value === "one" ? "block" : "none";
});

document.getElementById("send-notification-btn").addEventListener("click", async () => {
  const target = document.getElementById("n-target").value;
  const title = document.getElementById("n-title").value.trim();
  const body = document.getElementById("n-body").value.trim();
  if (!title || !body) { toast("Enter a title and message."); return; }

  let userId = null;
  if (target === "one") {
    const uid = document.getElementById("n-uid").value.trim();
    if (!uid) { toast("Enter a player UID."); return; }
    const { data: player } = await sb.from("users").select("id").eq("uid", uid).single();
    if (!player) { toast("No player found with that UID."); return; }
    userId = player.id;
  }

  const { data, error } = await sb.rpc("admin_send_notification", { p_user_id: userId, p_title: title, p_body: body });
  if (error || data.error) { toast((data && data.error) || error.message); return; }

  // Also fire a real push notification via the Edge Function, best-effort —
  // the in-app notification row above is already saved either way.
  try {
    await sb.functions.invoke("send-notification", { body: { user_id: userId, title, body } });
  } catch (e) { /* push best-effort — the in-app notification still saved above */ }

  toast("Notification sent!");
  ["n-uid","n-title","n-body"].forEach((id) => document.getElementById(id).value = "");
});

/* ---------------- BOOT ---------------- */
checkExistingSession();
