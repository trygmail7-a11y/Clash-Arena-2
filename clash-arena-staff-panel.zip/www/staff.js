const SUPABASE_URL = "https://byxtpznjawxpiqnvebnm.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_gqpHmF1RoFePOiwEol74kg_KH4k-Pnw";
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let currentStaff = null;

function showScreen(id) {
  document.querySelectorAll(".screen").forEach((s) => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

// ---------- Login ----------
document.getElementById("login-btn").addEventListener("click", async () => {
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value;
  const errEl = document.getElementById("login-error");
  errEl.textContent = "";

  if (!email || !password) { errEl.textContent = "Enter email and password."; return; }

  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error || !data.user) {
    errEl.textContent = "Incorrect email or password.";
    return;
  }

  // Confirm this login actually belongs to a staff account — a player
  // account signing in here should never reach the staff dashboard.
  const { data: staffRow, error: staffErr } = await sb.from("staff").select("*").eq("id", data.user.id).single();
  if (staffErr || !staffRow) {
    errEl.textContent = "This account is not registered as staff.";
    await sb.auth.signOut();
    return;
  }
  if (!staffRow.is_active) {
    errEl.textContent = "Your staff account has been deactivated. Contact admin.";
    await sb.auth.signOut();
    return;
  }

  currentStaff = staffRow;
  enterDashboard();
});

document.getElementById("logout-btn").addEventListener("click", async () => {
  await sb.auth.signOut();
  currentStaff = null;
  showScreen("screen-login");
});

// ---------- Dashboard ----------
async function enterDashboard() {
  showScreen("screen-dashboard");
  document.getElementById("wallet-balance").textContent = "₹" + Number(currentStaff.wallet_balance).toLocaleString("en-IN");
  loadNotices();
  loadMySubmissions();
}

async function loadNotices() {
  const el = document.getElementById("notice-list");
  const { data, error } = await sb.from("staff_notices").select("*").order("created_at", { ascending: false }).limit(10);
  if (error || !data || data.length === 0) { el.innerHTML = `<p class="muted">No notices right now.</p>`; return; }
  el.innerHTML = "";
  data.forEach((n) => {
    const div = document.createElement("div");
    div.className = "notice-item";
    const h4 = document.createElement("h4"); h4.textContent = n.title;
    const p = document.createElement("p"); p.textContent = n.message;
    const time = document.createElement("time"); time.textContent = new Date(n.created_at).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
    div.append(h4, p, time);
    el.appendChild(div);
  });
}

async function loadMySubmissions() {
  const el = document.getElementById("my-submissions");
  const { data, error } = await sb.from("staff_room_submissions").select("*").eq("staff_id", currentStaff.id).order("created_at", { ascending: false }).limit(10);
  if (error || !data || data.length === 0) { el.innerHTML = `<p class="muted">Nothing sent yet.</p>`; return; }
  el.innerHTML = "";
  data.forEach((r) => {
    const div = document.createElement("div");
    div.className = "sub-item";
    div.textContent = `${r.tournament_name} — Room: ${r.room_id}`;
    const t = document.createElement("div"); t.className = "t";
    t.textContent = new Date(r.created_at).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
    div.appendChild(t);
    el.appendChild(div);
  });
}

// ---------- Submit Room ID & Password ----------
document.getElementById("room-submit-btn").addEventListener("click", async () => {
  const tournament_name = document.getElementById("room-tournament").value.trim();
  const room_id = document.getElementById("room-id").value.trim();
  const room_password = document.getElementById("room-password").value.trim();
  const successEl = document.getElementById("room-success");
  successEl.textContent = "";

  if (!tournament_name || !room_id || !room_password) { successEl.textContent = ""; alert("Fill all fields."); return; }

  const { error } = await sb.from("staff_room_submissions").insert({
    staff_id: currentStaff.id, tournament_name, room_id, room_password,
  });
  if (error) { alert("Could not send: " + error.message); return; }

  successEl.textContent = "Sent to admin ✓";
  document.getElementById("room-tournament").value = "";
  document.getElementById("room-id").value = "";
  document.getElementById("room-password").value = "";
  loadMySubmissions();
});

// ---------- Withdraw request ----------
document.getElementById("withdraw-btn").addEventListener("click", async () => {
  const amount = parseFloat(document.getElementById("withdraw-amount").value);
  const upi_id = document.getElementById("withdraw-upi").value.trim();
  const successEl = document.getElementById("withdraw-success");
  const errEl = document.getElementById("withdraw-error");
  successEl.textContent = ""; errEl.textContent = "";

  if (!amount || amount <= 0 || !upi_id) { errEl.textContent = "Enter a valid amount and UPI ID."; return; }

  const { data, error } = await sb.rpc("staff_submit_withdraw", { p_amount: amount, p_upi_id: upi_id });
  if (error || (data && data.error)) { errEl.textContent = (data && data.error) || error.message; return; }

  successEl.textContent = "Withdraw request sent to admin ✓";
  document.getElementById("withdraw-amount").value = "";
  document.getElementById("withdraw-upi").value = "";

  // Refresh balance locally since it was just deducted
  const { data: staffRow } = await sb.from("staff").select("*").eq("id", currentStaff.id).single();
  if (staffRow) { currentStaff = staffRow; document.getElementById("wallet-balance").textContent = "₹" + Number(staffRow.wallet_balance).toLocaleString("en-IN"); }
});

// ---------- Resume session on reload ----------
(async () => {
  const { data } = await sb.auth.getSession();
  if (data.session && data.session.user) {
    const { data: staffRow } = await sb.from("staff").select("*").eq("id", data.session.user.id).single();
    if (staffRow && staffRow.is_active) {
      currentStaff = staffRow;
      enterDashboard();
    }
  }
})();
