const SUPABASE_URL = "https://byxtpznjawxpiqnvebnm.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_gqpHmF1RoFePOiwEol74kg_KH4k-Pnw";
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let currentStaff = null;

function showScreen(id) {
  // Exactly the same pattern the Admin Panel uses: a plain `.hidden`
  // class with `display:none !important` on the screen NOT being shown.
  // No overlay, no stacking, no "still visible behind" possibility.
  if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
  document.querySelectorAll(".screen").forEach((s) => s.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
}

// ---------- Login ----------
document.getElementById("login-btn").addEventListener("click", async () => {
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value;
  const errEl = document.getElementById("login-error");
  errEl.textContent = "";

  if (!email || !password) { errEl.textContent = "Enter email and password."; return; }

  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error || !data.user) {
    errEl.textContent = "Incorrect email or password.";
    return;
  }

  // Confirm this login actually belongs to a staff account — a player
  // account signing in here should never reach the staff dashboard.
  const { data: staffRow, error: staffErr } = await sb.from("staff").select("*").eq("id", data.user.id).single();
  if (staffErr || !staffRow) {
    errEl.textContent = "This account is not registered as staff.";
    await sb.auth.signOut();
    return;
  }
  if (!staffRow.is_active) {
    errEl.textContent = "Your staff account has been deactivated. Contact admin.";
    await sb.auth.signOut();
    return;
  }

  currentStaff = staffRow;
  enterDashboard();
});

document.getElementById("logout-btn").addEventListener("click", async () => {
  await sb.auth.signOut();
  currentStaff = null;
  showScreen("screen-login");
});

// ---------- Dashboard ----------
async function enterDashboard() {
  showScreen("screen-dashboard");
  document.getElementById("wallet-balance").textContent = "₹" + Number(currentStaff.wallet_balance).toLocaleString("en-IN");
  loadNotices();
  loadMyTournaments();
  loadMySubmissions();
  loadMyWithdrawals();
}

async function loadMyTournaments() {
  const el = document.getElementById("my-tournaments");
  const { data, error } = await sb.from("staff_tournament_assignments")
    .select("*, tournaments(id, name, mode, entry_fee, prize_pool, tournament_number)")
    .eq("staff_id", currentStaff.id)
    .order("assigned_at", { ascending: false });

  if (error || !data || data.length === 0) {
    el.innerHTML = `<p class="muted">No tournaments assigned to you yet.</p>`;
    populateRoomTournamentSelect([]);
    return;
  }

  el.innerHTML = "";
  data.forEach((a) => {
    const t = a.tournaments;
    if (!t) return;
    const div = document.createElement("div");
    div.className = "tourn-card";
    div.innerHTML = `<h4>${t.name} <span class="muted">#${t.tournament_number}</span></h4>
      <div class="meta">Mode: ${t.mode || "—"} · Entry: ${t.entry_fee} coins · Prize: ₹${t.prize_pool}</div>`;
    el.appendChild(div);
  });

  populateRoomTournamentSelect(data.map((a) => a.tournaments).filter(Boolean));
}

function populateRoomTournamentSelect(tournamentsList) {
  const select = document.getElementById("room-tournament-select");
  if (!tournamentsList || tournamentsList.length === 0) {
    select.innerHTML = `<option value="">No tournaments assigned to you</option>`;
    return;
  }
  select.innerHTML = `<option value="">— Select tournament —</option>` +
    tournamentsList.map((t) => `<option value="${t.id}" data-name="${t.name}">${t.name} (#${t.tournament_number})</option>`).join("");
}

async function loadNotices() {
  const el = document.getElementById("notice-list");
  const { data, error } = await sb.from("staff_notices").select("*").order("created_at", { ascending: false }).limit(30);
  if (error || !data) { el.innerHTML = `<p class="muted">No notices right now.</p>`; return; }

  // "Important Notice" list only shows type='notice' — these stay listed
  // permanently for staff to refer back to.
  const notices = data.filter((n) => n.type === "notice");
  if (notices.length === 0) {
    el.innerHTML = `<p class="muted">No notices right now.</p>`;
  } else {
    el.innerHTML = "";
    notices.forEach((n) => {
      const div = document.createElement("div");
      div.className = "notice-item";
      const h4 = document.createElement("h4"); h4.textContent = n.title;
      const p = document.createElement("p"); p.textContent = n.message;
      const time = document.createElement("time"); time.textContent = new Date(n.created_at).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
      div.append(h4, p, time);
      el.appendChild(div);
    });
  }

  // type='notification' is a one-time pop-up alert, not a persistent list
  // item. Track which ones this device has already shown (per staff
  // account) so the same notification doesn't pop up again on every login.
  const notifications = data.filter((n) => n.type === "notification");
  const seenKey = "ca_staff_seen_notifs_" + currentStaff.id;
  const seenIds = new Set(JSON.parse(localStorage.getItem(seenKey) || "[]"));
  const unseen = notifications.filter((n) => !seenIds.has(n.id));

  unseen.reverse().forEach((n, i) => {
    setTimeout(() => showNotificationPopup(n.title, n.message), i * 3500);
    seenIds.add(n.id);
  });
  if (unseen.length > 0) {
    localStorage.setItem(seenKey, JSON.stringify([...seenIds]));
  }
}

function showNotificationPopup(title, message) {
  const popup = document.createElement("div");
  popup.className = "notif-popup";
  const strong = document.createElement("strong"); strong.textContent = title;
  const p = document.createElement("p"); p.textContent = message;
  popup.append(strong, p);
  document.body.appendChild(popup);
  requestAnimationFrame(() => popup.classList.add("show"));
  setTimeout(() => {
    popup.classList.remove("show");
    setTimeout(() => popup.remove(), 300);
  }, 4500);
}

async function loadMySubmissions() {
  const el = document.getElementById("my-submissions");
  const { data, error } = await sb.from("staff_room_submissions").select("*").eq("staff_id", currentStaff.id).order("created_at", { ascending: false }).limit(10);
  if (error || !data || data.length === 0) {
    el.innerHTML = `<p class="muted">Nothing sent yet.</p>`;
    populateWinnerRoomSelect([]);
    return;
  }
  el.innerHTML = "";
  data.forEach((r) => {
    const div = document.createElement("div");
    div.className = "sub-item";
    let winnerText = "";
    if (r.winners && Array.isArray(r.winners) && r.winners.length > 0) {
      winnerText = " — " + r.winners.map((w) => `${w.position}: ${w.name} (${w.uid})`).join(", ");
    } else if (r.winner_uid) {
      winnerText = ` — Winner: ${r.winner_name} (${r.winner_uid})`;
    }
    div.textContent = `${r.tournament_name} — Room: ${r.room_id}` + winnerText;
    const t = document.createElement("div"); t.className = "t";
    t.textContent = new Date(r.created_at).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
    div.appendChild(t);
    el.appendChild(div);
  });
  populateWinnerRoomSelect(data);
}

function populateWinnerRoomSelect(rooms) {
  const select = document.getElementById("winner-room-select");
  if (!rooms || rooms.length === 0) {
    select.innerHTML = `<option value="">Send a Room ID first</option>`;
    return;
  }
  select.innerHTML = `<option value="">— Select the room —</option>` +
    rooms.map((r) => `<option value="${r.id}">${r.tournament_name} (Room: ${r.room_id})</option>`).join("");
}

// ---------- Submit Room ID & Password ----------
document.getElementById("room-submit-btn").addEventListener("click", async () => {
  const select = document.getElementById("room-tournament-select");
  const tournament_id = select.value;
  const tournament_name = tournament_id ? select.options[select.selectedIndex].dataset.name : "";
  const room_id = document.getElementById("room-id").value.trim();
  const room_password = document.getElementById("room-password").value.trim();
  const successEl = document.getElementById("room-success");
  const errEl = document.getElementById("room-error");
  successEl.textContent = ""; errEl.textContent = "";

  if (!tournament_id) { errEl.textContent = "Select a tournament first."; return; }
  if (!room_id || !room_password) { errEl.textContent = "Fill Room ID and Password."; return; }

  const { error } = await sb.from("staff_room_submissions").insert({
    staff_id: currentStaff.id, tournament_id, tournament_name, room_id, room_password,
  });
  if (error) { errEl.textContent = "Could not send: " + error.message; return; }

  successEl.textContent = "Sent to admin ✓";
  document.getElementById("room-id").value = "";
  document.getElementById("room-password").value = "";
  loadMySubmissions();
});

// ---------- Report Winner ----------
document.getElementById("winner-mode-select").addEventListener("change", () => {
  const mode = document.getElementById("winner-mode-select").value;
  document.getElementById("winner-mode-single").style.display = mode === "single" ? "" : "none";
  document.getElementById("winner-mode-multi").style.display = mode === "multi" ? "" : "none";
});

const POSITION_LABELS = ["1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th"];
let multiWinnerCount = 0;
document.getElementById("add-position-btn").addEventListener("click", () => {
  const idx = multiWinnerCount++;
  const label = POSITION_LABELS[idx] || (idx + 1) + "th";
  const row = document.createElement("div");
  row.className = "field";
  row.style.cssText = "display:flex;gap:8px;align-items:flex-end;";
  row.dataset.rank = idx + 1;
  row.innerHTML = `
    <div style="flex:none;width:38px;font-weight:700;padding-bottom:11px;font-size:0.85rem;">${label}</div>
    <div style="flex:1;"><input type="text" class="multi-winner-uid" placeholder="UID"></div>
    <div style="flex:1;"><input type="text" class="multi-winner-name" placeholder="Username"></div>
    <button type="button" class="btn-outline small" style="flex:none;">✕</button>
  `;
  row.querySelector("button").addEventListener("click", () => row.remove());
  document.getElementById("multi-winner-rows").appendChild(row);
});

document.getElementById("winner-submit-btn").addEventListener("click", async () => {
  const submissionId = document.getElementById("winner-room-select").value;
  const mode = document.getElementById("winner-mode-select").value;
  const successEl = document.getElementById("winner-success");
  const errEl = document.getElementById("winner-error");
  successEl.textContent = ""; errEl.textContent = "";

  if (!submissionId) { errEl.textContent = "Select which room this winner is for."; return; }

  let updatePayload = {};
  if (mode === "single") {
    const winner_uid = document.getElementById("winner-uid").value.trim();
    const winner_name = document.getElementById("winner-name").value.trim();
    if (!winner_uid || !winner_name) { errEl.textContent = "Enter both the winner's UID and username."; return; }
    updatePayload = { winner_uid, winner_name, winners: [{ position: "1st", uid: winner_uid, name: winner_name }] };
  } else {
    const winners = [];
    document.querySelectorAll("#multi-winner-rows > div").forEach((row) => {
      const uid = row.querySelector(".multi-winner-uid").value.trim();
      const name = row.querySelector(".multi-winner-name").value.trim();
      if (uid && name) winners.push({ position: POSITION_LABELS[row.dataset.rank - 1] || row.dataset.rank + "th", uid, name });
    });
    if (winners.length === 0) { errEl.textContent = "Add at least one position with UID and username."; return; }
    updatePayload = { winners, winner_uid: winners[0].uid, winner_name: winners[0].name };
  }

  const { error } = await sb.from("staff_room_submissions")
    .update(updatePayload)
    .eq("id", submissionId)
    .eq("staff_id", currentStaff.id); // extra safety — only ever update your own row

  if (error) { errEl.textContent = "Could not send: " + error.message; return; }

  successEl.textContent = "Winner(s) sent to admin ✓";
  document.getElementById("winner-uid").value = "";
  document.getElementById("winner-name").value = "";
  document.getElementById("multi-winner-rows").innerHTML = "";
  multiWinnerCount = 0;
  loadMySubmissions();
});

// ---------- Withdraw request ----------
document.getElementById("withdraw-btn").addEventListener("click", async () => {
  const amount = parseFloat(document.getElementById("withdraw-amount").value);
  const upi_id = document.getElementById("withdraw-upi").value.trim();
  const successEl = document.getElementById("withdraw-success");
  const errEl = document.getElementById("withdraw-error");
  successEl.textContent = ""; errEl.textContent = "";

  if (!amount || amount <= 0 || !upi_id) { errEl.textContent = "Enter a valid amount and UPI ID."; return; }

  const { data, error } = await sb.rpc("staff_submit_withdraw", { p_amount: amount, p_upi_id: upi_id });
  if (error || (data && data.error)) { errEl.textContent = (data && data.error) || error.message; return; }

  successEl.textContent = "Withdraw request sent to admin ✓";
  document.getElementById("withdraw-amount").value = "";
  document.getElementById("withdraw-upi").value = "";

  // Refresh balance locally since it was just deducted
  const { data: staffRow } = await sb.from("staff").select("*").eq("id", currentStaff.id).single();
  if (staffRow) { currentStaff = staffRow; document.getElementById("wallet-balance").textContent = "₹" + Number(staffRow.wallet_balance).toLocaleString("en-IN"); }
  loadMyWithdrawals();
});

async function loadMyWithdrawals() {
  const el = document.getElementById("my-withdrawals");
  const { data, error } = await sb.from("staff_withdraw_requests").select("*").eq("staff_id", currentStaff.id).order("created_at", { ascending: false }).limit(10);
  if (error || !data || data.length === 0) { el.innerHTML = ""; return; }

  el.innerHTML = `<h4 style="font-size:0.85rem;color:var(--muted);margin:14px 0 8px;">Your Withdraw Requests</h4>`;
  data.forEach((r) => {
    const div = document.createElement("div");
    div.className = "sub-item";
    div.innerHTML = `₹${Number(r.amount).toLocaleString("en-IN")} to ${r.upi_id} <span class="status-pill ${r.status}">${r.status}</span>`;
    const t = document.createElement("div"); t.className = "t";
    t.textContent = new Date(r.created_at).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
    div.appendChild(t);
    el.appendChild(div);
  });
}

// ---------- Resume session on reload ----------
(async () => {
  const { data } = await sb.auth.getSession();
  if (data.session && data.session.user) {
    const { data: staffRow } = await sb.from("staff").select("*").eq("id", data.session.user.id).single();
    if (staffRow && staffRow.is_active) {
      currentStaff = staffRow;
      enterDashboard();
    }
  }
})();
